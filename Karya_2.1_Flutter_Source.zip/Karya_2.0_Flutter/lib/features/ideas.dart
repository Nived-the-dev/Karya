import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/state.dart';
import '../core/models.dart';
import 'neo.dart';


final ideasProvider=FutureProvider<List<Idea>>((ref)=>ref.watch(dbProvider).loadIdeas());
class IdeasScreen extends ConsumerStatefulWidget{const IdeasScreen({super.key});@override ConsumerState<IdeasScreen> createState()=>_IdeasScreenState();}
class _IdeasScreenState extends ConsumerState<IdeasScreen>{String query='';
 Future<void> edit(Idea? idea) async {
   final controller=TextEditingController(text:idea?.body??'');
   var pinned=idea?.pinned??false;
   await showModalBottomSheet<void>(context:context,isScrollControlled:true,useSafeArea:true,showDragHandle:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>Padding(padding:EdgeInsets.fromLTRB(18,12,18,MediaQuery.viewInsetsOf(ctx).bottom+24),child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text(idea==null?'CAPTURE AN IDEA':'EDIT IDEA',style:Theme.of(ctx).textTheme.titleLarge),const SizedBox(height:14),TextField(controller:controller,autofocus:true,maxLines:6,minLines:3,maxLength:10000,decoration:const InputDecoration(hintText:'A thought, a plan, whatever is on your mind...')),SwitchListTile(title:const Text('Pin this idea'),value:pinned,onChanged:(v)=>setLocal(()=>pinned=v)),FilledButton(onPressed:()async{if(controller.text.trim().isEmpty)return;await ref.read(dbProvider).saveIdea(id:idea?.id,body:controller.text,pinned:pinned);ref.invalidate(ideasProvider);if(ctx.mounted)Navigator.pop(ctx);},child:const Text('SAVE IDEA'))]))));
   // Avoid disposing until the closing sheet animation is complete.
   Future<void>.delayed(const Duration(milliseconds:500),controller.dispose);
 }
 @override Widget build(BuildContext context){final ideas=ref.watch(ideasProvider);return ideas.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(e,_)=>Center(child:Text('Could not load ideas: $e')),data:(items){final filtered=items.where((i)=>i.body.toLowerCase().contains(query.toLowerCase())).toList();return ScreenBody(children:[const Headline('IDEAS ✦','Catch your thoughts before they disappear.'),NeoButton(label:'+ NEW IDEA',icon:Icons.edit_note_rounded,onPressed:()=>edit(null)),TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search your notes')),const SizedBox(height:18),if(filtered.isEmpty)const EmptyState('A blank page.','Your next big idea can start here.',icon:Icons.lightbulb_outline),...filtered.map((i)=>NeoCard(onTap:()=>edit(i),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[if(i.pinned)const Icon(Icons.push_pin,size:18),Text(i.body,maxLines:8,overflow:TextOverflow.ellipsis),const SizedBox(height:8),Row(children:[TextButton.icon(onPressed:()=>edit(i),icon:const Icon(Icons.edit_outlined,size:18),label:const Text('Edit')),const Spacer(),IconButton(tooltip:'Convert to task',icon:const Icon(Icons.add_task),onPressed:()async {await ref.read(appProvider.notifier).change((db)=>db.saveTask(title:i.body.split('\n').first.trim().substring(0,i.body.split('\n').first.trim().length.clamp(0,180))));if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Added as a task!')));}),IconButton(tooltip:'Delete idea',icon:const Icon(Icons.delete_outline),onPressed:()async {if(!await confirmDelete(context,'idea'))return;await ref.read(dbProvider).removeIdea(i.id);ref.invalidate(ideasProvider);})])])))]);});}
}
