import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'neo.dart';
class AboutScreen extends StatelessWidget{const AboutScreen({super.key});
 Future<void> open(BuildContext context,String url) async {if(!await launchUrl(Uri.parse(url),mode:LaunchMode.externalApplication)&&context.mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not open this link.')));}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('BEHIND KĀRYA')),body:ScreenBody(children:[const Headline('THE STORY BEHIND THE CHAOS','Built by Nived Chandrasudan.'),const NeoCard(child:Text("I'm a very very messy person, like really messy. I thought why not fix this shit.\n\nSo I vibe coded Kārya.\n\nI hate ADS man. I really hate em. So it's offline and no ads (yay).\n\nHope it helps!",style:TextStyle(fontSize:17,height:1.55))),NeoButton(label:'KĀRYA ON GITHUB',icon:Icons.code,onPressed:()=>open(context,'https://github.com/Nived-the-dev/Karya')),NeoButton(label:'FIND ME ON LINKEDIN',icon:Icons.link,onPressed:()=>open(context,'https://www.linkedin.com/in/nived-chandrasudan-8a454b434/')),const SizedBox(height:12),const Text('Kārya 2.1 • Less Organising. More Doing. • Offline-first • No ads • No tracking',textAlign:TextAlign.center)]));
}
