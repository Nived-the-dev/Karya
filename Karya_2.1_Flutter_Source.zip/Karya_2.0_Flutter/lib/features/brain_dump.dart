import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/state.dart';
import 'neo.dart';

/// Offline text splitting with editable preview. Does not claim AI understanding.
List<String> splitThoughts(String raw) {
  final lines=raw.split(RegExp(r'[\n;]+')).expand((line)=>line.split(RegExp(r'\.\s+(?=[A-Z])')));
  return lines.map((line)=>line.trim().replaceAll(RegExp(r'^[-•*]\s*'),'')).where((line)=>line.isNotEmpty).toList();
}
class BrainDumpScreen extends ConsumerStatefulWidget {
  const BrainDumpScreen({super.key});
  @override ConsumerState<BrainDumpScreen> createState()=>_BrainDumpScreenState();
}
class _BrainDumpScreenState extends ConsumerState<BrainDumpScreen> {
  final text=TextEditingController();
  final entries=<TextEditingController>[];
  bool saving=false;
  @override void dispose(){text.dispose();for(final e in entries)e.dispose();super.dispose();}
  void preview(){for(final e in entries)e.dispose();entries.clear();entries.addAll(splitThoughts(text.text).map((thought)=>TextEditingController(text:thought)));setState((){});}
  Future<void> save() async {
    final candidates=entries.map((e)=>e.text.trim()).where((e)=>e.isNotEmpty).toList();
    if(candidates.isEmpty)return;
    setState(()=>saving=true);
    try {
      await ref.read(appProvider.notifier).change((db)=>db.transaction(() async {
        for(final title in candidates) {await db.saveTask(title:title.substring(0,title.length.clamp(0,180)));}
      }));
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Added ${candidates.length} task(s). You can edit their details in Tasks.')));Navigator.pop(context);}
    }catch(e){if(mounted)toast(context,'Could not save tasks: $e');}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('BRAIN DUMP')),body:ScreenBody(children:[const Headline('EMPTY YOUR HEAD.','Write messy thoughts. We will split them into editable tasks.'),NeoCard(child:TextField(controller:text,minLines:5,maxLines:9,decoration:const InputDecoration(hintText:'Finish history essay\nRead chapter 4\nBuy a notebook'))),NeoButton(label:'PREVIEW TASKS',icon:Icons.auto_fix_high,onPressed:preview),const SizedBox(height:10),if(entries.isNotEmpty)...[Text('REVIEW BEFORE SAVING',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:5),const Text('Edit or remove each task. Dates and subjects can be added later.'),const SizedBox(height:10),...entries.asMap().entries.map((entry)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Row(children:[Expanded(child:TextField(controller:entry.value,decoration:InputDecoration(labelText:'Task ${entry.key+1}'))),IconButton(icon:const Icon(Icons.close),tooltip:'Remove task',onPressed:(){final removed=entries.removeAt(entry.key);setState((){});Future<void>.delayed(const Duration(milliseconds:300),removed.dispose);})]))),NeoButton(label:saving?'SAVING...':'CREATE ${entries.where((t)=>t.text.trim().isNotEmpty).length} TASKS',icon:Icons.add_task,onPressed:saving?null:save)],const SizedBox(height:20),const Text('Kārya Brain Dump uses offline rules, not a cloud AI. Always review its suggestions.') ]));
}
