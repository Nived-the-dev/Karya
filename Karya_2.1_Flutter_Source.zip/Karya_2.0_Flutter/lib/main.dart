import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'core/state.dart';
import 'core/notifications.dart';
import 'features/screens.dart';
import 'features/ideas.dart';
import 'features/tour.dart';
import 'features/brain_dump.dart';
import 'features/neo.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Reminders.instance.initialize(); } catch (_) { /* show app even if notifications unavailable */ }
  runApp(const ProviderScope(child: KaryaApp()));
}

final router = GoRouter(initialLocation:'/',routes:[
  StatefulShellRoute.indexedStack(builder:(context,state,shell)=>AppScaffold(shell:shell),branches:[
    StatefulShellBranch(routes:[GoRoute(path:'/',builder:(context,state)=>const HomeScreen())]),
    StatefulShellBranch(routes:[GoRoute(path:'/tasks',builder:(context,state)=>TasksScreen(initialSubjectId:int.tryParse(state.uri.queryParameters['subject'] ?? '')))]),
    StatefulShellBranch(routes:[GoRoute(path:'/habits',builder:(context,state)=>const HabitsScreen())]),
    StatefulShellBranch(routes:[GoRoute(path:'/progress',builder:(context,state)=>const ProgressScreen())]),
    StatefulShellBranch(routes:[GoRoute(path:'/ideas',builder:(context,state)=>const IdeasScreen())]),
  ]),
  GoRoute(path:'/brain-dump',builder:(context,state)=>const BrainDumpScreen()),
  GoRoute(path:'/chat',builder:(context,state)=>const ChatScreen()),
  GoRoute(path:'/settings',builder:(context,state)=>const SettingsScreen()),
  GoRoute(path:'/tour',builder:(context,state)=>const TourScreen()),
]);

class KaryaApp extends ConsumerWidget {
  const KaryaApp({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeProvider).value ?? 'system';
    final personality = ref.watch(paletteProvider).value ?? 'Classic';
    return MaterialApp.router(title:'Kārya — कार्य',debugShowCheckedModeBanner:false,
      theme:neoTheme(false,personality),darkTheme:neoTheme(true,personality),themeMode:switch(mode){'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system},routerConfig:router);
  }
}
const themeNames=['Classic','Soft Pop','Monochrome','Forest','Lavender'];
const colorSets=<String,List<Color>>{
 'Classic':[Color(0xFFFFD51D),Color(0xFFFF4C89),Color(0xFFA6E529)],
 'Soft Pop':[Color(0xFFF7EDD9),Color(0xFFDE92B6),Color(0xFFAFD5A7)],
 'Monochrome':[Color(0xFFF1F1EE),Color(0xFF979797),Color(0xFFD1D1D1)],
 'Forest':[Color(0xFFE9EBD7),Color(0xFF719E78),Color(0xFFC4A779)],
 'Lavender':[Color(0xFFF0E9FC),Color(0xFF9573F5),Color(0xFFFFABC5)],
};
ThemeData neoTheme(bool dark,[String personality='Classic']) {
  final colors=colorSets[personality]??colorSets['Classic']!;
  const ink=Color(0xFF111111); const off=Color(0xFFFFFCF7);
  final background=dark?Colors.black:colors.first;
  final surface=dark?const Color(0xFF131313):off;
  final text=dark?Colors.white:ink;
  final accent=colors[1];
  return ThemeData(useMaterial3:true,brightness:dark?Brightness.dark:Brightness.light,scaffoldBackgroundColor:background,
    colorScheme:ColorScheme.fromSeed(seedColor:accent,brightness:dark?Brightness.dark:Brightness.light,surface:surface,primary:dark?colors[1]:ink,onSurface:text),
    textTheme:TextTheme(headlineLarge:TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:text,letterSpacing:-1.2),headlineMedium:TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:text),titleLarge:TextStyle(fontWeight:FontWeight.w900,color:text),bodyMedium:TextStyle(color:text)),
    appBarTheme:AppBarTheme(backgroundColor:Colors.transparent,foregroundColor:text,centerTitle:false,scrolledUnderElevation:0),
    inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),contentPadding:const EdgeInsets.all(15)),
    snackBarTheme:SnackBarThemeData(backgroundColor:dark?const Color(0xFF252525):ink,contentTextStyle:const TextStyle(color:Colors.white)),
    extensions:[NeoAccents([colors[0],colors[1],colors[2],personality=='Classic'?const Color(0xFF9573F5):colors[1],personality=='Classic'?const Color(0xFF70DDE3):colors[2]])],
    pageTransitionsTheme:const PageTransitionsTheme(builders:{TargetPlatform.android:FadeUpwardsPageTransitionsBuilder()}));
}

class AppScaffold extends StatefulWidget {
  const AppScaffold({super.key,required this.shell});
  final StatefulNavigationShell shell;
  @override State<AppScaffold> createState()=>_AppScaffoldState();
}
class _AppScaffoldState extends State<AppScaffold> {
  @override void initState(){ super.initState(); WidgetsBinding.instance.addPostFrameCallback((_ ) async {
    final prefs=await SharedPreferences.getInstance(); if(!mounted)return;
    if (!(prefs.getBool('onboarded') ?? false)) {
      if(mounted)context.push('/tour');
      await prefs.setBool('onboarded',true);
    }
  });}
  double dragDistance=0;
  void tapFeedback(){SharedPreferences.getInstance().then((p){if(p.getBool('haptics')??true)HapticFeedback.selectionClick();});}
  @override Widget build(BuildContext context) {
    final labels=['Home','Tasks','Habits','Progress','Ideas'];
    final icons=[Icons.home_rounded,Icons.check_box_rounded,Icons.auto_awesome_rounded,Icons.bar_chart_rounded,Icons.lightbulb_outline_rounded];
    return Scaffold(appBar:AppBar(title:const Text('KĀRYA ✦',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),actions:[IconButton(tooltip:'Command assistant',icon:const Icon(Icons.chat_bubble_outline_rounded),onPressed:()=>context.push('/chat')),IconButton(tooltip:'Settings',icon:const Icon(Icons.settings_outlined),onPressed:()=>context.push('/settings'))]),body:GestureDetector(behavior:HitTestBehavior.translucent,onHorizontalDragStart:(_)=>dragDistance=0,onHorizontalDragUpdate:(details)=>dragDistance+=details.delta.dx,onHorizontalDragEnd:(_){if(dragDistance.abs()<65)return;final to=(widget.shell.currentIndex+(dragDistance<0?1:-1)).clamp(0,4);if(to!=widget.shell.currentIndex){widget.shell.goBranch(to);tapFeedback();}},child:widget.shell),
      bottomNavigationBar:SafeArea(top:false,child:Container(margin:const EdgeInsets.fromLTRB(12,0,12,8),decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,border:Border.all(color:Theme.of(context).colorScheme.onSurface,width:2.5),borderRadius:BorderRadius.circular(18),boxShadow:const [BoxShadow(color:Colors.black,offset:Offset(4,4))]),child:Row(children:[for(var i=0;i<5;i++)Expanded(child:InkWell(borderRadius:BorderRadius.circular(14),onTap:(){widget.shell.goBranch(i);tapFeedback();},child:Padding(padding:const EdgeInsets.symmetric(vertical:9),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icons[i],color:widget.shell.currentIndex==i?const Color(0xFFFF4C89):Theme.of(context).colorScheme.onSurface),Text(labels[i],style:TextStyle(fontSize:10,fontWeight:widget.shell.currentIndex==i?FontWeight.w900:FontWeight.w600))]))))]))));
  }
}
