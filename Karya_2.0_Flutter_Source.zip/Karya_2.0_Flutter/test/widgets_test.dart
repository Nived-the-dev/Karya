import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karya_app/features/neo.dart';

void main(){
  testWidgets('neo-brutalist task button responds to a tap',(tester) async {
    var presses=0;
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:Center(child:NeoButton(label:'Add task',onPressed:()=>presses++)))));
    await tester.tap(find.text('Add task'));
    expect(presses,1);
  });
  testWidgets('empty state provides clear guidance',(tester) async {
    await tester.pumpWidget(const MaterialApp(home:Scaffold(body:EmptyState('Nothing here','Create your first habit'))));
    expect(find.text('Nothing here'),findsOneWidget);
    expect(find.text('Create your first habit'),findsOneWidget);
  });
}
