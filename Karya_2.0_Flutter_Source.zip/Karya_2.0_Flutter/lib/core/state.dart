import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'database.dart';
import 'models.dart';
import 'notifications.dart';

final dbProvider = Provider<KaryaDatabase>((ref) {
  final db = KaryaDatabase();
  ref.onDispose(db.close);
  return db;
});
final appProvider = AsyncNotifierProvider<AppController,AppData>(AppController.new);
class AppController extends AsyncNotifier<AppData> {
  @override Future<AppData> build() async {
    final data = await ref.read(dbProvider).snapshot();
    try { await Reminders.instance.sync(data); } catch (_) { /* allow app startup without notifications */ }
    return data;
  }
  Future<T> change<T>(Future<T> Function(KaryaDatabase) operation) async {
    final db = ref.read(dbProvider);
    final result = await operation(db);
    final fresh = await db.snapshot();
    state = AsyncData(fresh);
    try { await Reminders.instance.sync(fresh); } catch (_) { /* data writes must succeed even when reminders are blocked */ }
    return result;
  }
  Future<void> refresh() async { state = AsyncData(await ref.read(dbProvider).snapshot()); }
}
final themeProvider = AsyncNotifierProvider<KaryaThemeController,String>(KaryaThemeController.new);
class KaryaThemeController extends AsyncNotifier<String> {
  @override Future<String> build() async => (await SharedPreferences.getInstance()).getString('theme') ?? 'system';
  Future<void> setTheme(String mode) async { (await SharedPreferences.getInstance()).setString('theme',mode); state = AsyncData(mode); }
}
