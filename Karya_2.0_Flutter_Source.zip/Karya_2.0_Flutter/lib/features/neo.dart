import 'package:flutter/material.dart';
import '../core/models.dart';

class NeoCard extends StatelessWidget {
  const NeoCard({super.key,required this.child,this.color,this.padding=const EdgeInsets.all(16),this.onTap});
  final Widget child; final Color? color;final EdgeInsets padding;final VoidCallback? onTap;
  @override Widget build(BuildContext context) {
    final dark=Theme.of(context).brightness==Brightness.dark;
    final c=color ?? Theme.of(context).colorScheme.surface;
    final ink=dark?Colors.white:const Color(0xFF111111);
    return Container(margin:const EdgeInsets.only(bottom:14,right:5),decoration:BoxDecoration(color:c,borderRadius:BorderRadius.circular(17),border:Border.all(color:ink,width:2.4),boxShadow:[BoxShadow(color:dark?Colors.white24:Colors.black,offset:const Offset(4,4))]),child:Material(color:Colors.transparent,child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(16),child:Padding(padding:padding,child:child))));
  }
}
class NeoButton extends StatelessWidget {
  const NeoButton({super.key,required this.label,required this.onPressed,this.icon,this.color});
  final String label; final VoidCallback? onPressed;final IconData? icon;final Color? color;
  @override Widget build(BuildContext context)=>NeoCard(color:color ?? colorFor(2),padding:EdgeInsets.zero,child:InkWell(onTap:onPressed,child:Padding(padding:const EdgeInsets.symmetric(horizontal:15,vertical:12),child:Row(mainAxisSize:MainAxisSize.min,mainAxisAlignment:MainAxisAlignment.center,children:[if(icon!=null) ...[Icon(icon,color:Colors.black,size:19),const SizedBox(width:7)],Flexible(child:Text(label,style:const TextStyle(fontWeight:FontWeight.w900,color:Colors.black)))]))));
}
class ScreenBody extends StatelessWidget {
  const ScreenBody({super.key,required this.children});
  final List<Widget> children;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(17,18,17,22),children:children);
}
class Headline extends StatelessWidget {
  const Headline(this.heading,this.subtitle,{super.key});final String heading,subtitle;
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(heading,style:Theme.of(context).textTheme.headlineLarge),Text(subtitle,style:const TextStyle(fontWeight:FontWeight.w600))]));
}
class EmptyState extends StatelessWidget {
  const EmptyState(this.title,this.subtitle,{super.key,this.icon=Icons.inbox_outlined});
  final String title,subtitle;final IconData icon;
  @override Widget build(BuildContext context)=>NeoCard(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[Icon(icon,size:44),const SizedBox(height:10),Text(title,textAlign:TextAlign.center,style:Theme.of(context).textTheme.titleLarge),Text(subtitle,textAlign:TextAlign.center)])));
}
Future<bool> confirmDelete(BuildContext context,String what) async => await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text('Delete $what?'),content:const Text('This permanently deletes the selected item and its history.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),TextButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Delete'))])) ?? false;
void toast(BuildContext context,String text){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));}
