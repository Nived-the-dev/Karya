import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/notifications.dart';
import '../core/state.dart';
import 'neo.dart';

class SettingsScreen extends ConsumerStatefulWidget{const SettingsScreen({super.key});@override ConsumerState<SettingsScreen> createState()=>_SettingsScreenState();}
class _SettingsScreenState extends ConsumerState<SettingsScreen>{
  bool notifications=false,defaultTaskReminders=false,defaultHabitReminders=false;
  @override void initState(){super.initState();SharedPreferences.getInstance().then((prefs){if(mounted)setState((){notifications=prefs.getBool('notifications')??false;defaultTaskReminders=prefs.getBool('default_task_reminders')??false;defaultHabitReminders=prefs.getBool('default_habit_reminders')??false;});});}
  Future<void> toggle(bool enable) async {
    if(enable){
      final allowed=await Reminders.instance.requestPermission();
      if(!allowed){if(mounted)toast(context,'Notification permission was not granted. Enable it in Android settings.');return;}
    }
    final prefs=await SharedPreferences.getInstance();await prefs.setBool('notifications',enable);
    if(mounted)setState(()=>notifications=enable);
    try{await Reminders.instance.sync(await ref.read(dbProvider).snapshot());}catch(e){if(mounted)toast(context,'Reminder scheduling issue: $e');}
  }
  @override Widget build(BuildContext context){final selected=ref.watch(themeProvider).value??'system';return Scaffold(appBar:AppBar(title:const Text('SETTINGS',style:TextStyle(fontWeight:FontWeight.w900))),body:ScreenBody(children:[const Headline('MAKE IT YOURS.','Simple controls. No account needed.'),NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('APPEARANCE',style:Theme.of(context).textTheme.titleLarge),for(final mode in ['light','dark','system'])ListTile(title:Text(mode=='system'?'Follow system':mode[0].toUpperCase()+mode.substring(1)),trailing:Icon(mode==selected?Icons.radio_button_checked:Icons.radio_button_unchecked),onTap:()=>ref.read(themeProvider.notifier).setTheme(mode))])),NeoCard(child:SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Assignment & habit reminders',style:TextStyle(fontWeight:FontWeight.w800)),subtitle:const Text('Optional local Android notifications; no cloud needed.'),value:notifications,onChanged:toggle)),NeoCard(child:Column(children:[SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('New tasks: remind me 1 hour before due'),subtitle:const Text('Applies when you add a new deadline without choosing a reminder.'),value:defaultTaskReminders,onChanged:(v)async{await(await SharedPreferences.getInstance()).setBool('default_task_reminders',v);if(mounted)setState(()=>defaultTaskReminders=v);}),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('New habits: default 6 PM reminder'),subtitle:const Text('You can change or remove the time while creating each habit.'),value:defaultHabitReminders,onChanged:(v)async{await(await SharedPreferences.getInstance()).setBool('default_habit_reminders',v);if(mounted)setState(()=>defaultHabitReminders=v);})])),NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('ABOUT',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:10),const Text('Kārya (कार्य) • v1.0.0\nLess Organising. More Doing.\nCreated by Nived Chandrasudan.\n\nOffline-first, rule-based assistant, no ads or accounts.'),const SizedBox(height:12),TextButton(onPressed:()=>showDialog<void>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Privacy Policy'),content:const SingleChildScrollView(child:Text(privacyText)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Close'))])),child:const Text('Privacy Policy')),TextButton(onPressed:()=>showLicensePage(context:context,applicationName:'Kārya',applicationVersion:'1.0.0'),child:const Text('Open-source licenses'))])),NeoCard(child:ListTile(leading:const Icon(Icons.delete_forever),title:const Text('Delete all app data'),subtitle:const Text('Permanently remove tasks, subjects, habit records and reminders.'),onTap:()async{final answer=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Clear everything?'),content:const Text('This cannot be undone. Your task and habit history will be deleted permanently.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Delete all'))]));if(answer!=true)return;await ref.read(appProvider.notifier).change((db)=>db.clearAll());await (await SharedPreferences.getInstance()).clear();await Reminders.instance.sync(await ref.read(dbProvider).snapshot());if(mounted){setState((){notifications=false;defaultTaskReminders=false;defaultHabitReminders=false;});toast(context,'All local records and preferences deleted.');}}))]));}
}
const privacyText='''Kārya Privacy Policy (draft • October 2026)

Kārya stores the tasks, subjects, habits, reminders, and completion history you enter in a local SQLite database on your device. Theme and notification preferences are stored locally. The app does not require an account and does not contain advertising, analytics, trackers, or cloud synchronization. Its rule-based commands work offline. It does not send your content to a Kārya server.

Notification permission is requested only if you choose to enable reminders. You can decline and use the rest of the app. Android may make local app data available to operating-system backup services depending on device configuration and the app's backup settings; this release disables Android cloud and device-transfer backup in its manifest.

Delete all your information within Settings > Delete all app data, or uninstall the app.

For privacy questions, contact the developer via the support contact shown on the Google Play listing (to be provided by the publisher). The publisher must review this draft, add a real contact and public URL, and verify the declarations before release.''';
