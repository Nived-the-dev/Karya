import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/state.dart';
import 'core/notifications.dart';
import 'features/screens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try { await Reminders.instance.initialize(); } catch (_) { /* show app even if notifications unavailable */ }
  runApp(const ProviderScope(child: KaryaApp()));
}

final router = GoRouter(initialLocation:'/',routes:[
  StatefulShellRoute.indexedStack(builder:(context,state,shell)=>AppScaffold(shell:shell),branches:[
    StatefulShellBranch(routes:[GoRoute(path:'/',builder:(context,state)=>const HomeScreen())]),
    StatefulShellBranch(routes:[GoRoute(path:'/tasks',builder:(context,state)=>TasksScreen(initialSubjectId:int.tryParse(state.uri.queryParameters['subject'] ?? '')))]),
    StatefulShellBranch(routes:[GoRoute(path:'/habits',builder:(context,state)=>const HabitsScreen())]),
    StatefulShellBranch(routes:[GoRoute(path:'/progress',builder:(context,state)=>const ProgressScreen())]),
  ]),
  GoRoute(path:'/chat',builder:(context,state)=>const ChatScreen()),
  GoRoute(path:'/settings',builder:(context,state)=>const SettingsScreen()),
]);

class KaryaApp extends ConsumerWidget {
  const KaryaApp({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeProvider).value ?? 'system';
    return MaterialApp.router(title:'Kārya — कार्य',debugShowCheckedModeBanner:false,
      theme:neoTheme(false),darkTheme:neoTheme(true),themeMode:switch(mode){'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system},routerConfig:router);
  }
}
ThemeData neoTheme(bool dark) {
  const ink=Color(0xFF111111); const off=Color(0xFFFFFCF7);
  final surface=dark?const Color(0xFF25242D):off;
  final text=dark?Colors.white:ink;
  return ThemeData(useMaterial3:true,brightness:dark?Brightness.dark:Brightness.light,scaffoldBackgroundColor:dark?const Color(0xFF191820):const Color(0xFFFFD51D),
    colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xFFFFD51D),brightness:dark?Brightness.dark:Brightness.light,surface:surface,primary:dark?const Color(0xFFFFD51D):ink),
    textTheme:TextTheme(headlineLarge:TextStyle(fontSize:34,fontWeight:FontWeight.w900,color:text,letterSpacing:-1.2),headlineMedium:TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:text),titleLarge:TextStyle(fontWeight:FontWeight.w900,color:text),bodyMedium:TextStyle(color:text)),
    appBarTheme:AppBarTheme(backgroundColor:Colors.transparent,foregroundColor:text,centerTitle:false,scrolledUnderElevation:0),
    inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),contentPadding:const EdgeInsets.all(15)),
    snackBarTheme:SnackBarThemeData(backgroundColor:dark?const Color(0xFF494553):ink,contentTextStyle:const TextStyle(color:Colors.white)));
}

class AppScaffold extends StatefulWidget {
  const AppScaffold({super.key,required this.shell});
  final StatefulNavigationShell shell;
  @override State<AppScaffold> createState()=>_AppScaffoldState();
}
class _AppScaffoldState extends State<AppScaffold> {
  @override void initState(){ super.initState(); WidgetsBinding.instance.addPostFrameCallback((_ ) async {
    final prefs=await SharedPreferences.getInstance(); if(!mounted)return;
    if (!(prefs.getBool('onboarded') ?? false)) {
      await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(title:const Text('WELCOME TO KĀRYA ✦'),content:const Text('Less Organising. More Doing.\n\nAdd your homework, create daily habits, and use simple /commands to get moving. Everything stays available offline.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Let’s do this!'))]));
      await prefs.setBool('onboarded',true);
    }
  });}
  @override Widget build(BuildContext context) {
    final labels=['Home','Tasks','Habits','Progress'];
    final icons=[Icons.home_rounded,Icons.check_box_rounded,Icons.auto_awesome_rounded,Icons.bar_chart_rounded];
    return Scaffold(appBar:AppBar(title:const Text('KĀRYA ✦',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),actions:[IconButton(tooltip:'Command assistant',icon:const Icon(Icons.chat_bubble_outline_rounded),onPressed:()=>context.push('/chat')),IconButton(tooltip:'Settings',icon:const Icon(Icons.settings_outlined),onPressed:()=>context.push('/settings'))]),body:widget.shell,
      bottomNavigationBar:SafeArea(top:false,child:Container(margin:const EdgeInsets.fromLTRB(12,0,12,8),decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,border:Border.all(color:Theme.of(context).colorScheme.onSurface,width:2.5),borderRadius:BorderRadius.circular(18),boxShadow:const [BoxShadow(color:Colors.black,offset:Offset(4,4))]),child:Row(children:[for(var i=0;i<4;i++)Expanded(child:InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>widget.shell.goBranch(i),child:Padding(padding:const EdgeInsets.symmetric(vertical:9),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icons[i],color:widget.shell.currentIndex==i?const Color(0xFFFF4C89):Theme.of(context).colorScheme.onSurface),Text(labels[i],style:TextStyle(fontSize:11,fontWeight:widget.shell.currentIndex==i?FontWeight.w900:FontWeight.w600))]))))]))));
  }
}
