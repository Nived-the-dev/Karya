import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karya_app/core/database.dart';
import 'package:karya_app/core/models.dart';
import 'package:karya_app/features/brain_dump.dart';
import 'package:karya_app/features/constellation.dart';

void main() {
  test('Chaos Dump proposes ideas without pretending to be AI', () {
    expect(suggestedKind('Maybe I could make a podcast'), 'Idea');
    expect(suggestedKind('Finish calculus homework'), 'Task');
    expect(splitThoughts('Read notes\n- Maybe create a prototype'),
      ['Read notes', 'Maybe create a prototype']);
  });
  test('Empty constellation contains no invented nodes', () {
    final empty=AppData([],[],[]);
    expect(makeStarMap(empty).nodes,isEmpty);
    expect(makeStarMap(empty,activity:false).nodes,isEmpty);
  });
  group('Kārya 3 persistence and private sync snapshots', () {
    late KaryaDatabase db;
    setUp(()=>db=KaryaDatabase.test(NativeDatabase.memory()));
    tearDown(() async=>db.close());
    test('Goals and explicit links save and deletion unlinks', () async {
      final g=await db.saveGoal(title:'Become fluent in German');
      final t=await db.saveTask(title:'Revise 10 new words');
      await db.addLink('goal',g,'task',t);
      await db.addLink('goal',g,'task',t);
      var state=await db.snapshot();
      expect(state.goals.single.title,'Become fluent in German');
      expect(state.links.length,1);
      await db.deleteTask(t);
      state=await db.snapshot();
      expect(state.links,isEmpty);
      await db.clearAll();
      expect((await db.snapshot()).goals,isEmpty);
    });
    test('Full SQLite snapshot round trip retains subjects and links',() async {
      final subject=await db.saveSubject(name:'Biology',color:2,icon:0);
      final task=await db.saveTask(title:'Cells',subjectId:subject);
      final goal=await db.saveGoal(title:'Ace biology');
      await db.addLink('goal',goal,'task',task);
      await db.saveIdea(body:'Build a biology mind map');
      final original=await db.syncSnapshot();
      final target=KaryaDatabase.test(NativeDatabase.memory());
      try{
        await target.restoreSnapshot(original);
        expect(await target.syncSnapshot(),original);
        final snapshot=await target.snapshot();
        expect(snapshot.tasks.single.subjectId,subject);
        expect(snapshot.links.single.toId,task);
      }finally{await target.close();}
    });
    test('Malformed sync snapshot cannot erase original records',() async {
      await db.saveTask(title:'Must remain safe');
      final invalid=await db.syncSnapshot();
      invalid.remove('tasks');
      await expectLater(db.restoreSnapshot(invalid),throwsFormatException);
      expect((await db.snapshot()).tasks.single.title,'Must remain safe');
    });
  });
}
