import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:karya_app/core/database.dart';
import 'package:karya_app/core/models.dart';
import 'package:karya_app/core/progression.dart';

void main(){
 test('Fourteen exponentially spaced rank thresholds and one-year minimum',(){
  expect(rankNames.length,14);
  expect(rankNames.take(6),['Bronze','Silver','Gold','Platinum','Diamond','Olympian']);
  for(var i=1;i<rankPoints.length;i++)expect(rankPoints[i],greaterThan(rankPoints[i-1]));
  expect(rankDays.last,365);
  final sample=AppData([],[],[],const [],const [],
    const ProgressionInfo(0,0,'2026-01-01',''),
    const PointsBreakdown(tasks:7000,habits:0,weeks:0,goals:0));
  expect(rankFor(sample,today:DateTime(2026,12,31)).readyToPrestige,false);
  expect(rankFor(sample,today:DateTime(2027,1,1)).readyToPrestige,true);
 });
 test('Full consecutive weeks give bonuses without penalizing breaks',(){
  expect(fullWeeks({'2026-10-01','2026-10-02'}),0);
  expect(fullWeeks({for(var i=1;i<=7;i++)'2026-10-${i.toString().padLeft(2,'0')}'}),1);
  expect(fullWeeks({for(var i=1;i<=14;i++)'2026-10-${i.toString().padLeft(2,'0')}'}),2);
 });
 group('Durable earned points',(){
  late KaryaDatabase db;
  setUp(()=>db=KaryaDatabase.test(NativeDatabase.memory()));
  tearDown(() async=>db.close());
  test('Two points per task, no reward farming after reopening',()async{
    final task=await db.saveTask(title:'Finish calculus');
    await db.setTaskDone(task,true);
    expect(pointsFor(await db.snapshot()).tasks,2);
    await db.setTaskDone(task,false);
    await db.setTaskDone(task,true);
    await db.setTaskDone(task,true);
    expect(pointsFor(await db.snapshot()).tasks,2);
    await db.deleteTask(task);
    expect(pointsFor(await db.snapshot()).tasks,2);
  });
  test('Four points per habit day, once per actual day',()async{
    final id=await db.saveHabit(name:'Read',days:127);
    final h=(await db.snapshot()).habits.single;
    await db.setHabitDone(h,DateTime.now(),true);
    await db.setHabitDone(h,DateTime.now(),true);
    expect(pointsFor(await db.snapshot()).habits,4);
  });
  test('Major goal gives fifteen points once',()async{
    final goal=await db.saveGoal(title:'Make an app',done:true);
    await db.saveGoal(id:goal,title:'Make an app',done:false);
    await db.saveGoal(id:goal,title:'Make an app',done:true);
    expect(pointsFor(await db.snapshot()).goals,15);
  });
  test('Sync snapshot includes rank history and rewards',()async{
    final goal=await db.saveGoal(title:'Pass exam',done:true);
    expect(goal,greaterThan(0));
    final source=await db.syncSnapshot();
    expect(source['version'],4);
    expect(source['rewards'],isNotEmpty);
    final target=KaryaDatabase.test(NativeDatabase.memory());
    try{
      await target.restoreSnapshot(source);
      expect(pointsFor(await target.snapshot()).total,15);
    }finally{await target.close();}
  });
 });
}
