import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'models.dart';
import 'progression.dart';

/// SQL deliberately kept in one place; Drift handles connections and transactions.
/// No code generation is needed to build this project.
class KaryaDatabase extends GeneratedDatabase {
  KaryaDatabase() : super(LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    return NativeDatabase.createInBackground(File(p.join(dir.path, 'karya.sqlite')));
  }));

  KaryaDatabase.test(QueryExecutor executor) : super(executor);

  @override
  Iterable<TableInfo<Table, dynamic>> get allTables => const [];
  @override
  int get schemaVersion => 4;
  @override
  MigrationStrategy get migration => MigrationStrategy(onUpgrade:(m,from,to) async {
    if (from < 2) await customStatement('CREATE TABLE IF NOT EXISTS ideas (id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, pinned INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL)');
    if (from < 3) {
      await customStatement(goalSql);
      await customStatement(linkSql);
    }
    if (from < 4) {
      await customStatement(progressionSql);
      await customStatement(rewardsSql);
      await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) SELECT 'task',id,substr(completed_at,1,10),2 FROM tasks WHERE completed_at IS NOT NULL");
      await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) SELECT 'habit',habit_id,day,4 FROM habit_logs");
      await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) SELECT 'goal',id,substr(COALESCE(target_day,date('now')),1,10),15 FROM goals WHERE done=1");
    }
  }, onCreate: (m) async {
    await customStatement('PRAGMA foreign_keys = ON');
    for (final sql in schema) { await customStatement(sql); }
  }, beforeOpen: (details) async {
    await customStatement('PRAGMA foreign_keys = ON');
  });

  static const goalSql = '''CREATE TABLE IF NOT EXISTS goals (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', target_day TEXT, done INTEGER NOT NULL DEFAULT 0)''';
  static const linkSql = '''CREATE TABLE IF NOT EXISTS entity_links (id INTEGER PRIMARY KEY AUTOINCREMENT, from_type TEXT NOT NULL, from_id INTEGER NOT NULL, to_type TEXT NOT NULL, to_id INTEGER NOT NULL, UNIQUE(from_type, from_id, to_type, to_id))''';
  static const progressionSql = '''CREATE TABLE IF NOT EXISTS progression (id INTEGER PRIMARY KEY CHECK(id=1), prestige INTEGER NOT NULL DEFAULT 0, baseline INTEGER NOT NULL DEFAULT 0, started_day TEXT NOT NULL, prestige_day TEXT NOT NULL DEFAULT '')''';
  static const rewardsSql = '''CREATE TABLE IF NOT EXISTS rewards (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, entity_id INTEGER NOT NULL, event_day TEXT NOT NULL, points INTEGER NOT NULL, UNIQUE(kind,entity_id,event_day))''';
  static const schema = <String>[
    rewardsSql,
    progressionSql,
    goalSql,
    linkSql,
    '''CREATE TABLE ideas (id INTEGER PRIMARY KEY AUTOINCREMENT, body TEXT NOT NULL, pinned INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL)''',
    '''CREATE TABLE subjects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE, color INTEGER NOT NULL DEFAULT 0, icon INTEGER NOT NULL DEFAULT 0)''',
    '''CREATE TABLE tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL, priority TEXT NOT NULL CHECK(priority IN ('low','medium','high')), due_at TEXT, reminder_at TEXT, created_at TEXT NOT NULL, completed_at TEXT)''',
    '''CREATE INDEX idx_task_due ON tasks(due_at, completed_at)''',
    '''CREATE INDEX idx_task_subject ON tasks(subject_id)''',
    '''CREATE TABLE subtasks (id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0)''',
    '''CREATE INDEX idx_subtasks_parent ON subtasks(task_id)''',
    '''CREATE TABLE habits (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', icon INTEGER NOT NULL DEFAULT 0, color INTEGER NOT NULL DEFAULT 0, reminder TEXT, created_day TEXT NOT NULL, archived_day TEXT)''',
    '''CREATE TABLE habit_schedules (habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE, from_day TEXT NOT NULL, days INTEGER NOT NULL CHECK(days BETWEEN 1 AND 127), PRIMARY KEY(habit_id, from_day))''',
    '''CREATE TABLE habit_logs (habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE, day TEXT NOT NULL, PRIMARY KEY(habit_id, day))''',
    '''CREATE INDEX idx_habit_logs_day ON habit_logs(day)''',
    '''CREATE TABLE habit_status (habit_id INTEGER NOT NULL REFERENCES habits(id) ON DELETE CASCADE, day TEXT NOT NULL, active INTEGER NOT NULL CHECK(active IN (0,1)), PRIMARY KEY(habit_id,day))''',
  ];
  Future<AppData> snapshot() async {
    await customStatement('INSERT OR IGNORE INTO progression(id,started_day) VALUES(1,?)',[dayKey(DateTime.now())]);
    final subjects = (await customSelect('SELECT * FROM subjects ORDER BY name COLLATE NOCASE').get()).map((r) => Subject(r.read<int>('id'),r.read<String>('name'),r.read<int>('color'),r.read<int>('icon'))).toList();
    final subrows = await customSelect('SELECT * FROM subtasks ORDER BY id').get();
    final subMap = <int, List<Subtask>>{};
    for (final r in subrows) {
      final s = Subtask(r.read<int>('id'),r.read<int>('task_id'),r.read<String>('title'),r.read<int>('done') == 1);
      subMap.putIfAbsent(s.taskId, () => []).add(s);
    }
    final tasks = (await customSelect('SELECT * FROM tasks ORDER BY CASE WHEN completed_at IS NULL THEN 0 ELSE 1 END, CASE WHEN due_at IS NULL THEN 1 ELSE 0 END, due_at, id DESC').get()).map((r) {
      final id = r.read<int>('id');
      return Task(id:id, title:r.read<String>('title'),description:r.read<String>('description'),subjectId:r.readNullable<int>('subject_id'),priority:r.read<String>('priority'),dueAt:r.readNullable<String>('due_at'),reminderAt:r.readNullable<String>('reminder_at'),createdAt:r.read<String>('created_at'),completedAt:r.readNullable<String>('completed_at'),subtasks:subMap[id] ?? []);
    }).toList();
    final revisions = <int,List<ScheduleRevision>>{};
    for (final r in await customSelect('SELECT * FROM habit_schedules ORDER BY from_day ASC').get()) {
      revisions.putIfAbsent(r.read<int>('habit_id'), () => []).add(ScheduleRevision(r.read<String>('from_day'),r.read<int>('days')));
    }
    final logs = <int,Set<String>>{};
    for (final r in await customSelect('SELECT * FROM habit_logs').get()) {
      logs.putIfAbsent(r.read<int>('habit_id'), () => {}).add(r.read<String>('day'));
    }
    final statuses = <int,Map<String,bool>>{};
    for (final r in await customSelect('SELECT * FROM habit_status ORDER BY day ASC').get()) {
      statuses.putIfAbsent(r.read<int>('habit_id'), () => {})[r.read<String>('day')] = r.read<int>('active') == 1;
    }
    final habits = (await customSelect('SELECT * FROM habits ORDER BY archived_day IS NOT NULL, id DESC').get()).map((r) {
      final id = r.read<int>('id');
      return Habit(id:id,name:r.read<String>('name'),description:r.read<String>('description'),icon:r.read<int>('icon'),color:r.read<int>('color'),reminder:r.readNullable<String>('reminder'),createdDay:r.read<String>('created_day'),archivedDay:r.readNullable<String>('archived_day'),revisions:revisions[id] ?? [],logs:logs[id] ?? {},statusChanges:statuses[id] ?? {});
    }).toList();
    final goals = (await customSelect('SELECT * FROM goals ORDER BY done, id DESC').get())
        .map((r) => KaryaGoal(r.read<int>('id'), r.read<String>('title'),
            r.read<String>('description'), r.readNullable<String>('target_day'),
            r.read<int>('done') == 1)).toList();
    final links = (await customSelect('SELECT * FROM entity_links ORDER BY id').get())
        .map((r) => KaryaLink(r.read<int>('id'), r.read<String>('from_type'),
            r.read<int>('from_id'), r.read<String>('to_type'), r.read<int>('to_id'))).toList();
    final p=await customSelect('SELECT prestige,baseline,started_day,prestige_day FROM progression WHERE id=1').getSingle();
    final progress=ProgressionInfo(p.read<int>('prestige'),p.read<int>('baseline'),p.read<String>('started_day'),p.read<String>('prestige_day'));
    final earned=await customSelect('SELECT kind,COALESCE(SUM(points),0) AS total FROM rewards GROUP BY kind').get();
    int forKind(String kind){for(final row in earned){if(row.read<String>('kind')==kind)return row.read<int>('total');}return 0;}
    final breakdown=PointsBreakdown(tasks:forKind('task'),habits:forKind('habit'),weeks:forKind('week'),goals:forKind('goal'));
    return AppData(tasks, subjects, habits, goals, links, progress, breakdown);
  }
  Future<int> saveSubject({int? id, required String name, required int color, required int icon}) async {
    final clean = name.trim();
    if (clean.isEmpty) throw ArgumentError('Subject name cannot be empty.');
    if (id == null) return customInsert('INSERT INTO subjects(name,color,icon) VALUES(?,?,?)', variables:[Variable.withString(clean),Variable.withInt(color),Variable.withInt(icon)]);
    await customUpdate('UPDATE subjects SET name=?,color=?,icon=? WHERE id=?',variables:[Variable.withString(clean),Variable.withInt(color),Variable.withInt(icon),Variable.withInt(id)]);
    return id;
  }
  Future<void> deleteSubject(int id) async { await unlinkEntity('subject',id); await customStatement('DELETE FROM subjects WHERE id=?', [id]); }
  Future<int> saveTask({int? id, required String title, String description = '', int? subjectId, String priority = 'medium', String? dueAt, String? reminderAt}) async {
    final clean = title.trim();
    if (clean.isEmpty || clean.length > 180) throw ArgumentError('Task title must contain 1–180 characters.');
    final values = [Variable.withString(clean),Variable.withString(description.trim()), subjectId == null ? const Variable<int>(null) : Variable.withInt(subjectId),Variable.withString(priority),dueAt == null ? const Variable<String>(null) : Variable.withString(dueAt),reminderAt == null ? const Variable<String>(null) : Variable.withString(reminderAt)];
    if (id == null) {
      return customInsert('INSERT INTO tasks(title,description,subject_id,priority,due_at,reminder_at,created_at) VALUES(?,?,?,?,?,?,?)',variables:[...values,Variable.withString(DateTime.now().toIso8601String())]);
    }
    await customUpdate('UPDATE tasks SET title=?,description=?,subject_id=?,priority=?,due_at=?,reminder_at=? WHERE id=?',variables:[...values,Variable.withInt(id)]);
    return id;
  }
  Future<void> setTaskDone(int id, bool done) async {
    await transaction(() async {
      final before=await customSelect('SELECT completed_at FROM tasks WHERE id=?',variables:[Variable.withInt(id)]).getSingleOrNull();
      if(before==null)return;
      if(done&&before.readNullable<String>('completed_at')==null){
        await customStatement('UPDATE tasks SET completed_at=? WHERE id=?',[DateTime.now().toIso8601String(),id]);
        final has=await customSelect("SELECT 1 FROM rewards WHERE kind='task' AND entity_id=? LIMIT 1",variables:[Variable.withInt(id)]).getSingleOrNull();
        if(has==null)await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) VALUES('task',?,?,2)",[id,dayKey(DateTime.now())]);
      }else if(!done){await customStatement('UPDATE tasks SET completed_at=NULL WHERE id=?',[id]);}
    });
  }
  Future<void> deleteTask(int id) async { await unlinkEntity('task',id); await customStatement('DELETE FROM tasks WHERE id=?',[id]); }
  Future<int> duplicateTask(Task task) async {
    return transaction(() async {
      final newId = await saveTask(title:'${task.title} (copy)',description:task.description,subjectId:task.subjectId,priority:task.priority,dueAt:task.dueAt,reminderAt:null);
      for (final sub in task.subtasks) { await addSubtask(newId,sub.title); }
      return newId;
    });
  }
  Future<int> addSubtask(int taskId, String title) => customInsert('INSERT INTO subtasks(task_id,title) VALUES(?,?)',variables:[Variable.withInt(taskId),Variable.withString(title.trim())]);
  Future<void> setSubtaskDone(int id, bool done) => customStatement('UPDATE subtasks SET done=? WHERE id=?',[done ? 1 : 0,id]);
  Future<void> deleteSubtask(int id) => customStatement('DELETE FROM subtasks WHERE id=?',[id]);
  Future<int> saveHabit({int? id,required String name,String description = '',required int days,int icon = 0,int color = 0,String? reminder}) async {
    if (name.trim().isEmpty) throw ArgumentError('Give your habit a name.');
    if (days < 1 || days > 127) throw ArgumentError('Select at least one day.');
    final today = dayKey(DateTime.now());
    return transaction(() async {
      late final int habitId;
      if (id == null) {
        habitId = await customInsert('INSERT INTO habits(name,description,icon,color,reminder,created_day) VALUES(?,?,?,?,?,?)', variables:[Variable.withString(name.trim()),Variable.withString(description.trim()),Variable.withInt(icon),Variable.withInt(color),reminder == null ? const Variable<String>(null) : Variable.withString(reminder),Variable.withString(today)]);
      } else {
        habitId = id;
        await customUpdate('UPDATE habits SET name=?,description=?,icon=?,color=?,reminder=? WHERE id=?',variables:[Variable.withString(name.trim()),Variable.withString(description.trim()),Variable.withInt(icon),Variable.withInt(color),reminder == null ? const Variable<String>(null) : Variable.withString(reminder),Variable.withInt(id)]);
      }
      final existing = await customSelect('SELECT days FROM habit_schedules WHERE habit_id=? AND from_day<=? ORDER BY from_day DESC LIMIT 1',variables:[Variable.withInt(habitId),Variable.withString(today)]).getSingleOrNull();
      if (existing == null || existing.read<int>('days') != days) {
        await customStatement('INSERT INTO habit_schedules(habit_id,from_day,days) VALUES(?,?,?) ON CONFLICT(habit_id,from_day) DO UPDATE SET days=excluded.days',[habitId,today,days]);
      }
      return habitId;
    });
  }
  Future<void> setHabitDone(Habit habit, DateTime day, bool done) async {
    if (!habit.scheduledOn(day)) throw ArgumentError('This habit is not scheduled for that date.');
    if (done) { await transaction(() async {
      final date=dayKey(day);
      await customStatement('INSERT OR IGNORE INTO habit_logs(habit_id,day) VALUES(?,?)',[habit.id,date]);
      await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) VALUES('habit',?,?,4)",[habit.id,date]);
      final rows=await customSelect('SELECT day FROM habit_logs WHERE habit_id=? ORDER BY day',variables:[Variable.withInt(habit.id)]).get();
      var consecutive=0;
      DateTime? previous;
      for(final row in rows){
        final checkedDay=DateTime.tryParse(row.read<String>('day'));
        if(checkedDay==null)continue;
        consecutive=previous!=null&&checkedDay.difference(previous).inDays==1?consecutive+1:1;
        if(consecutive%7==0){
          await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) VALUES('week',?,?,8)",
            [habit.id,dayKey(checkedDay)]);
        }
        previous=checkedDay;
      }
    }); }
    else { await customStatement('DELETE FROM habit_logs WHERE habit_id=? AND day=?',[habit.id,dayKey(day)]); }
  }
  Future<void> archiveHabit(int id, bool archive) async {
    final day=dayKey(DateTime.now());
    await transaction(() async {
      await customStatement('UPDATE habits SET archived_day=? WHERE id=?',[archive?day:null,id]);
      await customStatement('INSERT INTO habit_status(habit_id,day,active) VALUES(?,?,?) ON CONFLICT(habit_id,day) DO UPDATE SET active=excluded.active',[id,day,archive?0:1]);
    });
  }
  Future<void> deleteHabit(int id) async { await unlinkEntity('habit',id); await customStatement('DELETE FROM habits WHERE id=?',[id]); }
  Future<List<Idea>> loadIdeas() async => (await customSelect('SELECT * FROM ideas ORDER BY pinned DESC, updated_at DESC').get()).map((r)=>Idea(r.read<int>('id'),r.read<String>('body'),r.read<int>('pinned')==1)).toList();
  Future<int> saveIdea({int? id,required String body,bool pinned=false}) async {
    if(body.trim().isEmpty) throw ArgumentError('Write something first.');
    final date=DateTime.now().toIso8601String();
    if(id==null)return customInsert('INSERT INTO ideas(body,pinned,updated_at) VALUES(?,?,?)',variables:[Variable.withString(body.trim()),Variable.withInt(pinned?1:0),Variable.withString(date)]);
    await customUpdate('UPDATE ideas SET body=?,pinned=?,updated_at=? WHERE id=?',variables:[Variable.withString(body.trim()),Variable.withInt(pinned?1:0),Variable.withString(date),Variable.withInt(id)]);
    return id;
  }
  Future<void> removeIdea(int id) async { await unlinkEntity('idea',id); await customStatement('DELETE FROM ideas WHERE id=?',[id]); }
  Future<int> saveGoal({int? id, required String title, String description = '',
      String? targetDay, bool done = false}) async {
    final name = title.trim();
    if (name.isEmpty || name.length > 180) throw ArgumentError('Give your goal a short title.');
    if (id == null) {
      final id=await customInsert('INSERT INTO goals(title,description,target_day,done) VALUES(?,?,?,?)',
        variables: [Variable.withString(name), Variable.withString(description.trim()),
          Variable<String>(targetDay), Variable.withInt(done ? 1 : 0)]);
      if(done)await _rewardGoal(id);
      return id;
    }
    await customStatement('UPDATE goals SET title=?,description=?,target_day=?,done=? WHERE id=?',
      [name, description.trim(), targetDay, done ? 1 : 0, id]);
    if(done)await _rewardGoal(id);
    return id;
  }
  Future<void> _rewardGoal(int id) async {
    final has=await customSelect("SELECT 1 FROM rewards WHERE kind='goal' AND entity_id=? LIMIT 1",variables:[Variable.withInt(id)]).getSingleOrNull();
    if(has==null)await customStatement("INSERT OR IGNORE INTO rewards(kind,entity_id,event_day,points) VALUES('goal',?,?,15)",[id,dayKey(DateTime.now())]);
  }
  Future<void> deleteGoal(int id) async { await unlinkEntity('goal',id); await customStatement('DELETE FROM goals WHERE id=?',[id]); }
  Future<void> unlinkEntity(String type,int id) => customStatement(
    'DELETE FROM entity_links WHERE (from_type=? AND from_id=?) OR (to_type=? AND to_id=?)',
    [type,id,type,id]);
  Future<void> addLink(String fromType,int fromId,String toType,int toId) async {
    const allowed={'task','habit','idea','goal','subject'};
    if(!allowed.contains(fromType)||!allowed.contains(toType))throw ArgumentError('Invalid link type');
    if(fromType==toType&&fromId==toId)return;
    await customStatement('INSERT OR IGNORE INTO entity_links(from_type,from_id,to_type,to_id) VALUES(?,?,?,?)',
      [fromType,fromId,toType,toId]);
  }
  Future<void> removeLink(int id)=>customStatement('DELETE FROM entity_links WHERE id=?',[id]);

  Future<void> prestige({required int score}) async {
    final record=await snapshot();
    if(!rankFor(record).readyToPrestige)throw StateError('Complete the final rank first.');
    await customStatement('UPDATE progression SET prestige=prestige+1,baseline=?,prestige_day=? WHERE id=1', [score, dayKey(DateTime.now())]);
  }

  /// Snapshot used only by paired local-network devices, never a public export feature.
  static const syncTables = <String, List<String>>{
    'subjects': ['id','name','color','icon'],
    'tasks': ['id','title','description','subject_id','priority','due_at','reminder_at','created_at','completed_at'],
    'subtasks': ['id','task_id','title','done'],
    'habits': ['id','name','description','icon','color','reminder','created_day','archived_day'],
    'habit_schedules': ['habit_id','from_day','days'],
    'habit_logs': ['habit_id','day'],
    'habit_status': ['habit_id','day','active'],
    'ideas': ['id','body','pinned','updated_at'],
    'goals': ['id','title','description','target_day','done'],
    'progression': ['id','prestige','baseline','started_day','prestige_day'],
    'rewards': ['id','kind','entity_id','event_day','points'],
    'entity_links': ['id','from_type','from_id','to_type','to_id'],
  };
  Future<Map<String,dynamic>> syncSnapshot() async {
    await customStatement('INSERT OR IGNORE INTO progression(id,started_day) VALUES(1,?)',[dayKey(DateTime.now())]);
    final out=<String,dynamic>{'version':4};
    for(final table in syncTables.keys){
      final order = syncTables[table]!.first;
      out[table]=(await customSelect('SELECT * FROM $table ORDER BY $order').get())
        .map((r)=>Map<String,dynamic>.from(r.data)).toList();
    }
    return out;
  }
  Future<void> restoreSnapshot(Map<String,dynamic> snapshot) async {
    if(snapshot['version']!=4)throw const FormatException('Incompatible sync version');
    // Validate all rows and keys before modifying any local data.
    final parsed=<String,List<Map<String,dynamic>>>{};
    for(final entry in syncTables.entries){
      final rows=snapshot[entry.key];
      if(rows is! List || rows.length>100000)throw const FormatException('Invalid sync collection');
      parsed[entry.key]=[];
      for(final row in rows){
        if(row is! Map)throw const FormatException('Invalid sync row');
        final record=Map<String,dynamic>.from(row);
        if(record.keys.any((k)=>!entry.value.contains(k)) || record.keys.length!=entry.value.length)
          throw const FormatException('Invalid sync columns');
        if(record.values.any((v)=>v!=null&&v is! String&&v is! int&&v is! double))
          throw const FormatException('Invalid sync value');
        parsed[entry.key]!.add(record);
      }
    }
    await transaction(() async {
      for(final table in syncTables.keys.toList().reversed){ await customStatement('DELETE FROM $table'); }
      for(final entry in syncTables.entries){
        final columns=entry.value;
        final marks=List.filled(columns.length,'?').join(',');
        for(final row in parsed[entry.key]!){
          await customStatement('INSERT INTO ${entry.key}(${columns.join(',')}) VALUES($marks)',
            columns.map((k)=>row[k]).toList());
        }
      }
    });
  }
  Future<void> clearAll() async {
    await transaction(() async {
      await customStatement('DELETE FROM habit_logs');
      await customStatement('DELETE FROM habit_schedules');
      await customStatement('DELETE FROM habit_status');
      await customStatement('DELETE FROM habits');
      await customStatement('DELETE FROM subtasks');
      await customStatement('DELETE FROM tasks');
      await customStatement('DELETE FROM subjects');
      await customStatement('DELETE FROM ideas');
      await customStatement('DELETE FROM entity_links');
      await customStatement('DELETE FROM goals');
      await customStatement('DELETE FROM progression');
      await customStatement('DELETE FROM rewards');
    });
  }
}
