import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class NeoCard extends StatefulWidget {
  const NeoCard({super.key, required this.child, this.color,
    this.padding=const EdgeInsets.all(16), this.onTap});
  final Widget child;
  final Color? color;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  @override State<NeoCard> createState()=>_NeoCardState();
}
class _NeoCardState extends State<NeoCard> {
  bool pressed=false;
  bool hovering=false;
  @override Widget build(BuildContext context){
    final dark=Theme.of(context).brightness==Brightness.dark;
    final colors=Theme.of(context).extension<NeoAccents>()?.colors;
    final index=widget.color==null?-1:palette.indexOf(widget.color!);
    final c=index>=0&&colors!=null?colors[index%colors.length]:
      (widget.color??Theme.of(context).colorScheme.surface);
    final ink=dark?const Color(0xFF707070):const Color(0xFF111111);
    return MouseRegion(
      onEnter:(_){if(mounted)setState(()=>hovering=true);},
      onExit:(_){if(mounted)setState(()=>hovering=false);},
      child:TweenAnimationBuilder<double>(tween:Tween(begin:0.96,end:1),
      duration:const Duration(milliseconds:260),curve:Curves.easeOutCubic,
      builder:(context,entry,child)=>Transform.scale(scale:entry,child:child),
      child:AnimatedContainer(
      duration:const Duration(milliseconds:180),
      curve:Curves.easeOutCubic,
      margin:const EdgeInsets.only(bottom:12,right:5),
      transform:Matrix4.translationValues(pressed?3:(hovering?-2:0),pressed?3:(hovering?-2:0),0),
      decoration:BoxDecoration(color:c,borderRadius:BorderRadius.circular(16),
        border:Border.all(color:ink,width:2.2),
        boxShadow:[BoxShadow(color:dark?const Color(0xFF353535):Colors.black,
          offset:Offset(pressed?1:4,pressed?1:4))]),
      child:Material(color:Colors.transparent,child:InkWell(
        borderRadius:BorderRadius.circular(15),
        onTapDown:widget.onTap==null?null:(_)=>setState(()=>pressed=true),
        onTapCancel:()=>setState(()=>pressed=false),
        onTapUp:(_)=>setState(()=>pressed=false),
        onTap:widget.onTap==null?null:(){
          widget.onTap?.call();
          SharedPreferences.getInstance().then((prefs){
            if(prefs.getBool('haptics')??true)HapticFeedback.selectionClick();
          });
        },
        child:Padding(padding:widget.padding,child:widget.child),
      )),
    )));
  }
}
class NeoButton extends StatelessWidget {
  const NeoButton({super.key,required this.label,required this.onPressed,this.icon,this.color});
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final Color? color;
  @override Widget build(BuildContext context)=>NeoCard(
    color:color??colorFor(2),padding:EdgeInsets.zero,onTap:onPressed,
    child:Padding(padding:const EdgeInsets.symmetric(horizontal:13,vertical:12),
      child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        if(icon!=null)...[Icon(icon,color:Colors.black,size:19),const SizedBox(width:7)],
        Flexible(child:Text(label,maxLines:2,overflow:TextOverflow.ellipsis,
          textAlign:TextAlign.center,style:const TextStyle(
            fontWeight:FontWeight.w900,color:Colors.black))),
      ])));
}
class ScreenBody extends ConsumerWidget {
  const ScreenBody({super.key,required this.children});
  final List<Widget> children;
  @override Widget build(BuildContext context,WidgetRef ref){
    final layout=ref.watch(layoutProvider).value??'Comfort';
    final maxWidth=switch(layout){'Studio'=>1380.0,'Compact'=>840.0,_=>1160.0};
    final spacing=layout=='Compact'?10.0:layout=='Studio'?22.0:16.0;
    return Center(child:ConstrainedBox(constraints:BoxConstraints(maxWidth:maxWidth),
      child:ListView(padding:EdgeInsets.fromLTRB(spacing,18,spacing,35),children:children)));
  }
}
class Headline extends StatelessWidget {
  const Headline(this.heading,this.subtitle,{super.key});
  final String heading,subtitle;
  @override Widget build(BuildContext context)=>Padding(
    padding:const EdgeInsets.only(bottom:20),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(heading,style:Theme.of(context).textTheme.headlineLarge),
      const SizedBox(height:5),
      Text(subtitle,style:const TextStyle(fontWeight:FontWeight.w600)),
    ]));
}
class EmptyState extends StatelessWidget {
  const EmptyState(this.title,this.subtitle,{super.key,this.icon=Icons.inbox_outlined});
  final String title,subtitle;
  final IconData icon;
  @override Widget build(BuildContext context)=>NeoCard(child:Padding(
    padding:const EdgeInsets.all(14),
    child:Column(children:[Icon(icon,size:40),const SizedBox(height:10),
      Text(title,textAlign:TextAlign.center,style:Theme.of(context).textTheme.titleLarge),
      Text(subtitle,textAlign:TextAlign.center)])));
}
Future<bool> confirmDelete(BuildContext context,String what) async =>
  await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
    title:Text('Delete $what?'),
    content:const Text('This permanently deletes the selected item and its history.'),
    actions:[
      TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
      TextButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Delete')),
    ]))??false;
void toast(BuildContext context,String text){
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text)));
}
class NeoAccents extends ThemeExtension<NeoAccents> {
  const NeoAccents(this.colors);
  final List<Color> colors;
  @override NeoAccents copyWith({List<Color>? colors})=>NeoAccents(colors??this.colors);
  @override NeoAccents lerp(ThemeExtension<NeoAccents>? other,double t)=>
    t<.5?this:(other??this) as NeoAccents;
}
