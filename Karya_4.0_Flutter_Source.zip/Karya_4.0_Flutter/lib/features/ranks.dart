import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/progression.dart';
import '../core/state.dart';
import 'neo.dart';

class RanksScreen extends ConsumerWidget {
  const RanksScreen({super.key});
  @override Widget build(BuildContext context,WidgetRef ref)=>Scaffold(
    appBar:AppBar(title:const Text('YOUR JOURNEY ✦')),
    body:ref.watch(appProvider).when(
      loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('$e')),
      data:(data){
        final totals=pointsFor(data),rank=rankFor(data);
        return ScreenBody(children:[
          const Headline('EVERY LITTLE THING COUNTS.',
            'Your progress is yours. No penalties for breaks, no comparison with others.'),
          NeoCard(color:colorFor(3),child:Column(crossAxisAlignment:CrossAxisAlignment.start,
            children:[
              Text('${rankIcons[rank.index]} ${rank.name.toUpperCase()}',
                style:const TextStyle(color:Colors.black,fontSize:26,fontWeight:FontWeight.w900)),
              Text('Prestige ${data.progression.prestige} • ${rank.points} points this cycle',
                style:const TextStyle(color:Colors.black)),
              const SizedBox(height:15),LinearProgressIndicator(value:rank.fraction,minHeight:9,
                backgroundColor:Colors.black12,color:Colors.black),
              const SizedBox(height:7),
              Text(rank.readyToPrestige?'Final rank unlocked!':'Next: ${rankNames[rank.index+1]} • ${rankPoints[rank.index+1]} pts / ${rankDays[rank.index+1]} days',
                style:const TextStyle(color:Colors.black,fontWeight:FontWeight.w700)),
            ])),
          NeoCard(child:Wrap(spacing:14,runSpacing:12,children:[
            _Points('Tasks',totals.tasks,'2 pts each'),
            _Points('Habits',totals.habits,'4 pts / day'),
            _Points('Weekly runs',totals.weeks,'8 pts / 7 days'),
            _Points('Major goals',totals.goals,'15 pts each'),
          ])),
          if(rank.readyToPrestige)NeoButton(label:'PRESTIGE ✦ KEEP YOUR WORK, START A NEW JOURNEY',
            icon:Icons.auto_awesome,onPressed:()async{
              final accept=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
                title:const Text('Begin another journey?'),
                content:const Text('Your tasks, habits, notes and lifetime achievements remain safe. Only the rank cycle restarts with a new Prestige badge.'),
                actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Not now')),
                  FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Prestige'))]));
              if(accept==true){await ref.read(appProvider.notifier).change((db)=>db.prestige(score:totals.total));}
            }),
          Text('THE RANK MAP',style:Theme.of(context).textTheme.titleLarge),
          const Text('Rank points rise geometrically. Ranks also require real time; the final rank takes at least 365 days. Consistency is celebrated, not demanded.'),
          const SizedBox(height:12),
          for(var i=0;i<rankNames.length;i++)_RankStep(
            index:i,current:rank.index,cyclePoints:rank.points,days:rank.days),
          const SizedBox(height:30),
        ]);
      }),
  );
}
class _Points extends StatelessWidget {
  const _Points(this.name,this.value,this.detail);
  final String name,detail;final int value;
  @override Widget build(BuildContext context)=>SizedBox(width:145,child:Column(
    crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('$value',style:Theme.of(context).textTheme.headlineMedium),Text(name,style:const TextStyle(fontWeight:FontWeight.w800)),
    Text(detail,style:Theme.of(context).textTheme.bodySmall)]));
}
class _RankStep extends StatelessWidget {
  const _RankStep({required this.index,required this.current,required this.cyclePoints,required this.days});
  final int index,current,cyclePoints,days;
  @override Widget build(BuildContext context){
    final unlocked=index<=current;
    final active=index==current;
    return Padding(padding:const EdgeInsets.only(bottom:5),child:Row(children:[
      Column(children:[CircleAvatar(radius:22,backgroundColor:unlocked?Theme.of(context).colorScheme.primary:Theme.of(context).colorScheme.surface,
        child:Text(rankIcons[index],style:TextStyle(fontSize:unlocked?22:17,color:Colors.grey))),
        Container(width:2,height:20,color:Theme.of(context).colorScheme.outline)]),
      const SizedBox(width:12),Expanded(child:Container(padding:const EdgeInsets.all(12),
        decoration:BoxDecoration(color:active?Theme.of(context).colorScheme.surface:null,
          borderRadius:BorderRadius.circular(10),border:active?Border.all(color:Theme.of(context).colorScheme.outline):null),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(rankNames[index],style:TextStyle(fontWeight:FontWeight.w900,color:unlocked?null:Theme.of(context).disabledColor)),
          Text('${rankPoints[index]} points • ${rankDays[index]} days',style:Theme.of(context).textTheme.bodySmall),
        ]))),
      Icon(unlocked?Icons.check_circle:Icons.lock_outline,size:19,color:unlocked?Theme.of(context).colorScheme.primary:Theme.of(context).disabledColor),
    ]));
  }
}
