import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'goals.dart';
import 'ideas.dart';
import 'tasks.dart';

class _FlowItem {
 const _FlowItem(this.type,this.id,this.label,this.complete);
 final String type,label;
 final int id;
 final bool complete;
}
List<_FlowItem> linkedFlowItems(KaryaGoal goal,AppData data,List<Idea> ideas){
 final items=<_FlowItem>[];
 for(final link in data.links.where((l)=>l.touches('goal',goal.id))){
  final type=link.fromType=='goal'&&link.fromId==goal.id?link.toType:link.fromType;
  final id=link.fromType=='goal'&&link.fromId==goal.id?link.toId:link.fromId;
  if(type=='task'){
   for(final t in data.tasks.where((t)=>t.id==id))items.add(_FlowItem('task',id,t.title,t.completed));
  }else if(type=='habit'){
   for(final h in data.habits.where((h)=>h.id==id))items.add(_FlowItem('habit',id,h.name,h.doneOn(DateTime.now())));
  }else if(type=='idea'){
   for(final idea in ideas.where((x)=>x.id==id))items.add(_FlowItem('idea',id,idea.body.split('\n').first,false));
  }else if(type=='subject'){
   for(final sub in data.subjects.where((x)=>x.id==id))items.add(_FlowItem('subject',id,sub.name,false));
  }else if(type=='goal'){
   for(final other in data.goals.where((x)=>x.id==id))items.add(_FlowItem('goal',id,other.title,other.done));
  }
 }
 return items;
}

/// A true pan-and-zoom flowchart, not a static list of goals. Data comes from
/// existing goal-to-task/habit/idea links and shares their persistence.
class FlowPlannerScreen extends ConsumerWidget {
 const FlowPlannerScreen({super.key});
 @override Widget build(BuildContext context,WidgetRef ref){
   final result=ref.watch(appProvider);
   return Scaffold(body:result.when(
     loading:()=>const Center(child:CircularProgressIndicator()),
     error:(e,_)=>Center(child:Text('Could not open flow planner: $e')),
     data:(data){
      final ideas=ref.watch(ideasProvider).value??const <Idea>[];
      final all=<List<_FlowItem>>[for(final goal in data.goals)linkedFlowItems(goal,data,ideas)];
      final height=data.goals.isEmpty?300.0:math.max(520.0,
        65.0+List.generate(data.goals.length,(i)=>math.max(170.0,90.0+all[i].length*67.0)).fold<double>(0,(a,b)=>a+b));
      var y=40.0;
      final painterLinks=<_FlowLine>[];
      final nodes=<Widget>[];
      for(var i=0;i<data.goals.length;i++){
        final goal=data.goals[i],list=all[i];
        final base=y;
        nodes.add(Positioned(left:35,top:base+35,width:280,height:112,child:_GoalNode(goal:goal)));
        for(var j=0;j<list.length;j++){
          final item=list[j];final iy=base+5+j*67.0;
          painterLinks.add(_FlowLine(const Offset(315,0)+Offset(0,base+88),Offset(410,iy+25)));
          nodes.add(Positioned(left:410,top:iy,width:335,height:54,child:_StepNode(item:item,data:data)));
        }
        if(list.isEmpty)nodes.add(Positioned(left:410,top:base+45,width:260,
          child:Card(child:Padding(padding:const EdgeInsets.all(10),child:Text('Add connected tasks or habits →',
            style:Theme.of(context).textTheme.bodySmall)))));
        y+=math.max(170.0,90.0+list.length*67.0);
      }
      return Column(children:[
        Padding(padding:const EdgeInsets.fromLTRB(16,8,16,8),child:Wrap(
          crossAxisAlignment:WrapCrossAlignment.center,spacing:8,runSpacing:6,children:[
            Text('FLOW PLANNER ✦',style:Theme.of(context).textTheme.titleLarge),
            OutlinedButton.icon(onPressed:()=>editGoal(context,ref),icon:const Icon(Icons.add),label:const Text('New goal')),
            OutlinedButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>const GoalsScreen())),
              icon:const Icon(Icons.add_link),label:const Text('Connect steps')),
          ])),
        const Padding(padding:EdgeInsets.symmetric(horizontal:16),child:Text(
          'Drag to explore • Pinch or scroll to zoom • Tap a step to work on it. Your plan is connected to real tasks.')),
        Expanded(child:data.goals.isEmpty?Center(child:Padding(padding:const EdgeInsets.all(20),
          child:NeoButton(label:'CREATE YOUR FIRST GOAL',icon:Icons.flag_outlined,
            onPressed:()=>editGoal(context,ref)))):
          ClipRect(child:InteractiveViewer(constrained:false,minScale:.40,maxScale:2.4,
            boundaryMargin:const EdgeInsets.all(130),child:SizedBox(width:800,height:height,
              child:Stack(children:[
                CustomPaint(size:Size(800,height),painter:_Connections(painterLinks,
                  Theme.of(context).colorScheme.primary)),
                ...nodes,
              ]))))),
      ]);
     }));
 }
}
class _FlowLine { const _FlowLine(this.from,this.to);final Offset from,to; }
class _Connections extends CustomPainter {
 const _Connections(this.links,this.color);
 final List<_FlowLine> links;
 final Color color;
 @override void paint(Canvas canvas,Size size){
  final pen=Paint()..color=color.withValues(alpha:.7)..strokeWidth=2.5..style=PaintingStyle.stroke;
  for(final l in links){
    final p=Path()..moveTo(l.from.dx,l.from.dy)
      ..cubicTo(l.from.dx+45,l.from.dy,l.to.dx-45,l.to.dy,l.to.dx,l.to.dy);
    canvas.drawPath(p,pen);
  }
 }
 @override bool shouldRepaint(covariant _Connections old)=>old.links!=links||old.color!=color;
}
class _GoalNode extends ConsumerWidget {
 const _GoalNode({required this.goal});final KaryaGoal goal;
 @override Widget build(BuildContext context,WidgetRef ref)=>NeoCard(color:colorFor(3),padding:const EdgeInsets.all(12),
   onTap:()=>editGoal(context,ref,goal),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     const Text('GOAL',style:TextStyle(color:Colors.black,fontSize:11,fontWeight:FontWeight.bold)),
     Expanded(child:Align(alignment:Alignment.centerLeft,child:Text(goal.title,maxLines:2,
       overflow:TextOverflow.ellipsis,style:const TextStyle(color:Colors.black,fontWeight:FontWeight.w900,fontSize:16)))),
     Row(children:[Icon(goal.done?Icons.check_circle:Icons.flag_outlined,size:16,color:Colors.black),
       Text(goal.done?' Achieved (+15 pts)':' Work in progress',style:const TextStyle(color:Colors.black,fontSize:11))]),
   ]));
}
class _StepNode extends ConsumerWidget {
 const _StepNode({required this.item,required this.data});
 final _FlowItem item;final AppData data;
 @override Widget build(BuildContext context,WidgetRef ref)=>NeoCard(color:item.complete?colorFor(2):null,
   padding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
   onTap:(){if(item.type=='task'){
     final t=data.tasks.where((x)=>x.id==item.id).toList();
     if(t.isNotEmpty)showTaskDetails(context,ref,t.first);
   }},
   child:Row(children:[Icon(item.complete?Icons.check_circle:Icons.circle_outlined,
     color:item.complete?Colors.black:null,size:19),const SizedBox(width:8),
     Expanded(child:Text('${item.type.toUpperCase()} · ${item.label}',maxLines:2,
       overflow:TextOverflow.ellipsis,style:TextStyle(fontWeight:FontWeight.w800,
       color:item.complete?Colors.black:null,fontSize:12)))]));
}
