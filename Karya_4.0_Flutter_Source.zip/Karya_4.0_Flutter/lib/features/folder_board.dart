import 'package:flutter/material.dart';
import '../core/models.dart';
import 'neo.dart';

/// Real folder silhouette, shared by Windows and Android.
class SubjectFolder extends StatefulWidget {
  const SubjectFolder({super.key,required this.subject,required this.openCount,
    required this.onTap});
  final Subject subject;
  final int openCount;
  final VoidCallback onTap;
  @override State<SubjectFolder> createState()=>_SubjectFolderState();
}
class _SubjectFolderState extends State<SubjectFolder> {
  bool hovering=false;
  @override Widget build(BuildContext context){
    final colors=Theme.of(context).extension<NeoAccents>()?.colors;
    final base=(colors==null||colors.isEmpty)?colorFor(widget.subject.color):
      colors[widget.subject.color%colors.length];
    final dark=Theme.of(context).brightness==Brightness.dark;
    final stroke=dark?const Color(0xFF626262):const Color(0xFF151515);
    return MouseRegion(
      onEnter:(_)=>setState(()=>hovering=true),
      onExit:(_)=>setState(()=>hovering=false),
      child:AnimatedScale(scale:hovering?1.035:1,duration:const Duration(milliseconds:180),
        curve:Curves.easeOutCubic,child:GestureDetector(onTap:widget.onTap,
        child:CustomPaint(painter:_FolderOutline(base,stroke),
          child:Padding(padding:const EdgeInsets.fromLTRB(17,35,17,17),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(subjectEmoji(widget.subject.icon),style:const TextStyle(fontSize:30)),
              const Spacer(),
              Text(widget.subject.name,maxLines:2,overflow:TextOverflow.ellipsis,
                style:const TextStyle(color:Colors.black,fontWeight:FontWeight.w900,fontSize:17)),
              Text('${widget.openCount} open',style:const TextStyle(color:Colors.black,fontSize:12)),
            ]))))));
  }
}
class _FolderOutline extends CustomPainter {
  const _FolderOutline(this.fill,this.stroke);
  final Color fill,stroke;
  @override void paint(Canvas c,Size s){
    final w=s.width,h=s.height;
    final path=Path()..moveTo(10,18)..lineTo(w*.36,18)..lineTo(w*.43,4)
      ..quadraticBezierTo(w*.46,1,w*.50,4)..lineTo(w*.60,18)
      ..lineTo(w-10,18)..quadraticBezierTo(w-2,18,w-2,29)
      ..lineTo(w-2,h-10)..quadraticBezierTo(w-2,h-2,w-12,h-2)
      ..lineTo(12,h-2)..quadraticBezierTo(2,h-2,2,h-12)
      ..lineTo(2,28)..quadraticBezierTo(2,18,10,18)..close();
    c.drawPath(path.shift(const Offset(3,4)),Paint()..color=stroke.withValues(alpha:.55));
    c.drawPath(path,Paint()..color=fill);
    c.drawPath(path,Paint()..color=stroke..strokeWidth=2.4..style=PaintingStyle.stroke);
  }
  @override bool shouldRepaint(covariant _FolderOutline old)=>fill!=old.fill||stroke!=old.stroke;
}
