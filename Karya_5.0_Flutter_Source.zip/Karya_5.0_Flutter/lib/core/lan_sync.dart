import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:cryptography/cryptography.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'database.dart';

/// Local Wi-Fi sync protocol v1: encrypted, opt-in, device-to-device only.
/// The two-way algorithm synchronizes only when one side changed since its last
/// successful matching snapshot; if both changed, it stops without overwriting.
/// No remote hosts except the IP the user explicitly pairs with are contacted.
class LocalSync {
  LocalSync._();
  static final instance=LocalSync._();
  static const port=8791;
  static const maxPayload=12*1024*1024;
  HttpServer? _server;
  String? _serverCode;
  bool get serving=>_server!=null;
  final changed=StreamController<int>.broadcast();
  final crypt=AesGcm.with256bits();
  Future<String> _fingerprint(Map<String,dynamic> value) async {
    final digest=await Sha256().hash(utf8.encode(jsonEncode(value)));
    return base64Url.encode(digest.bytes);
  }
  Future<SecretKey> _key(String code) async {
    final digest=await Sha256().hash(utf8.encode(code));
    return SecretKey(digest.bytes);
  }
  Future<String> _seal(Map<String,dynamic> content,String code) async {
    final box=await crypt.encrypt(utf8.encode(jsonEncode(content)),secretKey:await _key(code));
    return jsonEncode({'n':base64Url.encode(box.nonce),
      'c':base64Url.encode(box.cipherText),'m':base64Url.encode(box.mac.bytes)});
  }
  Future<Map<String,dynamic>> _open(String encoded,String code) async {
    final data=Map<String,dynamic>.from(jsonDecode(encoded) as Map);
    final box=SecretBox(base64Url.decode(data['c'] as String),
      nonce:base64Url.decode(data['n'] as String),mac:Mac(base64Url.decode(data['m'] as String)));
    return Map<String,dynamic>.from(jsonDecode(utf8.decode(
      await crypt.decrypt(box,secretKey:await _key(code)))) as Map);
  }
  String newCode() {
    const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random=Random.secure();
    return List.generate(26,(_)=>alphabet[random.nextInt(alphabet.length)]).join();
  }
  Future<List<String>> ipv4Addresses() async {
    final interfaces=await NetworkInterface.list(type:InternetAddressType.IPv4);
    return interfaces.expand((i)=>i.addresses).where((ip)=>!ip.isLoopback)
      .map((ip)=>ip.address).toSet().toList();
  }
  Future<String> startHost(KaryaDatabase db) async {
    if(_server!=null)return _serverCode!;
    final prefs=await SharedPreferences.getInstance();
    final code=prefs.getString('lan_host_code') ?? newCode();
    final server=await HttpServer.bind(InternetAddress.anyIPv4,port);
    _server=server;
    _serverCode=code;
    await prefs.setString('lan_host_code',code);
    server.listen((r)=>_handle(r,db,code),onError:(_){ });
    return code;
  }
  Future<void> stopHost() async {
    final s=_server;_server=null;_serverCode=null;
    await s?.close(force:true);
  }
  Future<void> _handle(HttpRequest req,KaryaDatabase db,String code) async {
    req.response.headers.contentType=ContentType.json;
    if(req.method!='POST'||req.uri.path!='/sync'){
      req.response.statusCode=404;await req.response.close();return;
    }
    try {
      final bytes=<int>[];
      await for(final chunk in req){
        bytes.addAll(chunk);
        if(bytes.length>maxPayload)throw const FormatException('Payload too large');
      }
      final message=await _open(utf8.decode(bytes),code);
      final op=message['op'];
      final before=await db.syncSnapshot();
      final hash=await _fingerprint(before);
      Map<String,dynamic> reply;
      if(op=='status') {
        reply={'ok':true,'hash':hash,'snapshot':before};
      } else if(op=='apply') {
        if(message['expected']!=hash) {
          reply={'ok':false,'error':'Other device changed during sync. Retry safely.'};
        }else{
          final incoming=Map<String,dynamic>.from(message['snapshot'] as Map);
          if(await _fingerprint(await db.syncSnapshot())!=hash){
            throw StateError('Desktop changed during sync; retry.');
          }
          await db.restoreSnapshot(incoming);
          changed.add(1);
          reply={'ok':true,'hash':await _fingerprint(await db.syncSnapshot())};
        }
      } else {
        reply={'ok':false,'error':'Unknown sync command'};
      }
      req.response.write(await _seal(reply,code));
    }catch(_){req.response.statusCode=400;req.response.write('{"error":"Could not authenticate or process sync"}');}
    await req.response.close();
  }
  Future<Map<String,dynamic>> _request(String host,String code,Map<String,dynamic> message) async {
    final http=HttpClient()..connectionTimeout=const Duration(seconds:5);
    try{
      final req=await http.post(host,port,'/sync').timeout(const Duration(seconds:8));
      req.headers.contentType=ContentType.json;
      req.write(await _seal(message,code));
      final res=await req.close().timeout(const Duration(seconds:10));
      if(res.statusCode!=200)throw StateError('Could not pair; check Wi-Fi address and code.');
      final content=await utf8.decoder.bind(res).join();
      return await _open(content,code);
    }finally{http.close(force:true);}
  }
  Future<String> sync(KaryaDatabase db,String host,String code) async {
    final ip=InternetAddress.tryParse(host.trim());
    if(ip==null||ip.type!=InternetAddressType.IPv4||ip.isLoopback)
      throw const FormatException('Enter the private IPv4 address shown by the other device.');
    // Never allow internet-facing addresses; the pairing must remain local.
    final parts=ip.rawAddress;
    final privateIp=parts[0]==10 || parts[0]==192&&parts[1]==168 ||
      parts[0]==172&&parts[1]>=16&&parts[1]<=31 ||
      parts[0]==169&&parts[1]==254;
    if(!privateIp)throw const FormatException('Only private local Wi-Fi addresses are supported.');
    final secret=code.trim().toUpperCase().replaceAll(RegExp(r'\s+'),'');
    if(secret.length<20)throw const FormatException('Paste the full pairing code.');
    final prefs=await SharedPreferences.getInstance();
    final local=await db.syncSnapshot();
    final localHash=await _fingerprint(local);
    final remote=await _request(ip.address,secret,{'op':'status'});
    if(remote['ok']!=true)throw StateError('The other device did not answer.');
    final remoteHash=remote['hash'] as String;
    final base=prefs.getString('lan_code')==secret?prefs.getString('lan_last_hash_${ip.address}'):null;
    if(localHash==remoteHash){
      await prefs.setString('lan_last_hash_${ip.address}',localHash);
      await prefs.setString('lan_ip',ip.address);
      await prefs.setString('lan_code',secret);
      await prefs.setString('lan_last_success',DateTime.now().toIso8601String());
      return 'Already up to date. Nothing changed.';
    }
    final localEmpty=(local.values.whereType<List>().every((v)=>v.isEmpty));
    final remoteMap=Map<String,dynamic>.from(remote['snapshot'] as Map);
    final remoteEmpty=(remoteMap.values.whereType<List>().every((v)=>v.isEmpty));
    if(await _fingerprint(await db.syncSnapshot())!=localHash){
      throw StateError('This device changed during sync. Try again; no data was overwritten.');
    }
    String synced;
    if(localHash==base || base==null&&localEmpty){
      await db.restoreSnapshot(remoteMap);
      changed.add(1);
      synced='Changes received from your paired device.';
    }else if(remoteHash==base || base==null&&remoteEmpty){
      final reply=await _request(ip.address,secret,
        {'op':'apply','expected':remoteHash,'snapshot':local});
      if(reply['ok']!=true)throw StateError('${reply['error']}');
      synced='Changes sent to your paired device.';
    }else{
      throw StateError('Both devices have unsynced changes. Nothing was overwritten. Back up both devices before resolving this conflict.');
    }
    final after=await db.syncSnapshot();
    await prefs.setString('lan_last_hash_${ip.address}',await _fingerprint(after));
    await prefs.setString('lan_ip',ip.address);
    await prefs.setString('lan_code',secret);
    await prefs.setString('lan_last_success',DateTime.now().toIso8601String());
    return synced;
  }
  Future<String?> autoSync(KaryaDatabase db) async {
    final prefs=await SharedPreferences.getInstance();
    if(!(prefs.getBool('lan_auto')??false))return null;
    final ip=prefs.getString('lan_ip');final code=prefs.getString('lan_code');
    if(ip==null||code==null)return null;
    return sync(db,ip,code);
  }
}
