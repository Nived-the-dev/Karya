import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/state.dart';
import '../core/models.dart';
import 'neo.dart';

final ideasProvider=FutureProvider<List<Idea>>((ref)=>ref.watch(dbProvider).loadIdeas());
class IdeasScreen extends ConsumerStatefulWidget {
  const IdeasScreen({super.key});
  @override ConsumerState<IdeasScreen> createState()=>_IdeasScreenState();
}
class _IdeasScreenState extends ConsumerState<IdeasScreen> {
  String query='';
  Future<void> edit(Idea? idea) async {
    final controller=TextEditingController(text:idea?.body??'');
    var pinned=idea?.pinned??false;
    await showModalBottomSheet<void>(context:context,isScrollControlled:true,useSafeArea:true,
      showDragHandle:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>Padding(
        padding:EdgeInsets.fromLTRB(18,12,18,MediaQuery.viewInsetsOf(ctx).bottom+24),
        child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,
          crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Text(idea==null?'CAPTURE AN IDEA':'EDIT IDEA',style:Theme.of(ctx).textTheme.titleLarge),
          const SizedBox(height:14),
          TextField(controller:controller,autofocus:true,maxLines:7,minLines:3,maxLength:10000,
            decoration:const InputDecoration(hintText:'A thought, a plan, whatever is on your mind...')),
          SwitchListTile(title:const Text('Pin this idea'),value:pinned,
            onChanged:(v)=>setLocal(()=>pinned=v)),
          FilledButton(onPressed:()async{
            if(controller.text.trim().isEmpty)return;
            await ref.read(dbProvider).saveIdea(id:idea?.id,body:controller.text,pinned:pinned);
            ref.invalidate(ideasProvider);
            if(ctx.mounted)Navigator.pop(ctx);
          },child:const Text('SAVE IDEA')),
        ])))));
    Future<void>.delayed(const Duration(milliseconds:500),controller.dispose);
  }
  Future<void> linkToGoal(Idea idea,AppData data) async {
    await showModalBottomSheet<void>(context:context,showDragHandle:true,useSafeArea:true,
      builder:(sheet)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Padding(padding:EdgeInsets.all(14),child:Text('LINK TO A GOAL')),
        for(final goal in data.goals)ListTile(leading:const Icon(Icons.flag_outlined),
          title:Text(goal.title),onTap:()async{
            await ref.read(appProvider.notifier).change((db)=>db.addLink('goal',goal.id,'idea',idea.id));
            if(sheet.mounted)Navigator.pop(sheet);
          }),
        if(data.goals.isEmpty)const Padding(padding:EdgeInsets.all(18),
          child:Text('First create a goal in the Flow Planner tab.')),
      ])));
  }
  @override Widget build(BuildContext context){
    final ideas=ref.watch(ideasProvider);
    final data=ref.watch(appProvider).value;
    return ideas.when(loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('Could not load ideas: $e')),
      data:(items){
        final filtered=items.where((i)=>i.body.toLowerCase().contains(query.toLowerCase())).toList();
        return ScreenBody(children:[
          const Headline('IDEAS ✦','A place for the thoughts that become something.'),
          NeoButton(label:'+ NEW IDEA',icon:Icons.edit_note_rounded,onPressed:()=>edit(null)),
          TextField(onChanged:(v)=>setState(()=>query=v),
            decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search notes')),
          const SizedBox(height:12),
          if(filtered.isEmpty)const EmptyState('A blank page.',
            'Your next big idea can start right here.',icon:Icons.lightbulb_outline),
          for(final idea in filtered)NeoCard(onTap:()=>edit(idea),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              if(idea.pinned)const Icon(Icons.push_pin,size:18),
              Text(idea.body,maxLines:8,overflow:TextOverflow.ellipsis),
              if(data!=null)...[
                const SizedBox(height:5),
                for(final link in data.links.where((l)=>l.touches('idea',idea.id)))
                  Text('Linked to ${data.goals.where((g)=>link.touches('goal',g.id)).map((g)=>g.title).join(', ')}',
                    maxLines:1,overflow:TextOverflow.ellipsis,
                    style:Theme.of(context).textTheme.bodySmall),
              ],
              Wrap(spacing:5,runSpacing:2,children:[
                IconButton(tooltip:'Edit idea',icon:const Icon(Icons.edit_outlined),onPressed:()=>edit(idea)),
                IconButton(tooltip:'Convert to task',icon:const Icon(Icons.add_task),
                  onPressed:()async{
                    final text=idea.body.trim().split('\n').first;
                    await ref.read(appProvider.notifier).change((db)=>db.transaction(() async {
                      final taskId=await db.saveTask(
                        title:text.length>180?text.substring(0,180):text);
                      await db.addLink('idea',idea.id,'task',taskId);
                    }));
                    if(context.mounted)toast(context,'Created a task.');
                  }),
                IconButton(tooltip:'Link to goal',icon:const Icon(Icons.link),
                  onPressed:data==null?null:()=>linkToGoal(idea,data)),
                IconButton(tooltip:'Turn into goal',icon:const Icon(Icons.flag_outlined),
                  onPressed:()async{
                    final t=idea.body.trim().split('\n').first;
                    await ref.read(appProvider.notifier).change((db)=>db.transaction(() async{
                      final id=await db.saveGoal(title:t.length>180?t.substring(0,180):t);
                      await db.addLink('goal',id,'idea',idea.id);
                    }));
                    if(context.mounted)toast(context,'New goal created and linked.');
                  }),
                IconButton(tooltip:'Delete idea',icon:const Icon(Icons.delete_outline),
                  onPressed:()async{
                    if(!await confirmDelete(context,'idea'))return;
                    await ref.read(appProvider.notifier).change((db)=>db.removeIdea(idea.id));
                    ref.invalidate(ideasProvider);
                  }),
              ]),
            ])),
        ]);
      });
  }
}
