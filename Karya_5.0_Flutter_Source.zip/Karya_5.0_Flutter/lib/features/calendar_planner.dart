import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'tasks.dart';

/// Offline calendar with scheduled tasks, habit check-ins and goal dates.
/// Calendar navigation and selection never change the underlying records.
class CalendarPlannerScreen extends ConsumerStatefulWidget {
  const CalendarPlannerScreen({super.key});
  @override ConsumerState<CalendarPlannerScreen> createState() => _CalendarPlannerScreenState();
}

class _CalendarPlannerScreenState extends ConsumerState<CalendarPlannerScreen> {
  DateTime displayed = DateTime(DateTime.now().year, DateTime.now().month);
  DateTime selected = dayOnly(DateTime.now());

  void monthBy(int offset) => setState(() {
    displayed = DateTime(displayed.year, displayed.month + offset);
  });

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(appProvider);
    return data.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, _) => Center(child: Text('Could not open calendar: $error')),
      data: (app) => ScreenBody(children: [
        const Headline('YOUR CALENDAR', 'A calmer way to see what is coming up.'),
        LayoutBuilder(builder: (context, constraints) {
          final compact = constraints.maxWidth < 850;
          final overview = _MonthView(
            month: displayed,
            selected: selected,
            data: app,
            onChangeMonth: monthBy,
            onSelect: (day) => setState(() => selected = day),
          );
          final agenda = _DayAgenda(day: selected, data: app, ref: ref);
          return compact
              ? Column(children: [overview, const SizedBox(height: 12), agenda])
              : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(flex: 6, child: overview),
                  const SizedBox(width: 16),
                  Expanded(flex: 4, child: agenda),
                ]);
        }),
      ]),
    );
  }
}

class _MonthView extends StatelessWidget {
  const _MonthView({required this.month, required this.selected,
    required this.data, required this.onChangeMonth, required this.onSelect});
  final DateTime month, selected;
  final AppData data;
  final void Function(int) onChangeMonth;
  final void Function(DateTime) onSelect;

  @override
  Widget build(BuildContext context) {
    final days = DateTime(month.year, month.month + 1, 0).day;
    final paddingDays = DateTime(month.year, month.month).weekday - 1;
    final total = (paddingDays + days + 6) ~/ 7 * 7;
    final dateTiles = List.generate(total, (index) {
      final day = index - paddingDays + 1;
      return day >= 1 && day <= days ? DateTime(month.year, month.month, day) : null;
    });
    final accent = Theme.of(context).colorScheme.primary;
    return NeoCard(child:Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child:Text(DateFormat('MMMM yyyy').format(month),
          style: Theme.of(context).textTheme.titleLarge)),
        IconButton(tooltip:'Previous month',onPressed: () => onChangeMonth(-1),
          icon: const Icon(Icons.chevron_left)),
        IconButton(tooltip:'Next month',onPressed: () => onChangeMonth(1),
          icon: const Icon(Icons.chevron_right)),
      ]),
      const SizedBox(height: 12),
      Row(children: [for (final name in ['M', 'T', 'W', 'T', 'F', 'S', 'S'])
        Expanded(child: Center(child: Text(name, style:const TextStyle(fontWeight:FontWeight.w800))))]),
      const SizedBox(height: 6),
      GridView.builder(
        shrinkWrap:true,
        physics:const NeverScrollableScrollPhysics(),
        itemCount:dateTiles.length,
        gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount:7,crossAxisSpacing:3,mainAxisSpacing:3,childAspectRatio:.9),
        itemBuilder:(context,index) {
          final date=dateTiles[index];
          if(date==null)return const SizedBox.shrink();
          final key=dayKey(date);
          final taskCount=data.tasks.where((t)=>t.dueDay==key && !t.completed).length;
          final hasGoal=data.goals.any((g)=>g.targetDay==key);
          final hasHabit=data.habits.any((h)=>h.scheduledOn(date));
          final active=dayKey(selected)==key;
          return Semantics(label:'${DateFormat('d MMMM').format(date)}, $taskCount tasks',
            button:true,selected:active,child:InkWell(
              borderRadius:BorderRadius.circular(10),onTap:()=>onSelect(date),
              child:AnimatedContainer(duration:const Duration(milliseconds:170),
                decoration:BoxDecoration(
                  color:active?accent.withValues(alpha:.2):Colors.transparent,
                  borderRadius:BorderRadius.circular(10),
                  border:Border.all(color:active?accent:Colors.transparent,width:2)),
                child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Text('${date.day}',style:TextStyle(fontWeight:active?FontWeight.w900:FontWeight.w500,
                    fontSize:12)),
                  const SizedBox(height:3),
                  Row(mainAxisAlignment:MainAxisAlignment.center,children:[
                    if(taskCount>0)_Dot(color:const Color(0xFFFF6BA6)),
                    if(hasHabit)_Dot(color:const Color(0xFF64DDBC)),
                    if(hasGoal)_Dot(color:const Color(0xFFA68EFF)),
                  ]),
                ]))),
            );
        }),
      const SizedBox(height:10),
      const Wrap(spacing:14,runSpacing:6,children:[
        _Key(color:Color(0xFFFF6BA6),label:'Tasks'),
        _Key(color:Color(0xFF64DDBC),label:'Habits'),
        _Key(color:Color(0xFFA68EFF),label:'Goals'),
      ]),
    ]));
  }
}
class _Dot extends StatelessWidget {
  const _Dot({required this.color});final Color color;
  @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.symmetric(horizontal:1),
    width:5,height:5,decoration:BoxDecoration(color:color,shape:BoxShape.circle));
}
class _Key extends StatelessWidget {
  const _Key({required this.color,required this.label});
  final Color color;final String label;
  @override Widget build(BuildContext context)=>Row(mainAxisSize:MainAxisSize.min,children:[
    _Dot(color:color),const SizedBox(width:6),Text(label,style:Theme.of(context).textTheme.bodySmall)]);
}
class _DayAgenda extends StatelessWidget {
  const _DayAgenda({required this.day,required this.data,required this.ref});
  final DateTime day;final AppData data;final WidgetRef ref;
  @override Widget build(BuildContext context) {
    final key=dayKey(day);
    final tasks=data.tasks.where((t)=>t.dueDay==key).toList();
    final habits=data.habits.where((h)=>h.scheduledOn(day)).toList();
    final goals=data.goals.where((g)=>g.targetDay==key).toList();
    return NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text(DateFormat('EEEE, d MMM').format(day),style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:10),
      OutlinedButton.icon(onPressed:()=>quickAddTask(context,ref),
        icon:const Icon(Icons.add),label:const Text('Add task')),
      if(tasks.isEmpty&&habits.isEmpty&&goals.isEmpty)
        const Padding(padding:EdgeInsets.symmetric(vertical:24),child:Text(
          'Nothing planned here yet. Leave room to breathe.')),
      for(final task in tasks)CheckboxListTile(
        contentPadding:EdgeInsets.zero,dense:true,title:Text(task.title),
        value:task.completed,
        onChanged:(value)=>ref.read(appProvider.notifier).change(
          (db)=>db.setTaskDone(task.id,value??false)),
      ),
      for(final habit in habits)ListTile(contentPadding:EdgeInsets.zero,dense:true,
        leading:Icon(habit.doneOn(day)?Icons.check_circle:Icons.radio_button_unchecked),
        title:Text(habit.name),subtitle:const Text('Habit')),
      for(final goal in goals)ListTile(contentPadding:EdgeInsets.zero,dense:true,
        leading:Icon(goal.done?Icons.flag_circle:Icons.flag_outlined),
        title:Text(goal.title),subtitle:const Text('Goal date')),
    ]));
  }
}
