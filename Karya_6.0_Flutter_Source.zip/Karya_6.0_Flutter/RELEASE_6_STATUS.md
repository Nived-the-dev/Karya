# Kārya 6 source candidate — 2026-10-22

**Status:** This is a development preview. Static source checks are not Flutter compilation, and Android/Windows on-device verification is required. Do not install over valuable local data without a backup.

## Addressed in this candidate
- Calendar date-selected task creation (with due date), multiple tasks/day, descriptions, scheduled time, and edit entry point.
- Home quick-add redirects to Tasks.
- Contextual, replayable tab help; searchable notes board with pinned/color-coded notes, optional automatic saves; fewer phone footer items.
- Windows navigation: dedicated Journey, Wi-Fi Sync, Help choices.
- Wi-Fi: pairing network diagnosis, selecting local private-network interface, opt-in rehosting at launch, encrypted reachability check, and explicit conflict handling.
- Reminder: on-demand diagnostics/test notification, permission request from due/reminder editor, reschedule on resume.
- Flow: Material ancestor for standalone route and drag adjusted for current zoom factor.
- A voluntary honesty pledge displayed in Journey.
- Long subject folder labels truncate rather than overflow; compact phone heading.
- Tests for calendar multiple tasks and descriptions, standalone Flow, notes and Help.

## Still requiring validation / limitations
- No guarantee the inherited Flutter `_dependents.isEmpty` assertion is eliminated; it may require a full Android stack trace with reproduction steps.
- Local network sync still rejects conflicting independent edits rather than merging records and cannot work across subnets without router configuration.
- Android inexact alarms may arrive later than their scheduled time depending on battery policy. Notifications must be enabled in the app and system; Android manufacturer restrictions vary.
- Notes use the existing synced note body; color choice is device-local. No automatic multi-device syncing of note colors yet.
- Diagram editor is not at diagram.net feature parity (connector editing, grouping, shape libraries, undo/redo).
- Real-device testing and release signing are still required.
