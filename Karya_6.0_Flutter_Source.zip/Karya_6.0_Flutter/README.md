# Kārya 4.0 — less organising, more doing

**Current editable version: 4.0.0** — Android and Windows Flutter source. Read [`RELEASE_4_STATUS.md`](RELEASE_4_STATUS.md) for complete changes and honest testing limitations. The existing Android 3 and Windows 3 releases are not automatically version 4.

The redesigned app includes five themes with true-black dark mode, folder-shaped subject boards, 32 emojis, instant task state updates, a flowchart planner, a habit Constellation, interactive onboarding, 3 layout modes, and a private rank/points journey with optional prestige. Optional local Wi-Fi synchronization remains account-free. No ads.

See [`BUILD_KARYA_4.md`](BUILD_KARYA_4.md) for beginner-friendly GitHub Actions build steps. Flutter compilation and real-device testing are required before distributing this source as an app.

---

# Kārya 3.0 (कार्य) — Less Organising. More Doing.

**Creator:** Nived Chandrasudan  
**Source status:** Editable Flutter/Dart project. **This 3.0 source is not yet a verified Android APK or Windows build.**

Kārya is an offline-first planner for messy thoughts, tasks, subjects, habits, notes and goals. It has no advertisements, no account requirement, no cloud backend, and no fake AI claims. The original Python chatbot is ported to a rule-based Flutter command assistant.

## Features

- Home dashboard with subject boards, quick task capture, today's work and progress
- Task CRUD, priorities, dates/reminders, subtasks, search, filters, subjects
- Daily/weekday habits, archived history, weekly charts, monthly heatmap
- **Constellation:** interactive habit check-in and work-connection graphs, zoom/pan, node details, private-label toggle and PNG share sheet
- **Goal Trees:** create goals and manually link them to tasks, habits, ideas and subjects
- **Ideas:** local notes, pinning, search, idea→task traceable link and idea→goal conversion
- **Chaos Dump:** offline rule-based sorting into editable Tasks and Ideas with review before saving
- **Rescue My Day:** suggested urgent next steps, without automatic deletion or rescheduling
- **Weekly Story:** narratives generated from actual saved activity
- Five color personalities, true-black dark mode, responsive PageView swiping and haptics
- **Private LAN sync:** opt-in encrypted local network transfer between a Windows host and Android client (see limits below)

## Project

`lib/main.dart` sets up the root responsive shell and routes; `lib/core` contains persistence, sync, notifications and state. The `lib/features` directory contains the screens. Database schema v3 includes goals and entity links and migrates prior v2 installations. All user data remains in local SQLite until deliberately sent to a paired device or deliberately shared as an image.

## Android / Windows build

Requires a current stable Flutter, Android SDK 36 / Java 17 for Android, and Visual Studio C++ Desktop for Windows. This working environment does not have them installed.

```sh
flutter create --platforms=android,windows --project-name=karya_app --no-pub .
flutter pub get
dart format lib test integration_test
flutter analyze --no-fatal-infos
flutter test test
flutter build apk --debug
```

On Windows:

```sh
flutter create --platforms=windows --project-name=karya_app --no-pub .
flutter pub get
flutter build windows --release
```

GitHub workflows `karya-3-build.yml` and `karya-3-windows.yml` in the connected `Nived-the-dev/Karya` repository build from the versioned source ZIP without replacing the original 2.1 pipeline. The full source also contains standalone workflow templates.

## Pairing and syncing

1. On Windows open Settings → **Private Wi-Fi sync** → **Start Wi-Fi Sync**. The app displays a private IPv4 address and a long pairing code; Windows Firewall may ask to allow private-network traffic.
2. On Android open the same Settings page, paste both values and choose **Sync Now**.
3. The first pairing can transfer data safely if one device is empty. Subsequent two-way updates use a last-known snapshot fingerprint. Only one device can have unsynced changes between successful syncs.
4. **If both sides changed, synchronization refuses to overwrite anything.** No automatic multi-master conflict merging is claimed. Auto-sync attempts run while the app is open (every two minutes); the laptop must be running and hosting.

Messages use AES-256-GCM encrypted payloads on your private Wi-Fi. The local connection itself is HTTP, so local IP/timing metadata can still be observed. Pairing keys are saved in device preferences; keep the device locked and do not share pairing codes publicly. No public internet endpoint, service account or external server is used.

## Documentation

Read [RELEASE_3_0_STATUS.md](RELEASE_3_0_STATUS.md) and [TEST_RESULTS_3_0.md](TEST_RESULTS_3_0.md) for verified versus unverified status, [PRIVACY_POLICY.html](PRIVACY_POLICY.html), [GOOGLE_PLAY_PUBLISHING_GUIDE.md](GOOGLE_PLAY_PUBLISHING_GUIDE.md) and [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md) before any store release.

**Important:** The APK from a prior GitHub Actions run is not Kārya 3.0. Do not present it as a new release. Real-device testing, security review and Play Store signing are not complete.


## Kārya 5.0 usability update (source candidate)

- Calendar planner: month and day agenda for actual due tasks, goals and scheduled habits.
- Diagram-style Flow Planner: pan/zoom, move-mode for nodes, persisted local coordinates, and connections to existing tasks, habits and goals. This is not a full diagram.net clone.
- Progress: selectable bars, line, filled area, and donut chart representations of real check-ins.
- Removed Constellation and Chaos Dump from the application UI and source.
- Home no longer shows shortcut buttons under the Journey card.
- Bottom navigation uses four labeled primary tabs and a labeled More menu rather than seven cramped icons; desktop uses a navigation rail.
- Theme-aware stationery-style folder silhouettes and white outlines/shadows in true-black dark mode.
- Once-per-calendar-day local reward of 5 points for opening the app; no penalties for breaks or pushy prompts. Rank thresholds become more demanding.
- Wi-Fi sync screen supports hosting and connecting from either device; concurrent edits still safely stop rather than perform unsafe automatic merges.

**Status**: this source needs a successful Flutter/Android/Windows build and real-device regression testing before replacing Kārya 4.0.
