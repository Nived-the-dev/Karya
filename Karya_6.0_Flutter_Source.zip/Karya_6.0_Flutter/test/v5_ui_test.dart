import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:karya_app/core/database.dart';
import 'package:karya_app/core/state.dart';
import 'package:karya_app/features/calendar_planner.dart';
import 'package:karya_app/features/flow_planner.dart';

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('Calendar remains usable at narrow phone width',(tester) async {
    final db=KaryaDatabase.test(NativeDatabase.memory());
    addTearDown(() async => db.close());
    tester.view.physicalSize=const Size(360,760);
    tester.view.devicePixelRatio=1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(ProviderScope(overrides:[dbProvider.overrideWithValue(db)],
      child:const MaterialApp(home:Scaffold(body:CalendarPlannerScreen()))));
    await tester.pumpAndSettle();
    expect(find.byType(CalendarPlannerScreen),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
  testWidgets('Empty flow canvas has a clear create-goal action',(tester) async {
    final db=KaryaDatabase.test(NativeDatabase.memory());
    addTearDown(() async => db.close());
    await tester.pumpWidget(ProviderScope(overrides:[dbProvider.overrideWithValue(db)],
      child:const MaterialApp(home:Scaffold(body:FlowPlannerScreen()))));
    await tester.pumpAndSettle();
    expect(find.text('Start with one goal.'),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
}
