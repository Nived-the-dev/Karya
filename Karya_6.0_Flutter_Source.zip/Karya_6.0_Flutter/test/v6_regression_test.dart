import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:karya_app/core/database.dart';
import 'package:karya_app/core/state.dart';
import 'package:karya_app/features/calendar_planner.dart';
import 'package:karya_app/features/help.dart';
import 'package:karya_app/features/flow_planner.dart';
import 'package:karya_app/features/ideas.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('Calendar shows several tasks and their descriptions on one day',(tester) async {
    tester.view.physicalSize=const Size(1200,980);
    tester.view.devicePixelRatio=1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final database=KaryaDatabase.test(NativeDatabase.memory());
    addTearDown(database.close);
    final today=DateTime.now();
    final due=DateTime(today.year,today.month,today.day,18).toIso8601String();
    await database.saveTask(title:'Chemistry test',description:'Read chapters 1–3',dueAt:due);
    await database.saveTask(title:'Maths revision',description:'Finish exercise 7',dueAt:due);
    await tester.pumpWidget(ProviderScope(overrides:[dbProvider.overrideWithValue(database)],
      child:const MaterialApp(home:Scaffold(body:CalendarPlannerScreen()))));
    await tester.pumpAndSettle();
    expect(find.text('Chemistry test'),findsOneWidget);
    expect(find.text('Maths revision'),findsOneWidget);
    expect(find.text('Read chapters 1–3'),findsOneWidget);
    expect(find.text('Finish exercise 7'),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
  testWidgets('Help documentation supports mobile viewport',(tester) async {
    tester.view.physicalSize=const Size(360,800);
    tester.view.devicePixelRatio=1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(const ProviderScope(child:MaterialApp(home:HelpScreen())));
    await tester.pumpAndSettle();
    expect(find.text('LEARN KĀRYA'),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
  testWidgets('Flow owns material ancestor on a standalone route',(tester) async {
    final database=KaryaDatabase.test(NativeDatabase.memory());
    addTearDown(database.close);
    await database.saveGoal(title:'Plan my studies');
    await tester.pumpWidget(ProviderScope(overrides:[dbProvider.overrideWithValue(database)],
      child:const MaterialApp(home:Scaffold(body:FlowPlannerScreen()))));
    await tester.pumpAndSettle();
    expect(tester.takeException(),isNull);
  });
  testWidgets('Notes is usable without any notes',(tester)async{
    final database=KaryaDatabase.test(NativeDatabase.memory());
    addTearDown(database.close);
    await tester.pumpWidget(ProviderScope(overrides:[dbProvider.overrideWithValue(database)],
      child:const MaterialApp(home:Scaffold(body:IdeasScreen()))));
    await tester.pumpAndSettle();
    expect(find.text('Nothing here yet.'),findsOneWidget);
    expect(tester.takeException(),isNull);
  });
}
