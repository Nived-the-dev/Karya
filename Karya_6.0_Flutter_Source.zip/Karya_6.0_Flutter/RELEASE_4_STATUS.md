# Kārya 4.0 — source release and verification status

**Status:** Editable Flutter source prepared. **Not yet Flutter-compiled, Android-device tested, or Windows-device tested.** Do not substitute old version-3 binaries for this release.

## Changes addressed

1. Subject folder swatches are selected from the active theme's five-color palette.
2. Wider responsive desktop content with five-column folders where space allows.
3. True-black dark canvas with muted, consistent outlines and colourful accents instead of white borders.
4. Card hover, press, entry, theme-switch, and route transitions; optional haptic feedback.
5. Rescue My Day and Weekly Story no longer in the app navigation/source.
6. Linked Flow Planner: pan/zoom goal -> task/habit/idea connections, interactive task details.
7. Flow Planner and Constellation have their own navigable pages/tabs.
8. Subjects use a recognizable drawn folder silhouette rather than square cards.
9. Thirty-two selectable emojis for subjects and habits.
10. The UI invalidates and reloads task data after adding/editing tasks, and refetches when tabs change.
11. Tour opens real feature screens; includes an interactive example and direct create-action buttons.
12. Three layout preferences (Comfort / Compact / Studio) for both mobile and desktop.
13. Wider desktop content and more direct Home actions.
14. Developer information linked from Home and the application toolbar.
15. Visible Customize UI button, shared with Settings, includes themes and layout picker.
16. Durable points ledger: task 2, habit check-in 4, every seven consecutive habit days 8, goal 15. Fourteen ranks from Bronze to Ascendant, with increasing point and real-day gates (last tier >=365 days), plus optional Prestige that preserves records and rewards. Award events are unique so toggling task completion cannot repeatedly award points.

## Technical details

- SQLite schema increases **3 → 4**, migrating existing task/goal/habit information and adding `progression` and immutable `rewards` collections.
- Local Wi-Fi sync snapshot version changes **3 → 4**. Update **both** devices before attempting to sync; old and new versions intentionally reject incompatible snapshots instead of silently deleting user data.
- The app remains offline-first with no ads or required account. The user can continue without using sync.
- For phone sizes, icon-first bottom navigation accommodates seven tabs. Desktop navigation uses a rail; tablet/desktop pages support swipe and mouse input.

## Actual verification done in this environment

- SQL schema initialization and reward uniqueness/integrity tested using an in-memory SQLite instance.
- Checked source imports and balanced punctuation on touched Dart files with a lexical scan.
- Checked ZIP integrity after packaging.
- **NOT yet run:** `flutter pub get`, `dart format`, `flutter analyze`, `flutter test`, Android APK build, Windows release build, real device responsiveness, runtime QA, Wi-Fi sync across two updated devices.

## Android and Windows CI

The `Karya_4.0_Flutter_Source.zip` upload triggers **Karya 4 Android test build** and **Karya 4 Windows desktop build** on the existing `Nived-the-dev/Karya` GitHub repository. Existing 3.0 builds remain untouched.

Successful automated builds are a step toward release, not proof of error-free navigation or live sync. Verify the app on a real laptop/phone and back up existing data before upgrading.
