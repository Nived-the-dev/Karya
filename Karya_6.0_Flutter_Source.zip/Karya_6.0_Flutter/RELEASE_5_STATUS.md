# Kārya 5.0 candidate — actual test status

**Do not distribute this as a verified release yet.** This is an editable source candidate. It has not been compiled with Flutter or installed on an Android or Windows device in this session.

## Implemented source changes

- Left-tab folder silhouette based on the submitted sample, folder colors bound to active theme.
- Dark-mode borders and shadows use white on pure black; Soft Pop and Forest palettes strengthened.
- Removed the Constellation and Chaos Dump screens/source and retired navigation entries.
- Home no longer shows shortcuts under rank/progression tile.
- Mobile bottom navigation: Home, Tasks, Calendar, Flow, More; desktop scrollable navigation panel.
- Planner canvas: pan/zoom, node drag mode, persistent local node positions, linked goal/task/habit/idea connections and editing controls; **not** full diagram.net parity.
- Calendar month/day planner with task completion, habit schedule and goal date indicators.
- Progress view options: bar, line, filled-area, and donut charts using saved activity.
- Five points earned once per local calendar date on app opening; progressively higher tier thresholds.
- Wi-Fi sync: either platform can host or connect with a shareable IP|CODE string. One-sided changes flow in either direction; simultaneous independent changes cause a safe stop rather than auto-merge.
- New widget tests for 360px calendar, empty Flow, and the daily reward.

## Requires validation

1. Run `flutter analyze`, `flutter test test`, and both platform build workflows.
2. Open app on real Android and Windows; check 320dp, 360dp, 412dp and tablet sizing with large text.
3. Reproduce reported `_dependents.isEmpty` Flutter assertion and obtain the **first** exception/complete stack trace. An assertion of that form may be secondary to an earlier widget mount exception; cannot claim this has been fixed.
4. Verify existing Kārya 4 SQLite data migrates without loss, including ranking ledger, in both apps.
5. Verify host/client sync in both directions, with credentials and consent, using actual devices. Do not rely on sync as the only backup.
6. Test every editing route and callback, Flow drag zoom, notification permissions and inaccessible network cases.
7. UX/accessibility review per `UI_UX_RESEARCH.md`, including keyboard and screen reader.

## Explicit limits

- No real-time multi-device merge of independently edited conflicting snapshots.
- Node layout coordinates are local per device; task/goal/habit data and explicit links are included in sync snapshots.
- Not a complete diagram.net editor (no freeform shape library, ports, routed connector handles or export).
- Not a bespoke recreation of any video creator's style; uses evidence-based hierarchy and navigation within Kārya's existing brand.
