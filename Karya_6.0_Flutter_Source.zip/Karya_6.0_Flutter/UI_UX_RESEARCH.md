# Kārya 5.0 — UI/UX evidence and design decisions

Kārya uses its own neo-brutalist brand design. Inspiration from Juxtopposed's UI redesign discussions is conceptual (clear hierarchy, thoughtful interactions, visual delight), not a reproduction of someone else's graphics or layouts.

## Findings and resulting design choices

1. **Recognition over recall:** Nielsen Norman Group explains that generic onboarding tutorials are easily forgotten and that users benefit more from contextual instruction. Kārya retains contextual empty states and tooltips, and puts core tasks on visible labeled actions. Source: https://www.nngroup.com/articles/recognition-and-recall/
2. **Progressive disclosure:** A cluttered phone bar is difficult to scan. The bottom navigation now holds four named core destinations plus More, while Windows uses a rail and can reveal secondary modules. Source: https://www.nngroup.com/articles/training-wheels-user-interface/
3. **Physical accessibility:** Android recommends 48dp targets and alternatives to gesture-only functionality. Planner interactions have labeled toolbar buttons in addition to pinch/drag gestures. Source: https://developer.android.com/design/ui/mobile/guides/foundations/accessibility
4. **Input modality:** Windows desktop should have explicit zoom buttons, keyboard- and pointer-friendly navigation, and meaningful hover states. Source: https://learn.microsoft.com/en-us/windows/apps/develop/input/mouse-interactions
5. **Meaningful motion:** Motion should orient users and acknowledge actions, not distract; short card entrance and press transitions stay in the existing visual language. Source: https://learn.microsoft.com/en-us/windows/apps/design/motion/
6. **Progress without compulsion:** Daily opens earn one passive five-point reward, not points for repeated opens or forced notifications. There are no penalties for days away and no artificial urgency or streak-loss threats. This is a product ethics decision, not a claim of clinical psychology evidence.

## Validation still required

- Actual Android handset test at 320, 360, 412, and 600dp widths; text enlargement and screen-reader navigation.
- Windows pointer/keyboard navigation at compact snapped width and ultrawide layouts.
- Flow node dragging, zoom, re-open persistence, and route transition stress tests.
- Local-network pairing in both host directions and conflicting-edits backup/restore testing.
- Privacy/security assessment before exposing Wi-Fi sync beyond a trusted local network.
