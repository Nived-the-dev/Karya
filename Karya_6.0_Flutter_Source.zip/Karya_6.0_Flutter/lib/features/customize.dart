import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/state.dart';
import '../main.dart';
import 'neo.dart';

class CustomizeScreen extends ConsumerWidget {
 const CustomizeScreen({super.key});
 @override Widget build(BuildContext context,WidgetRef ref){
  final mode=ref.watch(themeProvider).value??'system';
  final personality=ref.watch(paletteProvider).value??'Classic';
  final layout=ref.watch(layoutProvider).value??'Comfort';
  return Scaffold(appBar:AppBar(title:const Text('CUSTOMIZE KĀRYA ✦')),
    body:ScreenBody(children:[
      const Headline('MAKE IT FEEL LIKE YOU.',
        'Choose a palette, how it looks, and how much fits on your screen.'),
      const Text('APPEARANCE',style:TextStyle(fontWeight:FontWeight.w900)),
      const SizedBox(height:8),Wrap(spacing:8,children:[
        for(final m in ['light','dark','system'])ChoiceChip(
          label:Text(m=='system'?'Follow device':m=='dark'?'True black':'Light'),
          selected:mode==m,onSelected:(_)=>ref.read(themeProvider.notifier).setTheme(m)),
      ]),const SizedBox(height:15),
      const Text('FIVE COLOR PERSONALITIES',style:TextStyle(fontWeight:FontWeight.w900)),
      const SizedBox(height:9),
      for(final name in themeNames)NeoCard(onTap:()=>ref.read(paletteProvider.notifier).setPalette(name),
        child:Row(children:[for(final color in colorSets[name]!)Padding(
          padding:const EdgeInsets.only(right:5),child:CircleAvatar(radius:10,backgroundColor:color)),
          const SizedBox(width:12),Expanded(child:Text(name,style:const TextStyle(fontWeight:FontWeight.w900))),
          Icon(personality==name?Icons.check_circle:Icons.circle_outlined)])),
      const SizedBox(height:14),
      const Text('THREE LAYOUTS',style:TextStyle(fontWeight:FontWeight.w900)),
      const Text('Comfort is balanced, Compact fits more, Studio gives content more room.'),
      for(final name in layoutNames)NeoCard(onTap:()=>ref.read(layoutProvider.notifier).setLayout(name),
        child:ListTile(contentPadding:EdgeInsets.zero,
          leading:Icon(name=='Compact'?Icons.view_compact:name=='Studio'?Icons.dashboard_customize:Icons.view_agenda),
          title:Text(name),subtitle:Text(switch(name){'Compact'=>'Tighter cards and icon-first navigation',
            'Studio'=>'Wide boards and expanded desktop navigation',_=>'Comfortable defaults for every screen'}),
          trailing:Icon(layout==name?Icons.radio_button_checked:Icons.radio_button_unchecked))),
    ]));
 }
}
