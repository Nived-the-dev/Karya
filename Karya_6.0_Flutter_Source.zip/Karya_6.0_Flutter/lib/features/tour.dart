import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'neo.dart';
import '../core/models.dart';
import 'tasks.dart';
import 'habits.dart';
import 'flow_planner.dart';
import 'calendar_planner.dart';
import 'customize.dart';
import 'ideas.dart';
import 'ranks.dart';

/// Interactive first-run tour. Users can try REAL screens rather than merely
/// paging through marketing illustrations; nothing is saved without confirmation.
class TourScreen extends ConsumerStatefulWidget {
 const TourScreen({super.key});
 @override ConsumerState<TourScreen> createState()=>_TourScreenState();
}
class _TourScreenState extends ConsumerState<TourScreen> {
 int step=0;
 bool demoTask=false;
 static const titles=<String>[
  'WELCOME TO KĀRYA ✦','SUBJECT FOLDERS','ADD A TASK IN SECONDS',
  'TRACK HABITS','SAVE YOUR IDEAS','DRAW YOUR FLOW',
  'PLAN YOUR WEEK','CUSTOMIZE EVERYTHING','GROW AT YOUR OWN PACE',
 ];
 static const descriptions=<String>[
  'Tasks, habits and ideas together. No ads and no account required.',
  'Folders group the things you care about. Pick a color and an emoji that feel like you.',
  'Tap a task to see the satisfying little completion animation. Your tasks are saved offline.',
  'Mark what you finish. Days off never remove your achievements.',
  'Put loose thoughts here. Link ideas to work later.',
  'Make a goal, then connect tasks and habits in a real flow chart.',
  'See due dates, goal milestones and scheduled habits together in one simple calendar.',
  'Try true-black dark mode, 5 palettes, and 3 layouts for every screen.',
  'Earn points, unlock ranks, and Prestige after your year-long journey.',
 ];
 static const symbols=<IconData>[
  Icons.waving_hand,Icons.folder_outlined,Icons.add_task,
  Icons.check_circle_outline,Icons.lightbulb_outline,Icons.account_tree_outlined,
  Icons.calendar_month_outlined,Icons.palette_outlined,Icons.workspace_premium_outlined,
 ];
 Future<void> explore() async {
  if(step==1){await showSubjectEditor(context,ref,null);}
  if(step==2){await quickAddTask(context,ref);}
  if(step==3){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const HabitsScreen()));}
  if(step==4){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const IdeasScreen()));}
  if(step==5){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const FlowPlannerScreen()));}
  if(step==6){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const CalendarPlannerScreen()));}
  if(step==7){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const CustomizeScreen()));}
  if(step==8){await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const RanksScreen()));}
  if(mounted && step<titles.length-1)setState(()=>step++);
 }
 @override Widget build(BuildContext context){
  final color=Theme.of(context).colorScheme.primary;
  return Scaffold(appBar:AppBar(title:const Text('EXPLORE KĀRYA'),
    actions:[TextButton(onPressed:()=>context.pop(),child:const Text('SKIP'))]),
   body:SafeArea(child:Center(child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:670),
    child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
      LinearProgressIndicator(value:(step+1)/titles.length,minHeight:6),
      Expanded(child:SingleChildScrollView(child:Padding(padding:const EdgeInsets.symmetric(vertical:26),
        child:Column(children:[
          AnimatedSwitcher(duration:const Duration(milliseconds:260),child:CircleAvatar(
            key:ValueKey(step),radius:49,backgroundColor:color.withValues(alpha:.12),
            child:Icon(symbols[step],size:53,color:color))),
          const SizedBox(height:24),
          Text(titles[step],textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height:12),Text(descriptions[step],textAlign:TextAlign.center),
          const SizedBox(height:28),
          if(step==2)NeoCard(color:colorFor(2),onTap:()=>setState(()=>demoTask=!demoTask),
            child:Row(children:[Icon(demoTask?Icons.check_box:Icons.check_box_outline_blank,
              color:Colors.black),const SizedBox(width:12),
              Expanded(child:Text('Try tapping this sample task',style:TextStyle(
                color:Colors.black,fontWeight:FontWeight.w900,
                decoration:demoTask?TextDecoration.lineThrough:null)))])),
          if(step==1)Container(height:110,width:140,padding:const EdgeInsets.all(20),
            decoration:BoxDecoration(color:colorFor(3),borderRadius:BorderRadius.circular(18)),
            child:const Column(children:[Icon(Icons.folder,size:39,color:Colors.black),
              Text('Your subjects',style:TextStyle(color:Colors.black,fontWeight:FontWeight.bold))])),
          if(step>0)NeoButton(label:switch(step){
            1=>'TRY: CREATE A SUBJECT',2=>'TRY: ADD A REAL TASK',3=>'TRY: CREATE A HABIT',
            4=>'EXPLORE YOUR NOTES',5=>'OPEN FLOW PLANNER',6=>'OPEN CALENDAR',
            7=>'TRY THEMES AND LAYOUTS',_=>'VIEW YOUR RANK MAP'},
            icon:Icons.touch_app,onPressed:explore),
        ])))),
      Row(children:[TextButton(onPressed:step==0?null:()=>setState(()=>step--),child:const Text('BACK')),
        const Spacer(),Text('${step+1} / ${titles.length}'),const Spacer(),
        FilledButton(onPressed:(){if(step==titles.length-1){context.pop();}else{setState(()=>step++);}},
          child:Text(step==titles.length-1?'FINISH':'NEXT →'))]),
    ]))))));
 }
}
