import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/state.dart';
import '../core/models.dart';
import 'neo.dart';

final ideasProvider=FutureProvider<List<Idea>>((ref)=>ref.watch(dbProvider).loadIdeas());

/// A compact offline notes board. Note bodies stay in the original synced SQLite
/// database; cosmetic color selection lives in local device preferences.
class IdeasScreen extends ConsumerStatefulWidget {
  const IdeasScreen({super.key});
  @override ConsumerState<IdeasScreen> createState()=>_IdeasScreenState();
}
class _IdeasScreenState extends ConsumerState<IdeasScreen> {
  String query='';
  final colors=<Color>[const Color(0xFFFFE8A8),const Color(0xFFD9F2E4),
    const Color(0xFFE8DDFD),const Color(0xFFFFDFE9),const Color(0xFFDCEBFF)];
  final colorIndexes=<int,int>{};
  @override void initState(){super.initState();_loadColors();}
  Future<void> _loadColors() async {
    final pref=await SharedPreferences.getInstance();
    for(final key in pref.getKeys().where((k)=>k.startsWith('note_color:'))){
      final id=int.tryParse(key.substring(11));if(id!=null)colorIndexes[id]=pref.getInt(key)??0;
    }
    if(mounted)setState((){});
  }
  Future<void> edit(Idea? idea) async {
    if(!mounted)return;
    final lines=(idea?.body??'').split('\n');
    final title=TextEditingController(text:idea==null?'':lines.first);
    final body=TextEditingController(text:idea==null?'':lines.skip(1).join('\n'));
    var pinned=idea?.pinned??false;
    var color=colorIndexes[idea?.id]??0;
    var savedId=idea?.id;
    Timer? debounce;
    bool writing=false;
    Future<void> save() async {
      final heading=title.text.trim(),text=body.text.trim();
      if(heading.isEmpty&&text.isEmpty)return;
      if(writing)return;
      writing=true;
      try {
        savedId=await ref.read(dbProvider).saveIdea(
          id:savedId,body:[heading,text].where((s)=>s.isNotEmpty).join('\n'),pinned:pinned);
        await (await SharedPreferences.getInstance()).setInt('note_color:$savedId',color);
        ref.invalidate(ideasProvider);
      } finally { writing=false; }
    }
    void schedule() {debounce?.cancel();debounce=Timer(const Duration(milliseconds:650),(){save();});}
    try {
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,
        useSafeArea:true,showDragHandle:true,builder:(sheet)=>StatefulBuilder(builder:(ctx,update)=>
        Padding(padding:EdgeInsets.fromLTRB(16,5,16,MediaQuery.viewInsetsOf(ctx).bottom+20),
          child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,
            crossAxisAlignment:CrossAxisAlignment.start,children:[
              Row(children:[Expanded(child:Text(idea==null?'NEW NOTE':'EDIT NOTE',
                style:Theme.of(ctx).textTheme.titleLarge)),
                IconButton(tooltip:'Pin note',icon:Icon(pinned?Icons.push_pin:Icons.push_pin_outlined),
                  onPressed:(){update(()=>pinned=!pinned);schedule();}),
                TextButton(onPressed:()async{await save();if(ctx.mounted)Navigator.pop(ctx);},
                  child:const Text('DONE'))]),
              const SizedBox(height:10),
              TextField(controller:title,maxLength:160,autofocus:idea==null,onChanged:(_)=>schedule(),
                textCapitalization:TextCapitalization.sentences,style:Theme.of(ctx).textTheme.titleLarge,
                decoration:const InputDecoration(hintText:'Title',counterText:'')),
              const SizedBox(height:7),
              TextField(controller:body,minLines:5,maxLines:12,onChanged:(_)=>schedule(),
                textCapitalization:TextCapitalization.sentences,
                decoration:const InputDecoration(hintText:'Take a note…')),
              const SizedBox(height:12),
              Text('NOTE COLOR',style:Theme.of(ctx).textTheme.labelLarge),
              Wrap(spacing:10,children:[for(var i=0;i<colors.length;i++)IconButton(
                tooltip:'Note color ${i+1}',onPressed:(){update(()=>color=i);schedule();},
                icon:CircleAvatar(backgroundColor:colors[i],child:color==i
                  ?const Icon(Icons.check,color:Colors.black):null))]),
              const Text('Auto-saves after typing. Press Done to save immediately.',
                style:TextStyle(fontSize:12)),
            ])))));
    }finally{
      debounce?.cancel();await save();
      // Do not dispose a TextField controller until the route finishes its animation.
      Future<void>.delayed(const Duration(milliseconds:400),(){title.dispose();body.dispose();});
    }
  }
  Future<void> _convert(Idea idea) async {
    final name=idea.body.split('\n').first.trim();if(name.isEmpty)return;
    await ref.read(appProvider.notifier).change((db)=>db.transaction(()async{
      final id=await db.saveTask(title:name.length>180?name.substring(0,180):name,
        description:idea.body.split('\n').skip(1).join('\n'));
      await db.addLink('idea',idea.id,'task',id);
    }));
    if(mounted)toast(context,'Created a task from this note.');
  }
  @override Widget build(BuildContext context){
    final notes=ref.watch(ideasProvider);
    return notes.when(loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('Could not load notes: $e')),
      data:(items){
        final filtered=items.where((n)=>n.body.toLowerCase().contains(query.toLowerCase())).toList();
        final layoutWidth=MediaQuery.sizeOf(context).width;
        final columns=layoutWidth>=1100?4:layoutWidth>=750?3:layoutWidth>=500?2:1;
        return ScreenBody(children:[
          Row(children:[Expanded(child:Text('NOTES',style:Theme.of(context).textTheme.headlineMedium)),
            FilledButton.icon(onPressed:()=>edit(null),icon:const Icon(Icons.add),label:const Text('New'))]),
          const SizedBox(height:12),
          TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(
            prefixIcon:Icon(Icons.search),hintText:'Search your notes')),
          const SizedBox(height:14),
          if(filtered.isEmpty)const EmptyState('Nothing here yet.',
            'Save a thought, checklist or idea. Your notes stay on this device.',icon:Icons.sticky_note_2_outlined),
          if(filtered.isNotEmpty)LayoutBuilder(builder:(context,size){
            final count=size.maxWidth<540?1:columns;
            return GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
              itemCount:filtered.length,gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount:count,crossAxisSpacing:12,mainAxisSpacing:12,
                mainAxisExtent:210),itemBuilder:(context,index){
                final idea=filtered[index],parts=idea.body.split('\n');
                final background=colors[(colorIndexes[idea.id]??0)%colors.length];
                return NeoCard(color:background,padding:const EdgeInsets.all(13),onTap:()=>edit(idea),
                  child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                    Row(children:[Expanded(child:Text(parts.first,maxLines:2,
                      overflow:TextOverflow.ellipsis,style:const TextStyle(
                        color:Colors.black,fontWeight:FontWeight.w900,fontSize:17))),
                      if(idea.pinned)const Icon(Icons.push_pin,color:Colors.black,size:18)]),
                    const SizedBox(height:8),
                    Expanded(child:Text(parts.skip(1).join('\n'),maxLines:5,overflow:TextOverflow.ellipsis,
                      style:const TextStyle(color:Colors.black))),
                    Row(mainAxisAlignment:MainAxisAlignment.end,children:[
                      IconButton(tooltip:'Turn note into task',icon:const Icon(Icons.add_task,color:Colors.black),
                        onPressed:()=>_convert(idea)),
                      IconButton(tooltip:'Delete note',icon:const Icon(Icons.delete_outline,color:Colors.black),
                        onPressed:()async{if(!await confirmDelete(context,'note'))return;
                          await ref.read(appProvider.notifier).change((db)=>db.removeIdea(idea.id));
                          ref.invalidate(ideasProvider);
                        }),
                    ]),
                  ]));
              });
          }),
        ]);
      });
  }
}
