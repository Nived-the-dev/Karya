import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'ideas.dart';

/// Flow connections are composed of explicit user links; nothing is inferred or uploaded.
class GoalsScreen extends ConsumerWidget {
  const GoalsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar: AppBar(title: const Text('CONNECT YOUR FLOW ✦')),
    body: ref.watch(appProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Could not load goals: $e')),
      data: (data) => ScreenBody(children: [
        const Headline('BIG THINGS, SMALL STEPS.',
          'Link tasks, habits and ideas to a goal. Every step counts.'),
        NeoButton(label: '+ NEW GOAL', icon: Icons.add_circle_outline,
          onPressed: () => editGoal(context, ref)),
        if (data.goals.isEmpty) const EmptyState('Start with a goal.',
          'Your first milestone can be as simple as finishing a chapter.',
          icon: Icons.flag_outlined),
        for (final goal in data.goals) _GoalTile(goal: goal, data: data),
      ]),
    ),
  );
}

class _GoalTile extends ConsumerWidget {
  const _GoalTile({required this.goal, required this.data});
  final KaryaGoal goal;
  final AppData data;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final related = data.links.where((l) => l.touches('goal', goal.id)).toList();
    final ideas=ref.watch(ideasProvider).value??const <Idea>[];
    final done = related.where((l) {
      if (l.fromType == 'task') return data.tasks.any((t) => t.id == l.fromId && t.completed);
      if (l.toType == 'task') return data.tasks.any((t) => t.id == l.toId && t.completed);
      if (l.fromType == 'habit') return data.habits.any((h) => h.id == l.fromId && h.doneOn(DateTime.now()));
      if (l.toType == 'habit') return data.habits.any((h) => h.id == l.toId && h.doneOn(DateTime.now()));
      return false;
    }).length;
    return NeoCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(goal.done ? Icons.flag : Icons.flag_outlined),
        const SizedBox(width: 10),
        Expanded(child: Text(goal.title, style: Theme.of(context).textTheme.titleLarge)),
        IconButton(tooltip: 'Edit goal', onPressed: () => editGoal(context, ref, goal), icon: const Icon(Icons.edit_outlined)),
      ]),
      if (goal.description.isNotEmpty) Text(goal.description),
      if (goal.targetDay != null) Text('Target: ${goal.targetDay}'),
      const SizedBox(height: 8),
      Text('${related.length} connected items • $done completed or checked in today',
          style: Theme.of(context).textTheme.bodySmall),
      const SizedBox(height: 8),
      for (final link in related) Row(children: [
        Icon(Icons.account_tree_outlined, size: 17),
        const SizedBox(width: 6),
        Expanded(child: Text(_linkTitle(link, goal.id, data, ideas), maxLines: 2,
          overflow: TextOverflow.ellipsis)),
        IconButton(tooltip: 'Unlink item', icon: const Icon(Icons.link_off, size: 18),
          onPressed: () => ref.read(appProvider.notifier).change((db) => db.removeLink(link.id))),
      ]),
      Wrap(spacing: 6, children: [
        OutlinedButton.icon(icon: const Icon(Icons.add_link), label: const Text('Link an item'),
          onPressed: () => _chooseLink(context, ref, goal, data)),
        OutlinedButton.icon(icon: Icon(goal.done ? Icons.replay : Icons.check),
          label: Text(goal.done ? 'Reopen' : 'Complete goal'),
          onPressed: () => ref.read(appProvider.notifier).change((db) => db.saveGoal(
            id: goal.id, title: goal.title, description: goal.description,
            targetDay: goal.targetDay, done: !goal.done))),
      ]),
    ]));
  }
}

String _linkTitle(KaryaLink l, int goalId, AppData data, List<Idea> ideas) {
  final type = l.fromType == 'goal' && l.fromId == goalId ? l.toType : l.fromType;
  final id = l.fromType == 'goal' && l.fromId == goalId ? l.toId : l.fromId;
  switch (type) {
    case 'task':
      for (final t in data.tasks) { if (t.id == id) return 'Task • ${t.title}'; }
      break;
    case 'habit':
      for (final h in data.habits) { if (h.id == id) return 'Habit • ${h.name}'; }
      break;
    case 'subject':
      for (final s in data.subjects) { if (s.id == id) return 'Subject • ${s.name}'; }
      break;
    case 'idea':
      for (final i in ideas) { if (i.id == id) return 'Idea • ${i.body.split('\n').first}'; }
      break;
  }
  return '$type #$id';
}

Future<void> _chooseLink(BuildContext context, WidgetRef ref,
    KaryaGoal goal, AppData data) async {
  final db = ref.read(dbProvider);
  final ideas = await db.loadIdeas();
  if (!context.mounted) return;
  final choices = <({String type, int id, String label})>[
    for (final t in data.tasks) (type: 'task', id: t.id, label: 'Task • ${t.title}'),
    for (final h in data.habits) (type: 'habit', id: h.id, label: 'Habit • ${h.name}'),
    for (final s in data.subjects) (type: 'subject', id: s.id, label: 'Subject • ${s.name}'),
    for (final i in ideas) (type: 'idea', id: i.id, label: 'Idea • ${i.body.split('\n').first}'),
  ];
  await showModalBottomSheet<void>(context: context, isScrollControlled: true,
    showDragHandle: true, useSafeArea: true, builder: (sheet) => SizedBox(
      height: MediaQuery.sizeOf(sheet).height * .6,
      child: Column(children: [
        const Padding(padding: EdgeInsets.all(12), child: Text('LINK TO THIS GOAL')),
        Expanded(child: ListView.builder(itemCount: choices.length, itemBuilder: (ctx, index) {
          final c = choices[index];
          return ListTile(title: Text(c.label, maxLines: 2, overflow: TextOverflow.ellipsis),
            onTap: () async {
              await ref.read(appProvider.notifier).change((db) => db.addLink('goal', goal.id, c.type, c.id));
              if (ctx.mounted) Navigator.pop(ctx);
            });
        })),
      ]),
    ));
}

Future<void> editGoal(BuildContext context, WidgetRef ref, [KaryaGoal? goal]) async {
  final title = TextEditingController(text: goal?.title ?? '');
  final description = TextEditingController(text: goal?.description ?? '');
  DateTime? target = goal?.targetDay == null ? null : DateTime.tryParse(goal!.targetDay!);
  try {
    await showModalBottomSheet<void>(context: context, isScrollControlled: true,
      useSafeArea: true, showDragHandle: true, builder: (sheet) => StatefulBuilder(
      builder: (sheet, update) => Padding(
        padding: EdgeInsets.fromLTRB(16, 8, 16, MediaQuery.viewInsetsOf(sheet).bottom + 20),
        child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(goal == null ? 'NEW GOAL' : 'EDIT GOAL', style: Theme.of(sheet).textTheme.titleLarge),
          const SizedBox(height: 10),
          TextField(controller: title, maxLength: 180, decoration: const InputDecoration(labelText: 'Goal title')),
          const SizedBox(height: 8),
          TextField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'Why it matters (optional)')),
          OutlinedButton.icon(icon: const Icon(Icons.calendar_month_outlined),
            label: Text(target == null ? 'Optional target date' : dayKey(target!)),
            onPressed: () async {
              final date = await showDatePicker(context: sheet, firstDate: DateTime(2020),
                lastDate: DateTime(2100), initialDate: target ?? DateTime.now());
              if (date != null) update(() => target = date);
            }),
          FilledButton(onPressed: () async {
            if (title.text.trim().isEmpty) return;
            await ref.read(appProvider.notifier).change((db) => db.saveGoal(id: goal?.id,
              title: title.text, description: description.text,
              targetDay: target == null ? null : dayKey(target!), done: goal?.done ?? false));
            if (sheet.mounted) Navigator.pop(sheet);
          }, child: const Text('SAVE GOAL')),
          if (goal != null) TextButton.icon(icon: const Icon(Icons.delete_outline),
            label: const Text('Delete goal'), onPressed: () async {
              if (!await confirmDelete(sheet, 'goal')) return;
              await ref.read(appProvider.notifier).change((db) => db.deleteGoal(goal.id));
              if (sheet.mounted) Navigator.pop(sheet);
            }),
        ]))),
      ));
  } finally { title.dispose(); description.dispose(); }
}
