import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'neo.dart';

/// Contextual, skippable tutorials. A user can replay any explanation at any time.
const featureHelp = <({String title, IconData icon, List<String> steps, String action})>[
  (title:'Home and subjects', icon:Icons.home_outlined,action:'Create a subject',steps:[
    'Home is your overview: subjects, tasks due soon and a quick-add button.',
    'Tap Create a Subject to give related tasks a shared folder.',
    'Tap a folder to open Tasks filtered to that subject. Long names are truncated, not deleted.'
  ]),
  (title:'Tasks and reminders', icon:Icons.check_box_outlined,action:'Add a task',steps:[
    'Use Add Task to write a title; description, subject, priority and deadline are optional.',
    'A task only appears on Calendar when you assign a due date. Multiple tasks may share a day.',
    'Choose a reminder time. In Settings, enable notifications and allow Android permission.',
    'Check a task only when it is completed. Open a task to add or check individual steps.'
  ]),
  (title:'Calendar', icon:Icons.calendar_month_outlined,action:'Pick a day',steps:[
    'Choose a date to see every task, its deadline time and its full description.',
    'Tap Add task on that date. A date is prefilled; you can add as many tasks as you need.',
    'Use the month arrows to move through dates. Colored dots indicate planned activity.',
    'Edits you save on Calendar also appear in Tasks, and vice versa.'
  ]),
  (title:'Flow Planner',icon:Icons.account_tree_outlined,action:'Make a goal',steps:[
    'Create a goal, then connect existing tasks and habits using the link icon.',
    'Use Pan mode to drag the background and pinch with two fingers to zoom.',
    'Use Move mode to position one card. Positions persist after you leave the screen.',
    'Use the zoom controls and reset option if you lose track of your plan.'
  ]),
  (title:'Habits',icon:Icons.auto_awesome_outlined,action:'Create a habit',steps:[
    'Create a habit, choose its weekdays and optionally set a daily reminder.',
    'Tap the checkbox only after following the habit on that date.',
    'Habit progress tracks your actual chosen schedule, not days you were never meant to do it.'
  ]),
  (title:'Progress',icon:Icons.bar_chart_outlined,action:'View your activity',steps:[
    'Switch between bar, line, area and donut views of recorded habit check-ins.',
    'The heatmap shows days with scheduled check-ins; it is not a grade.',
    'You can always return after time away. A missed day should not prevent a new start.'
  ]),
  (title:'Ideas and notes',icon:Icons.lightbulb_outline,action:'Write a note',steps:[
    'Ideas is a private offline notepad for rough thoughts, lists and plans.',
    'Pin important ideas, search text, or link a note to an existing goal.',
    'Use Convert to task when an idea becomes something actionable.'
  ]),
  (title:'Private Wi-Fi sync',icon:Icons.wifi_tethering_outlined,action:'Pair devices',steps:[
    'Put both devices on the same trusted local Wi-Fi. On Windows, allow Kārya through the firewall on private networks.',
    'On either device, choose Start Sharing. On the other, enter its local IP and pairing code, then Connect.',
    'Keep the host app open while syncing. You can repeat the process in the other direction.',
    'If both devices contain independent edits, Kārya pauses rather than overwriting data. Keep separate backups before resolving conflicts.'
  ]),
  (title:'Journey and points',icon:Icons.workspace_premium_outlined,action:'Explore ranks',steps:[
    'Journey shows your milestones and how many points are recorded.',
    'Rewards are intended to celebrate tasks and habits you genuinely completed.',
    'You can choose your own pace. Your rank is not a measure of your worth or productivity.'
  ]),
  (title:'Appearance and privacy',icon:Icons.palette_outlined,action:'Change theme',steps:[
    'Open Customize to choose color theme, light/dark mode, and layout.',
    'On Android, More contains Ideas, Habits, Progress, Journey, Wi-Fi sync and Help.',
    'Kārya works offline; optional Wi-Fi sync is direct and needs no cloud account.'
  ]),
];

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key,this.initialTopic});
  final int? initialTopic;
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('HELP & GUIDES')),
    body:ScreenBody(children:[
      const Headline('LEARN KĀRYA','Small lessons you can revisit whenever you need.'),
      const Text('Choose any feature to see exactly how it works. Nothing here changes your data.'),
      const SizedBox(height:12),
      for(var i=0;i<featureHelp.length;i++)NeoCard(onTap:()=>showFeatureGuide(context,i),child:Row(children:[
        Icon(featureHelp[i].icon),const SizedBox(width:14),
        Expanded(child:Text(featureHelp[i].title,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w800))),
        const Icon(Icons.chevron_right_rounded),
      ])),
      const SizedBox(height:8),
      OutlinedButton.icon(onPressed:()=>context.push('/tour'),icon:const Icon(Icons.school_outlined),
        label:const Text('Replay guided app tour')),
    ]),
  );
}
Future<void> showFeatureGuide(BuildContext context,int index) async {
  if(index<0||index>=featureHelp.length)return;
  final feature=featureHelp[index];
  await showModalBottomSheet<void>(context:context,isScrollControlled:true,useSafeArea:true,
    showDragHandle:true,builder:(sheet)=>Padding(
      padding:EdgeInsets.fromLTRB(20,8,20,MediaQuery.viewInsetsOf(sheet).bottom+24),
      child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Row(children:[Icon(feature.icon,size:26),const SizedBox(width:10),
          Expanded(child:Text(feature.title,style:Theme.of(sheet).textTheme.titleLarge))]),
        const SizedBox(height:14),
        for(var i=0;i<feature.steps.length;i++)Padding(padding:const EdgeInsets.symmetric(vertical:9),
          child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
            CircleAvatar(radius:13,child:Text('${i+1}',style:const TextStyle(fontSize:12))),
            const SizedBox(width:12),Expanded(child:Text(feature.steps[i])),
          ])),
        const SizedBox(height:12),FilledButton.icon(onPressed:()=>Navigator.pop(sheet),
          icon:const Icon(Icons.check),label:const Text('Got it')),
      ]))),
    );
}
