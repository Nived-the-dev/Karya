import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'goals.dart';
import 'ideas.dart';
import 'neo.dart';
import 'tasks.dart';

/// A free-pan, zoomable workspace of connected, editable goals and real tasks.
/// Drag Mode enables node positioning; Pan Mode keeps the canvas easy to explore.
class FlowPlannerScreen extends ConsumerStatefulWidget {
  const FlowPlannerScreen({super.key});
  @override ConsumerState<FlowPlannerScreen> createState()=>_FlowPlannerScreenState();
}

class _DiagramNode {
  const _DiagramNode(this.key,this.type,this.id,this.name,this.done,this.group);
  final String key,type,name;
  final int id,group;
  final bool done;
}
class _DiagramEdge {
  const _DiagramEdge(this.source,this.target);
  final String source,target;
}
class _FlowPlannerScreenState extends ConsumerState<FlowPlannerScreen> {
  final viewport=TransformationController();
  final offsets=<String,Offset>{};
  bool editing=false,initialized=false;
  double width=880,height=620;

  @override
  void initState(){super.initState();_load();}
  Future<void> _load() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in prefs.getKeys().where((key)=>key.startsWith('diagram:'))){
      final coordinates=prefs.getStringList(key);
      if(coordinates?.length!=2)continue;
      final x=double.tryParse(coordinates![0]),y=double.tryParse(coordinates[1]);
      if(x!=null&&y!=null&&x.isFinite&&y.isFinite){
        offsets[key.substring(8)]=Offset(x.clamp(0.0,5000.0).toDouble(),y.clamp(0.0,5000.0).toDouble());
      }
    }
    if(mounted)setState((){});
  }
  @override void dispose(){viewport.dispose();super.dispose();}
  Future<void> _move(String key,Offset next) async {
    if(!mounted)return;
    setState(()=>offsets[key]=next);
  }
  Future<void> _savePosition(String key) async {
    final position=offsets[key];if(position==null)return;
    final prefs=await SharedPreferences.getInstance();
    await prefs.setStringList('diagram:$key',[
      position.dx.toStringAsFixed(1),position.dy.toStringAsFixed(1)]);
  }
  void _zoom(double factor){
    final current=viewport.value.getMaxScaleOnAxis();
    final target=(current*factor).clamp(.30,3.5).toDouble();
    viewport.value=viewport.value.clone()..scale(target/current);
  }
  Future<void> _resetPositions() async {
    final prefs=await SharedPreferences.getInstance();
    for(final key in offsets.keys)await prefs.remove('diagram:$key');
    setState(()=>offsets.clear());
  }
  void _fit(double screenWidth) {
    if(initialized)return;
    initialized=true;
    WidgetsBinding.instance.addPostFrameCallback((_){
      if(!mounted)return;
      final scale=math.min(1.0,math.max(.42,(screenWidth-20)/width));
      viewport.value=Matrix4.identity()..scale(scale);
    });
  }
  @override Widget build(BuildContext context){
    final app=ref.watch(appProvider);
    final ideas=ref.watch(ideasProvider).value??const <Idea>[];
    return app.when(
      loading:()=>const Center(child:CircularProgressIndicator()),
      error:(error,_)=>Center(child:Text('Flow Planner unavailable: $error')),
      data:(data){
        final nodes=<_DiagramNode>[];
        final edges=<_DiagramEdge>[];
        for(var i=0;i<data.goals.length;i++){
          final goal=data.goals[i];
          nodes.add(_DiagramNode('goal:${goal.id}','goal',goal.id,goal.title,goal.done,i));
          for(final link in data.links.where((l)=>l.touches('goal',goal.id))){
            final type=link.fromType=='goal'&&link.fromId==goal.id?link.toType:link.fromType;
            final id=link.fromType=='goal'&&link.fromId==goal.id?link.toId:link.fromId;
            String? name;
            bool done=false;
            if(type=='task'){
              for(final t in data.tasks.where((t)=>t.id==id)){name=t.title;done=t.completed;}
            } else if(type=='habit'){
              for(final h in data.habits.where((h)=>h.id==id)){name=h.name;done=h.doneOn(DateTime.now());}
            } else if(type=='idea'){
              for(final idea in ideas.where((n)=>n.id==id)){name=idea.body.split('\n').first;}
            } else if(type=='goal'){
              for(final g in data.goals.where((g)=>g.id==id)){name=g.title;done=g.done;}
            } else if(type=='subject'){
              for(final subject in data.subjects.where((s)=>s.id==id)){name=subject.name;}
            }
            if(name==null)continue;
            final key='$type:$id';
            if(!nodes.any((n)=>n.key==key))nodes.add(_DiagramNode(key,type,id,name,done,i));
            edges.add(_DiagramEdge('goal:${goal.id}',key));
          }
        }
        final pos=<String,Offset>{};
        for(final n in nodes){
          final cluster=nodes.where((m)=>m.group==n.group&&m.type!='goal').toList();
          final row=n.type=='goal'?0:cluster.indexWhere((m)=>m.key==n.key);
          final initial=Offset(n.type=='goal'?32:350,
            36+n.group*math.max(190.0,70.0*cluster.length+65)+(n.type=='goal'?24:row*76));
          pos[n.key]=offsets[n.key]??initial;
        }
        width=math.max(790.0,pos.values.fold<double>(0,(v,p)=>math.max(v,p.dx+245))+40);
        height=math.max(560.0,pos.values.fold<double>(0,(v,p)=>math.max(v,p.dy+100))+80);
        return LayoutBuilder(builder:(context,constraints){
          final compact=constraints.maxWidth<650;
          _fit(constraints.maxWidth);
          return Material(color:Theme.of(context).scaffoldBackgroundColor,child:Column(children:[
            Padding(padding:const EdgeInsets.fromLTRB(14,12,14,4),child:
              Row(children:[
                Expanded(child:Text('FLOW PLANNER',style:Theme.of(context).textTheme.headlineMedium,
                  maxLines:1,overflow:TextOverflow.ellipsis)),
                IconButton(tooltip:'New goal',icon:const Icon(Icons.add_circle_outline),
                  onPressed:()=>editGoal(context,ref)),
                IconButton(tooltip:'Connect goals and tasks',icon:const Icon(Icons.add_link_rounded),
                  onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const GoalsScreen()))),
              ])),
            Padding(padding:const EdgeInsets.symmetric(horizontal:14),child:Wrap(
              alignment:WrapAlignment.start,runSpacing:2,spacing:6,children:[
                FilterChip(label:Text(editing?'Move nodes':'Pan canvas'),
                  selected:editing,onSelected:(_)=>setState(()=>editing=!editing),
                  avatar:Icon(editing?Icons.open_with:Icons.pan_tool_alt_outlined,size:17)),
                IconButton(tooltip:'Zoom out',icon:const Icon(Icons.zoom_out),onPressed:()=>_zoom(.8)),
                IconButton(tooltip:'Zoom in',icon:const Icon(Icons.zoom_in),onPressed:()=>_zoom(1.25)),
                IconButton(tooltip:'Reset zoom',icon:const Icon(Icons.center_focus_strong),
                  onPressed:()=>viewport.value=Matrix4.identity()),
                PopupMenuButton<String>(tooltip:'Canvas options',onSelected:(value){if(value=='reset')_resetPositions();},
                  itemBuilder:(_)=>[const PopupMenuItem(value:'reset',child:Text('Reset node positions'))]),
              ])),
            if(compact)Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:5),
              child:Text(editing?'Drag a card to move it. Switch to Pan to explore.':
                'Pinch to zoom · Drag the background to pan · Tap a node to open it.',
                style:Theme.of(context).textTheme.bodySmall)),
            Expanded(child:nodes.isEmpty
              ? Center(child:Padding(padding:const EdgeInsets.all(20),child:Column(
                  mainAxisSize:MainAxisSize.min,children:[
                    const Icon(Icons.account_tree_outlined,size:48),
                    const SizedBox(height:14),const Text('Start with one goal.'),
                    const SizedBox(height:10),FilledButton.icon(onPressed:()=>editGoal(context,ref),
                      icon:const Icon(Icons.add),label:const Text('New goal')),
                  ])))
              :ClipRect(child:InteractiveViewer(
                  transformationController:viewport,
                  minScale:.3,maxScale:3.5,
                  constrained:false,
                  boundaryMargin:const EdgeInsets.all(450),
                  panEnabled:!editing,scaleEnabled:!editing,
                  child:SizedBox(width:width,height:height,child:Stack(children:[
                    Positioned.fill(child:CustomPaint(painter:_GridAndEdges(pos,edges,
                      Theme.of(context).colorScheme.outline,
                      Theme.of(context).brightness==Brightness.dark))),
                    for(final n in nodes)Positioned(
                      left:pos[n.key]!.dx,top:pos[n.key]!.dy,
                      width:n.type=='goal'?235:210,height:84,
                      child:GestureDetector(
                        onPanEnd:!editing?null:(_)=>_savePosition(n.key),
                        onPanUpdate:!editing?null:(details)=>_move(n.key,
                          Offset((pos[n.key]!.dx+details.delta.dx/viewport.value.getMaxScaleOnAxis()).clamp(6.0,width-250.0).toDouble(),
                            (pos[n.key]!.dy+details.delta.dy/viewport.value.getMaxScaleOnAxis()).clamp(6.0,height-96.0).toDouble())),
                        child:NeoCard(color:n.type=='goal'?colorFor(3):null,
                          onTap:editing?null:(){
                            if(n.type=='goal'){
                              final matches=data.goals.where((g)=>g.id==n.id);
                              if(matches.isNotEmpty)editGoal(context,ref,matches.first);
                            }else if(n.type=='task'){
                              final matches=data.tasks.where((t)=>t.id==n.id);
                              if(matches.isNotEmpty)showTaskDetails(context,ref,matches.first);
                            }
                          },
                          padding:const EdgeInsets.symmetric(horizontal:11,vertical:8),
                          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                            Row(children:[Icon(n.done?Icons.check_circle:Icons.circle_outlined,size:14,
                              color:n.type=='goal'?Colors.black:null),const SizedBox(width:5),
                              Text(n.type.toUpperCase(),style:TextStyle(fontSize:10,fontWeight:FontWeight.w900,
                                color:n.type=='goal'?Colors.black:null))]),
                            const SizedBox(height:5),
                            Expanded(child:Text(n.name,maxLines:2,overflow:TextOverflow.ellipsis,
                              style:TextStyle(fontSize:13,fontWeight:FontWeight.w800,
                                color:n.type=='goal'?Colors.black:null))),
                          ]))),
                      ),
                  ]))))),
            const Padding(padding:EdgeInsets.fromLTRB(12,6,12,10),child:Text(
              'Link existing tasks and habits using the chain button. Your work is saved locally.',
              textAlign:TextAlign.center,style:TextStyle(fontSize:11))),
          ]));
        });
      },
    );
  }
}

class _GridAndEdges extends CustomPainter {
  const _GridAndEdges(this.positions,this.edges,this.ink,this.dark);
  final Map<String,Offset> positions;
  final List<_DiagramEdge> edges;
  final Color ink;final bool dark;
  @override void paint(Canvas canvas,Size size){
    final dots=Paint()..color=ink.withValues(alpha:dark ? 0.13 : 0.10);
    for(double x=12;x<size.width;x+=26){
      for(double y=12;y<size.height;y+=26){canvas.drawCircle(Offset(x,y),.75,dots);}
    }
    final line=Paint()..color=ink.withValues(alpha:.7)..strokeWidth=2.3
      ..style=PaintingStyle.stroke;
    final arrow=Paint()..color=ink.withValues(alpha:.8)..style=PaintingStyle.fill;
    for(final e in edges){
      final start=positions[e.source],end=positions[e.target];
      if(start==null||end==null)continue;
      final a=start+const Offset(234,40),b=end+const Offset(0,40);
      final mid=(a.dx+b.dx)/2;
      final path=Path()..moveTo(a.dx,a.dy)..cubicTo(mid,a.dy,mid,b.dy,b.dx,b.dy);
      canvas.drawPath(path,line);
      canvas.drawPath(Path()..moveTo(b.dx-7,b.dy-4)..lineTo(b.dx,b.dy)
        ..lineTo(b.dx-7,b.dy+4)..close(),arrow);
    }
  }
  @override bool shouldRepaint(covariant _GridAndEdges old)=>true;
}
