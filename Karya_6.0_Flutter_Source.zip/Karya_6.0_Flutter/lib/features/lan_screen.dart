import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/lan_sync.dart';
import '../core/state.dart';
import 'neo.dart';

/// Either device can be the host or the client. Both send and receive updates.
/// Conflict safety remains intentional: simultaneous independent changes must
/// be resolved before any snapshot is overwritten.
class LanSyncScreen extends ConsumerStatefulWidget {
  const LanSyncScreen({super.key});
  @override ConsumerState<LanSyncScreen> createState() => _LanSyncScreenState();
}
class _LanSyncScreenState extends ConsumerState<LanSyncScreen> {
  final pairing=TextEditingController();
  String status='Not paired yet';
  String? hostCode;
  List<String> addresses=[];String? selectedAddress;bool rememberHost=false;
  bool busy=false,auto=false,hosting=false;
  @override void initState(){super.initState();_load();}
  Future<void> _load() async {
    final prefs=await SharedPreferences.getInstance();
    final address=prefs.getString('lan_ip')??'';
    final secret=prefs.getString('lan_code')??'';
    pairing.text=address.isEmpty?'':'$address|$secret';
    auto=prefs.getBool('lan_auto')??false;
    hosting=LocalSync.instance.serving;
    hostCode=hosting?prefs.getString('lan_host_code'):null;
    rememberHost=prefs.getBool('lan_share_on_launch')??false;
    try{addresses=await LocalSync.instance.ipv4Addresses();
      selectedAddress=addresses.isEmpty?null:addresses.first;
    }catch(_){ }
    if(mounted)setState((){});
  }
  @override void dispose(){pairing.dispose();super.dispose();}

  Future<void> _startHost() async {
    if(busy)return;
    setState(()=>busy=true);
    try{
      if(LocalSync.instance.serving){
        await LocalSync.instance.stopHost();
        if(mounted)setState((){hosting=false;hostCode=null;status='Sharing stopped';});
      }else{
        final key=await LocalSync.instance.startHost(ref.read(dbProvider));
        addresses=await LocalSync.instance.ipv4Addresses();
        selectedAddress=addresses.isEmpty?null:addresses.first;
        if(mounted)setState((){hosting=true;hostCode=key;status='Ready to pair';});
      }
    }catch(error){if(mounted)setState(()=>status='Could not start Wi-Fi sharing: $error');}
    finally{if(mounted)setState(()=>busy=false);}
  }

  String get connectionCode => '${selectedAddress??''}|${hostCode??''}';

  Future<void> _checkConnection() async {
    final parts=pairing.text.trim().split('|');
    if(parts.length!=2){setState(()=>status='Paste the full IP|CODE from the host.');return;}
    setState(()=>busy=true);
    try{final message=await LocalSync.instance.testConnection(parts[0],parts[1]);
      if(mounted)setState(()=>status=message);
    }catch(e){if(mounted)setState(()=>status='Connection test failed: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> _connect() async {
    if(busy)return;
    final input=pairing.text.trim();
    final parts=input.split('|');
    if(parts.length!=2||parts.any((x)=>x.trim().isEmpty)){
      setState(()=>status='Paste the IP|PAIRING-CODE from your other device.');
      return;
    }
    setState((){busy=true;status='Checking changes on both devices…';});
    try{
      final result=await LocalSync.instance.sync(ref.read(dbProvider),parts[0],parts[1]);
      await ref.read(appProvider.notifier).refresh();
      if(mounted)setState(()=>status=result);
    }catch(error){
      if(mounted)setState(()=>status='$error');
    }finally{if(mounted)setState(()=>busy=false);}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('WI-FI SYNC')),
    body:ScreenBody(children:[
      const Headline('STAY IN SYNC.',
        'Open on both devices. Connect by code on a trusted local Wi-Fi. No account or internet required.'),
      NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('1. SHARE FROM THIS DEVICE',style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:8),
        const Text('On Windows, allow Kārya through Windows Firewall on PRIVATE networks. Your PC and phone must be on the same Wi-Fi. Keep this page open until the first connection is complete.'),
        const SizedBox(height:10),
        NeoButton(label:hosting?'STOP SHARING':'START SHARING',icon:Icons.wifi_tethering,
          onPressed:busy?null:_startHost),
        if(hosting)...[
          const SizedBox(height:12),
          const Text('Copy this connection code to your other device:'),
          if(addresses.length>1)DropdownButton<String>(isExpanded:true,
            value:addresses.contains(selectedAddress)?selectedAddress:addresses.first,
            items:addresses.map((ip)=>DropdownMenuItem(value:ip,child:Text('Use $ip'))).toList(),
            onChanged:(ip)=>setState(()=>selectedAddress=ip)),
          SelectableText(connectionCode,style:const TextStyle(fontWeight:FontWeight.w800)),
          SwitchListTile(contentPadding:EdgeInsets.zero,value:rememberHost,
            title:const Text('Start sharing when I open Kārya'),
            subtitle:const Text('Works while this device and app are awake.'),
            onChanged:(value)async{await (await SharedPreferences.getInstance()).setBool('lan_share_on_launch',value);
              if(mounted)setState(()=>rememberHost=value);}),
          OutlinedButton.icon(icon:const Icon(Icons.copy_all_outlined),
            label:const Text('Copy connection code'),onPressed:()=>Clipboard.setData(
              ClipboardData(text:connectionCode))),
        ],
      ])),
      NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('2. CONNECT FROM THIS DEVICE',style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:10),
        TextField(controller:pairing,autocorrect:false,enableSuggestions:false,
          decoration:const InputDecoration(labelText:'Connection code',
            hintText:'192.168.1.24|ABCDEFGH…')),
        const SizedBox(height:10),
        OutlinedButton.icon(onPressed:busy?null:_checkConnection,
          icon:const Icon(Icons.network_check_outlined),label:const Text('Test connection')),
        const SizedBox(height:8),
        NeoButton(label:busy?'SYNCING…':'SYNC BOTH WAYS',icon:Icons.sync,onPressed:busy?null:_connect),
        SwitchListTile(contentPadding:EdgeInsets.zero,
          value:auto,title:const Text('Automatically sync when connected'),
          subtitle:const Text('Checks every two minutes while the app is open.'),
          onChanged:(enabled)async{
            await (await SharedPreferences.getInstance()).setBool('lan_auto',enabled);
            if(mounted)setState(()=>auto=enabled);
          }),
        const Divider(),Text(status),
      ])),
      NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('PAIRING CHECKLIST',style:TextStyle(fontWeight:FontWeight.w900)),
        const SizedBox(height:8),
        const Text('• Same Wi-Fi or hotspot network\n• Windows firewall permits Kārya on private networks\n• Both devices are awake and the host is sharing\n• Connection code and IP copied exactly'),
        if(addresses.isNotEmpty)Text('This device addresses: ${addresses.join(', ')}'),
      ])),
      const NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('YOUR DATA IS SAFER WITH A BACKUP',style:TextStyle(fontWeight:FontWeight.w900)),
        SizedBox(height:7),
        Text('Changes travel both ways, but if both devices independently edit their data, '
          'Kārya pauses instead of silently overwriting anything. This version does not '
          'automatically merge simultaneous edits. Allow local-network access when prompted.'),
      ])),
    ]),
  );
}
