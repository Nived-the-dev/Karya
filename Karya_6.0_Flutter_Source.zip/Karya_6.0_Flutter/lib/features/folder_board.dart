import 'package:flutter/material.dart';
import '../core/models.dart';
import 'neo.dart';

/// Real folder silhouette, shared by Windows and Android.
class SubjectFolder extends StatefulWidget {
  const SubjectFolder({super.key,required this.subject,required this.openCount,
    required this.onTap});
  final Subject subject;
  final int openCount;
  final VoidCallback onTap;
  @override State<SubjectFolder> createState()=>_SubjectFolderState();
}
class _SubjectFolderState extends State<SubjectFolder> {
  bool hovering=false;
  @override Widget build(BuildContext context){
    final colors=Theme.of(context).extension<NeoAccents>()?.colors;
    final base=(colors==null||colors.isEmpty)?colorFor(widget.subject.color):
      colors[widget.subject.color%colors.length];
    final dark=Theme.of(context).brightness==Brightness.dark;
    final stroke=dark?Colors.white:const Color(0xFF151515);
    return MouseRegion(
      onEnter:(_)=>setState(()=>hovering=true),
      onExit:(_)=>setState(()=>hovering=false),
      child:AnimatedScale(scale:hovering?1.035:1,duration:const Duration(milliseconds:180),
        curve:Curves.easeOutCubic,child:GestureDetector(onTap:widget.onTap,
        child:CustomPaint(painter:_FolderOutline(base,stroke),
          child:Padding(padding:const EdgeInsets.fromLTRB(17,35,17,17),
            child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(subjectEmoji(widget.subject.icon),style:const TextStyle(fontSize:30)),
              const Spacer(),
              Text(widget.subject.name,maxLines:2,overflow:TextOverflow.ellipsis,
                style:const TextStyle(color:Colors.black,fontWeight:FontWeight.w900,fontSize:17)),
              Text('${widget.openCount} open',style:const TextStyle(color:Colors.black,fontSize:12)),
            ]))))));
  }
}
/// Left-tabbed stationery folder silhouette inspired by the user's example.
/// All color combinations are drawn from the active Kārya palette.
class _FolderOutline extends CustomPainter {
  const _FolderOutline(this.fill,this.stroke);
  final Color fill,stroke;
  @override void paint(Canvas canvas,Size size){
    final w=size.width,h=size.height;
    // Folder tab sits at the upper-left rather than in the middle.
    final back=Path()..moveTo(13,21)..lineTo(13,11)
      ..quadraticBezierTo(13,4,21,4)..lineTo(w*.38,4)
      ..quadraticBezierTo(w*.42,4,w*.46,11)
      ..lineTo(w*.52,21)..lineTo(w-12,21)
      ..quadraticBezierTo(w-4,21,w-4,30)
      ..lineTo(w-4,h-9)..quadraticBezierTo(w-4,h-4,w-12,h-4)
      ..lineTo(13,h-4)..quadraticBezierTo(4,h-4,4,h-13)
      ..lineTo(4,30)..quadraticBezierTo(4,21,13,21)..close();
    canvas.drawPath(back.shift(const Offset(3,4)),Paint()..color=stroke.withValues(alpha:.50));
    canvas.drawPath(back,Paint()..color=fill);
    canvas.drawPath(back,Paint()..color=stroke..strokeWidth=2.5..style=PaintingStyle.stroke);
    final flap=Path()..moveTo(5,31)..quadraticBezierTo(5,24,13,24)
      ..lineTo(w-12,24)..quadraticBezierTo(w-4,24,w-4,33);
    canvas.drawPath(flap,Paint()..color=stroke..strokeWidth=1.6..style=PaintingStyle.stroke);
  }
  @override bool shouldRepaint(covariant _FolderOutline old)=>fill!=old.fill||stroke!=old.stroke;
}
