import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../main.dart';
import 'package:intl/intl.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'tasks.dart';
import 'folder_board.dart';
import '../core/progression.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context,WidgetRef ref){
    final a=ref.watch(appProvider);
    return a.when(loading:()=>const Center(child:CircularProgressIndicator()),error:(e,_)=>Center(child:Text('Could not load data: $e')),data:(data){
      final today=DateTime.now();
      final habits=data.habits.where((h)=>h.scheduledOn(today)).toList();
      final completed=habits.where((h)=>h.doneOn(today)).length;
      final pending=data.tasks.where((t)=>!t.completed).toList();
      final urgent=pending.where((t)=>t.overdue||t.dueDay==dayKey(today)).toList();
      final upcoming=pending.where((t)=>t.dueDay!=null&&t.dueDay!.compareTo(dayKey(today))>0).toList();
      final week=List.generate(7,(i)=>DateTime(today.year,today.month,today.day-i));
      final weekly=week.fold(0,(sum,d)=>sum+statsFor(data.habits,d).completed);
      return ScreenBody(children:[
        Headline('LET’S GET IT DONE.',DateFormat('EEEE, d MMMM y').format(today)),
        Row(children:[Expanded(child:NeoCard(color:colorFor(1),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('NEEDS ATTENTION',style:TextStyle(fontWeight:FontWeight.w900,color:Colors.black,fontSize:12)),Text('${urgent.length}',style:const TextStyle(fontSize:35,fontWeight:FontWeight.w900,color:Colors.black))]))),const SizedBox(width:8),Expanded(child:NeoCard(color:colorFor(2),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('HABITS TODAY',style:TextStyle(fontWeight:FontWeight.w900,color:Colors.black,fontSize:12)),Text('$completed/${habits.length}',style:const TextStyle(fontSize:35,fontWeight:FontWeight.w900,color:Colors.black))])))]),
        NeoButton(label:'+ QUICK ADD TASK',icon:Icons.add_circle_outline,onPressed:()async{await quickAddTask(context,ref);if(context.mounted)AppScaffold.open(context,1);}),
        const SizedBox(height:8),Text('YOUR SUBJECT BOARDS',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:10),
        if(data.subjects.isEmpty)const EmptyState('Make it yours.','Create your first subject below.',icon:Icons.folder_outlined),
        NeoButton(label:'+ CREATE A SUBJECT',icon:Icons.create_new_folder_outlined,onPressed:()=>showSubjectEditor(context,ref,null)),
        if(data.subjects.isNotEmpty)LayoutBuilder(builder:(ctx,layout){
          final cross=layout.maxWidth>=1000?5:layout.maxWidth>=740?4:layout.maxWidth>=490?3:2;
          return GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),
            itemCount:data.subjects.length,
            gridDelegate:SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:cross,
              mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.07),
            itemBuilder:(ctx,i){
              final subject=data.subjects[i];
              final count=pending.where((t)=>t.subjectId==subject.id).length;
              return SubjectFolder(subject:subject,openCount:count,
                onTap:()=>AppScaffold.open(context,1,subjectId:subject.id));
            });
        }),
        const SizedBox(height:8),Text('UP NEXT',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:10),
        if(urgent.isEmpty)const EmptyState('All clear! ✦','No tasks due today or overdue.',icon:Icons.celebration_outlined),
        ...urgent.take(4).map((t)=>NeoCard(onTap:()=>showTaskEditor(context,ref,task:t),child:Row(children:[Icon(t.overdue?Icons.warning_amber_rounded:Icons.assignment_outlined),const SizedBox(width:12),Expanded(child:Text(t.title,style:const TextStyle(fontWeight:FontWeight.w800))),Text(t.overdue?'OVERDUE':'TODAY',style:TextStyle(fontSize:11,fontWeight:FontWeight.w900,color:t.overdue?Colors.red:Theme.of(context).colorScheme.onSurface))]))),
        if(upcoming.isNotEmpty)NeoCard(child:Text('${upcoming.length} assignment${upcoming.length==1?'':'s'} coming up • Next: ${upcoming.first.title}')),
        NeoCard(onTap:()=>AppScaffold.open(context,5),child:Row(children:[const Icon(Icons.insights_rounded),const SizedBox(width:12),Expanded(child:Text('$weekly habit check-ins this week • ${data.completed} tasks done'))])),
        NeoCard(onTap:()=>context.push('/ranks'),color:colorFor(3),
          child:Row(children:[Text(rankIcons[rankFor(data).index],style:const TextStyle(fontSize:31)),
            const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,
            children:[Text('${rankFor(data).name} • ${rankFor(data).points} pts',
              style:const TextStyle(color:Colors.black,fontWeight:FontWeight.w900,fontSize:17)),
            const Text('YOUR JOURNEY • SEE RANK MAP →',
              style:TextStyle(color:Colors.black,fontWeight:FontWeight.w600,fontSize:11))])),
            const Icon(Icons.arrow_forward_ios,color:Colors.black,size:17)])),
      ]);
    });
  }
}
