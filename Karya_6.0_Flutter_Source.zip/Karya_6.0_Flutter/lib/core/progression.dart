import 'dart:math' as math;
import 'models.dart';

/// Fourteen rank titles. The final eight follow Olympian.
const rankNames = <String>[
  'Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond', 'Olympian',
  'Titan', 'Oracle', 'Phoenix', 'Nebula', 'Cosmic', 'Eternal',
  'Mythic', 'Ascendant',
];
const rankIcons = <String>[
  '🥉','🥈','🥇','🛡️','💎','🏛️','⚡','🔮',
  '🔥','🌌','🪐','✨','👑','🌠',
];
/// Both points and calendar time are required. No tier can be rushed by
/// repeatedly creating trivial tasks, but normal activity unlocks them.
const rankPoints = <int>[0, 45, 105, 190, 310, 475, 700, 1005, 1420, 1990, 2780, 3875, 5410, 7560];
const rankDays = <int>[0, 7, 15, 26, 40, 57, 80, 108, 142, 181, 225, 274, 326, 365];

/// 7 consecutive REAL check-in days earns one weekly bonus. Complete streaks
/// are grouped into nonoverlapping blocks; missing days don't subtract points.
int fullWeeks(Set<String> logs) {
  final ordered = logs.toList()..sort();
  var run=0, bonus=0;
  DateTime? previous;
  for(final key in ordered) {
    final date=DateTime.tryParse(key);
    if(date==null)continue;
    run=(previous!=null && date.difference(previous).inDays==1)?run+1:1;
    if(run%7==0)bonus++;
    previous=date;
  }
  return bonus;
}
PointsBreakdown pointsFor(AppData data) => data.earnedPoints ?? PointsBreakdown(
  tasks:data.tasks.where((t)=>t.completed).length*2,
  habits:data.habits.fold<int>(0,(sum,h)=>sum+h.logs.length*4),
  weeks:data.habits.fold<int>(0,(sum,h)=>sum+fullWeeks(h.logs)*8),
  goals:data.goals.where((g)=>g.done).length*15,
  daily:0,
);
int calendarDays(String from, DateTime today) {
  final start=DateTime.tryParse(from);
  if(start==null)return 0;
  return math.max(0, DateTime(today.year,today.month,today.day)
      .difference(DateTime(start.year,start.month,start.day)).inDays);
}
class RankProgress {
  const RankProgress(this.index,this.points,this.days);
  final int index,points,days;
  bool get readyToPrestige => index==rankNames.length-1;
  String get name => rankNames[index];
  double get fraction {
    if(readyToPrestige)return 1;
    final pointFraction=((points-rankPoints[index]) /
      (rankPoints[index+1]-rankPoints[index])).clamp(0.0,1.0);
    final dayFraction=((days-rankDays[index]) /
      (rankDays[index+1]-rankDays[index])).clamp(0.0,1.0);
    return math.min(pointFraction,dayFraction);
  }
}
RankProgress rankFor(AppData data, {DateTime? today}) {
  final info=data.progression;
  final total=pointsFor(data).total;
  final points=math.max(0,total-info.baseline);
  final age=calendarDays(info.prestigeDay.isEmpty?info.startedDay:info.prestigeDay,today??DateTime.now());
  var index=0;
  for(var i=1;i<rankNames.length;i++) {
    if(points>=rankPoints[i] && age>=rankDays[i])index=i;
  }
  return RankProgress(index,points,age);
}
