import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/state.dart';
import 'core/notifications.dart';
import 'core/lan_sync.dart';
import 'features/screens.dart';
import 'features/ideas.dart';
import 'features/tour.dart';
import 'features/neo.dart';
import 'features/goals.dart';
import 'features/lan_screen.dart';
import 'features/about.dart';
import 'features/ranks.dart';
import 'features/flow_planner.dart';
import 'features/customize.dart';
import 'features/calendar_planner.dart';
import 'features/help.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {await Reminders.instance.initialize();}catch(_){ }
  runApp(const ProviderScope(child:KaryaApp()));
}

final router=GoRouter(initialLocation:'/',routes:[
  GoRoute(path:'/',builder:(_,__)=>const AppScaffold()),
  GoRoute(path:'/chat',builder:(_,__)=>const ChatScreen()),
  GoRoute(path:'/settings',builder:(_,__)=>const SettingsScreen()),
  GoRoute(path:'/tour',builder:(_,__)=>const TourScreen()),
  GoRoute(path:'/goals',builder:(_,__)=>const Scaffold(body:FlowPlannerScreen())),
  GoRoute(path:'/calendar',builder:(_,__)=>const CalendarPlannerScreen()),
  GoRoute(path:'/about',builder:(_,__)=>const AboutScreen()),
  GoRoute(path:'/goals-edit',builder:(_,__)=>const GoalsScreen()),
  GoRoute(path:'/customize',builder:(_,__)=>const CustomizeScreen()),
  GoRoute(path:'/ranks',builder:(_,__)=>const RanksScreen()),
  GoRoute(path:'/wifi',builder:(_,__)=>const LanSyncScreen()),
  GoRoute(path:'/help',builder:(_,__)=>const HelpScreen()),
]);

class KaryaApp extends ConsumerWidget {
  const KaryaApp({super.key});
  @override Widget build(BuildContext context,WidgetRef ref){
    final mode=ref.watch(themeProvider).value??'system';
    final personality=ref.watch(paletteProvider).value??'Classic';
    return MaterialApp.router(title:'Kārya — कार्य',debugShowCheckedModeBanner:false,
      theme:neoTheme(false,personality),darkTheme:neoTheme(true,personality),
      themeMode:switch(mode){'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system},
      themeAnimationDuration:const Duration(milliseconds:300),
      themeAnimationCurve:Curves.easeOutCubic,
      routerConfig:router);
  }
}
const themeNames=['Classic','Soft Pop','Monochrome','Forest','Lavender'];
const colorSets=<String,List<Color>>{
 'Classic':[Color(0xFFFFD51D),Color(0xFFFF4C89),Color(0xFFA6E529),Color(0xFF9573F5),Color(0xFF70DDE3)],
 'Soft Pop':[Color(0xFFFFE9F1),Color(0xFFFF6BA6),Color(0xFF79DECD),Color(0xFFAB8CFF),Color(0xFFFFD46F)],
 'Monochrome':[Color(0xFFF1F1EE),Color(0xFFACACAC),Color(0xFFD1D1D1),Color(0xFF777777),Color(0xFFE0E0E0)],
 'Forest':[Color(0xFFEAFFD8),Color(0xFF42C17A),Color(0xFFFFC857),Color(0xFF48BDBD),Color(0xFFFF8E73)],
 'Lavender':[Color(0xFFF0E9FC),Color(0xFF9573F5),Color(0xFFFFABC5),Color(0xFFB5C9FA),Color(0xFFC0A4E6)],
};
ThemeData neoTheme(bool dark,[String personality='Classic']) {
  final colors=colorSets[personality]??colorSets['Classic']!;
  const ink=Color(0xFF111111);const off=Color(0xFFFFFCF7);
  final background=dark?Colors.black:colors.first;
  final surface=dark?const Color(0xFF111111):off;
  final text=dark?Colors.white:ink;
  final accent=colors[1];
  return ThemeData(useMaterial3:true,brightness:dark?Brightness.dark:Brightness.light,
    pageTransitionsTheme:const PageTransitionsTheme(builders:{
      TargetPlatform.android:ZoomPageTransitionsBuilder(),
      TargetPlatform.windows:FadeUpwardsPageTransitionsBuilder(),
      TargetPlatform.linux:FadeUpwardsPageTransitionsBuilder(),
      TargetPlatform.macOS:FadeUpwardsPageTransitionsBuilder(),
    }),
    scaffoldBackgroundColor:background,
    colorScheme:ColorScheme.fromSeed(seedColor:accent,
      brightness:dark?Brightness.dark:Brightness.light,
      surface:surface,primary:dark?colors[1]:ink,onSurface:text,
      outline:dark?Colors.white:ink),
    textTheme:TextTheme(
      headlineLarge:TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:text,letterSpacing:-.7),
      headlineMedium:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:text),
      titleLarge:TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:text),
      bodyMedium:TextStyle(color:text)),
    appBarTheme:AppBarTheme(backgroundColor:background,foregroundColor:text,
      centerTitle:false,scrolledUnderElevation:0),
    inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:surface,
      border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),
        borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),
      enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),
        borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),
      contentPadding:const EdgeInsets.all(14)),
    dialogTheme:DialogThemeData(backgroundColor:dark?const Color(0xFF171717):off),
    snackBarTheme:SnackBarThemeData(backgroundColor:dark?const Color(0xFF252525):ink,
      contentTextStyle:const TextStyle(color:Colors.white)),
    extensions:[NeoAccents(colors)],
  );
}

/// A real PageView follows the user's finger; desktop switches to a side rail.
class AppScaffold extends ConsumerStatefulWidget {
  const AppScaffold({super.key});
  static void open(BuildContext context,int tab,{int? subjectId}){
    context.findAncestorStateOfType<_AppScaffoldState>()?.openTab(tab,subjectId:subjectId);
  }
  @override ConsumerState<AppScaffold> createState()=>_AppScaffoldState();
}
class _AppScaffoldState extends ConsumerState<AppScaffold> {
  final controller=PageController();
  int selected=0;
  int? subjectId;
  Timer? _syncTimer;
  StreamSubscription<int>? _syncEvents;
  bool _syncBusy=false;
  Future<void> _showCoach(int tab) async {
    if(!mounted)return;
    final prefs=await SharedPreferences.getInstance();
    if(prefs.getBool('guide_seen_$tab')??false)return;
    await prefs.setBool('guide_seen_$tab',true);
    if(!mounted)return;
    await showFeatureGuide(context,tab);
  }
  @override void initState(){
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_)async{
      final prefs=await SharedPreferences.getInstance();
      if(!mounted)return;
      if(!(prefs.getBool('onboarded')??false)){
        await prefs.setBool('onboarded',true);
        if(mounted)context.push('/tour');
      }
    });
    ref.read(dbProvider).awardDailyOpen().then((_){if(mounted)ref.read(appProvider.notifier).refresh();}).catchError((Object _){});
    SharedPreferences.getInstance().then((prefs)async{
      if(!mounted || !(prefs.getBool('lan_share_on_launch')??false))return;
      try{await LocalSync.instance.startHost(ref.read(dbProvider));}catch(_){ }
    });
    _syncEvents=LocalSync.instance.changed.stream.listen((_){
      if(mounted)ref.read(appProvider.notifier).refresh();
    });
    _syncTimer=Timer.periodic(const Duration(minutes:2),(_)async{
      if(!mounted||_syncBusy)return;
      _syncBusy=true;
      try{
        final result=await LocalSync.instance.autoSync(ref.read(dbProvider));
        if(result!=null&&mounted)await ref.read(appProvider.notifier).refresh();
      }catch(_){/* offline is normal; manual sync gives full details */}
      finally{_syncBusy=false;}
    });
  }
  @override void dispose(){
    controller.dispose();_syncTimer?.cancel();_syncEvents?.cancel();super.dispose();
  }
  void openTab(int index,{int? subjectId}){
    if(subjectId!=null)setState(()=>this.subjectId=subjectId);
    if(controller.hasClients){
      controller.animateToPage(index,duration:const Duration(milliseconds:300),curve:Curves.easeOutCubic);
    }else{setState(()=>selected=index);}
    SharedPreferences.getInstance().then((p){
      if(p.getBool('haptics')??true)HapticFeedback.selectionClick();
    });
  }
  @override Widget build(BuildContext context){
    final labels=['Home','Tasks','Calendar','Flow','Habits','Progress','Ideas'];
    final layout=ref.watch(layoutProvider).value??'Comfort';
    final icons=[Icons.home_rounded,Icons.check_box_rounded,Icons.calendar_month_outlined,
      Icons.account_tree_rounded,Icons.auto_awesome_rounded,Icons.bar_chart_rounded,Icons.lightbulb_outline_rounded];
    return Scaffold(appBar:AppBar(title:const Text('KĀRYA ✦',
      style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),
      actions:[
        IconButton(tooltip:'Help with this tab',icon:const Icon(Icons.help_outline),
          onPressed:()=>showFeatureGuide(context,selected)),
        if(MediaQuery.sizeOf(context).width>=850)...[
          IconButton(tooltip:'About developer',icon:const Icon(Icons.info_outline),onPressed:()=>context.push('/about')),
          IconButton(tooltip:'Rank profile',icon:const Icon(Icons.workspace_premium_outlined),onPressed:()=>context.push('/ranks')),
          IconButton(tooltip:'Customize UI',icon:const Icon(Icons.palette_outlined),onPressed:()=>context.push('/customize')),
        ] else ...[
          IconButton(tooltip:'Customize UI',icon:const Icon(Icons.palette_outlined),onPressed:()=>context.push('/customize')),
          IconButton(tooltip:'Rank profile',icon:const Icon(Icons.workspace_premium_outlined),onPressed:()=>context.push('/ranks')),
        ],
        IconButton(tooltip:'Settings',icon:const Icon(Icons.settings_outlined),onPressed:()=>context.push('/settings')),
      ]),
      body:LayoutBuilder(builder:(context,bounds){
        final desktop=bounds.maxWidth>=850;
        final pages=<Widget>[
          const HomeScreen(),TasksScreen(initialSubjectId:subjectId),
          const CalendarPlannerScreen(),const FlowPlannerScreen(),const HabitsScreen(),
          const ProgressScreen(),const IdeasScreen(),
        ];
        final view=PageView(controller:controller,
          onPageChanged:(i){setState(()=>selected=i);ref.read(appProvider.notifier).refresh();
            WidgetsBinding.instance.addPostFrameCallback((_){if(mounted)_showCoach(i);});},
          physics:const BouncingScrollPhysics(),children:pages);
        if(desktop){
          final extended=layout=='Studio'||(layout=='Comfort'&&bounds.maxWidth>=1250);
          return Row(children:[
            SizedBox(width:extended?210:80,
              child:ListView(padding:const EdgeInsets.symmetric(vertical:12,horizontal:9),children:[
                for(var i=0;i<labels.length;i++)Padding(
                  padding:const EdgeInsets.symmetric(vertical:3),
                  child:Tooltip(message:labels[i],child:Material(
                    color:selected==i?Theme.of(context).colorScheme.primary.withValues(alpha:.15):Colors.transparent,
                    borderRadius:BorderRadius.circular(12),
                    child:InkWell(borderRadius:BorderRadius.circular(12),
                      onTap:()=>openTab(i),
                      child:Padding(padding:const EdgeInsets.symmetric(vertical:15,horizontal:9),
                        child:Row(mainAxisAlignment:extended?MainAxisAlignment.start:MainAxisAlignment.center,
                          children:[Icon(icons[i],size:24),
                            if(extended)...[const SizedBox(width:13),
                              Expanded(child:Text(labels[i],style:TextStyle(fontWeight:
                                selected==i?FontWeight.w900:FontWeight.w500)))],
                          ]))))),
                ),
                const Divider(),
                for(final extra in [
                  (Icons.workspace_premium_outlined,'Journey','/ranks'),
                  (Icons.wifi_tethering_rounded,'Wi-Fi sync','/wifi'),
                  (Icons.help_outline_rounded,'Help','/help'),
                ])Padding(padding:const EdgeInsets.symmetric(vertical:2),child:ListTile(
                    dense:!extended,contentPadding:const EdgeInsets.symmetric(horizontal:10),
                    leading:Icon(extra.$1),title:extended?Text(extra.$2):null,
                    onTap:()=>context.push(extra.$3))),
              ])),
            const VerticalDivider(width:1),Expanded(child:view),
          ]);
        }
        return view;
      }),
      bottomNavigationBar:MediaQuery.sizeOf(context).width>=850?null:
        SafeArea(top:false,child:Padding(
          padding:const EdgeInsets.fromLTRB(12,4,12,9),
          child:Container(height:70,
            decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,
              border:Border.all(color:Theme.of(context).colorScheme.outline,width:2),
              borderRadius:BorderRadius.circular(22),
              boxShadow:[BoxShadow(color:Theme.of(context).brightness==Brightness.dark?Colors.white:Colors.black,
                offset:const Offset(3,3))]),
            child:Row(children:[
              for(final i in [0,1,2,3])Expanded(child:InkWell(
                onTap:()=>openTab(i),borderRadius:BorderRadius.circular(16),
                child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Icon(icons[i],size:23),const SizedBox(height:2),
                  Text(labels[i],style:TextStyle(fontSize:10,fontWeight:selected==i?FontWeight.w900:FontWeight.w500))]))),
              Expanded(child:InkWell(onTap:()=>showModalBottomSheet<void>(context:context,
                showDragHandle:true,builder:(sheetContext)=>SafeArea(child:Padding(
                padding:const EdgeInsets.all(14),child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
                  for(final i in [4,5,6])ListTile(leading:Icon(icons[i]),title:Text(labels[i]),
                    onTap:(){Navigator.pop(sheetContext);openTab(i);}),
                  ListTile(leading:const Icon(Icons.workspace_premium_outlined),title:const Text('Journey'),
                    onTap:(){Navigator.pop(sheetContext);context.push('/ranks');}),
                  ListTile(leading:const Icon(Icons.palette_outlined),title:const Text('Customize'),
                    onTap:(){Navigator.pop(sheetContext);context.push('/customize');}),
                  ListTile(leading:const Icon(Icons.wifi_tethering),title:const Text('Private Wi-Fi sync'),
                    onTap:(){Navigator.pop(sheetContext);context.push('/wifi');}),
                  ListTile(leading:const Icon(Icons.help_outline),title:const Text('Help and walkthroughs'),
                    onTap:(){Navigator.pop(sheetContext);context.push('/help');}),
                  ListTile(leading:const Icon(Icons.info_outline),title:const Text('About the developer'),
                    onTap:(){Navigator.pop(sheetContext);context.push('/about');}),
                ]))))),
                child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                  Icon(selected>=4?icons[selected]:Icons.grid_view_rounded,size:23),
                  const SizedBox(height:2),Text(selected>=4?labels[selected]:'More',
                    style:const TextStyle(fontSize:10,fontWeight:FontWeight.w800))]))),
            ]))),
        ),
    );
  }
}
