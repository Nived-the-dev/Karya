# Kārya 2.1 Development Status

## Implemented in source
- Subject boards elevated on Home, direct creation and quick-add tasks.
- Five color palettes, including Classic, Soft Pop, Monochrome, Forest and Lavender; light, true-black dark and system mode.
- Guided first-run walkthrough and replay from Settings.
- Ideas tab with local SQLite storage, editing, pinning, search, deletion and task conversion; schema v2 migration.
- Offline rule-based Brain Dump with editable task previews, while retaining command assistant as an optional tool.
- Five bottom tabs and horizontal swipe gesture navigation; enhanced card animation and optional haptic feedback.
- Personal About page with creator story and external GitHub/LinkedIn links.
- De-duplicated subject dropdown IDs with a valid fallback for missing selected subject.

## Known limitations
- Interactive drag-following tab transitions (holding between tabs) are not fully implemented; swiping changes tabs at release.
- Brain Dump is rule-based and cannot reliably interpret natural-language due dates; manual review is required.
- Normal add-task still includes advanced fields rather than a separate one-line quick-entry form.
- The walkthrough is guided slides, not contextual spotlights on live controls.
- Source has not yet been compiled with Flutter/Android toolchain in this container.
- Re-run GitHub Actions analysis, tests, and APK build before installation. Verify dropdown and navigation on a real phone.
- The debug APK from Kārya 2.0 is not this 2.1 update.
