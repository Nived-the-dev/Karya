import 'package:flutter_test/flutter_test.dart';
import 'package:karya_app/features/brain_dump.dart';
void main(){
 test('offline brain dump splits lines and bullets',(){
  expect(splitThoughts('Finish homework\n- Buy notebook\n'),['Finish homework','Buy notebook']);
 });
 test('brain dump ignores empty thoughts',(){
  expect(splitThoughts('\n;  ; One task ; Second task'),['One task','Second task']);
 });
}
