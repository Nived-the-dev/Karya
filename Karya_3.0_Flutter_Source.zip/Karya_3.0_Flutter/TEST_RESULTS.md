# Test results — Kārya 3.0

- PASS: 10 offline source/SQLite/XML/image smoke checks via `python tool/verify_source.py`.
- PASS: output source ZIP CRC verified (packaging check).
- NOT RUN: `dart format`, `flutter analyze`, `flutter test`, Android APK build, Windows build.
- NOT RUN: actual Android screen-size evaluation, upgrades from 2.1, Windows device pairing, LAN encryption/failure/replay handling, image share operation, notification scheduling.
- Flutter tests for version 3 features exist in `test/v3_features_test.dart` but have NOT been run yet.

Do not claim a 3.0 APK exists until a CI build artifact has been produced and checked.
