# Kārya 3.0 — Development and verification status

**Status: Source implementation delivered; Android and Windows application builds NOT YET VERIFIED for this version.**

## Implemented in editable Flutter source

- Fixes invalid Dart syntax left in the 2.1 Ideas, Tour, and Neo widgets.
- Responsive main shell: true draggable five-page PageView on phones, side NavigationRail on Windows/wide screens, compact and animated phone navigation; centered content limit (850 px).
- True-black dark backgrounds; five light/dark theme palettes; optional tactile feedback and animated card-press effect.
- Constellation habit activity map from real habit completion logs and connected map from goals, tasks, subjects and ideas. Drag, pinch-zoom, tap nodes, private-label toggle, device share-sheet PNG export.
- Goal Trees: goal CRUD, completion, optional target dates, linking and unlinking tasks, habits, subjects, and ideas.
- Rescue My Day: suggest up to 3 priority actions; complete, reschedule or edit with explicit actions only.
- Weekly Story: deterministic summaries from actual task completions, habit records and idea-to-task links.
- Chaos Dump: offline line splitting, type suggestions (Task or Idea), editable review, transactional save.
- Ideas: persistent CRUD, pin, search, convert to task with traceable link, turn into goal, link to existing goal.
- Private Wi-Fi sync protocol: opt-in Windows listener and Android client using authenticated AES-256-GCM encrypted request payloads, device-only IPv4 pairing, full database snapshot transfer, foreground auto-attempt every 2 minutes, and refuse-to-overwrite conflict detection.
- Local SQLite schema version 3 migration and snapshot input validation in an atomic transaction.
- Introductory tour updated, settings link to Wi-Fi page, privacy policy updated.
- Android INTERNET permission for the explicit local-network feature; no cloud sync backend or AI API.
- Separate Android and Windows CI workflows; Windows release is an executable folder zipped for download.

## Known limitations — do not misrepresent

- Wi-Fi sync is not general-purpose multi-master merging: when both devices changed since the last sync, it refuses to overwrite and requires backup/manual resolution. First pairing works automatically when one side is empty. Auto-sync runs only while the app is open; Windows hosting must be started from Wi-Fi settings. It is **not** background cloud sync and **does not** use QR scanning.
- Android local HTTP is allowed solely for encrypted local payloads; network metadata can still be observed. Pairing codes are stored in device preferences, not a hardware-backed secrets vault; production security review remains necessary.
- No on-device AI model is integrated. Chaos Dump is rule based.
- The Constellation displays selected recent activity for performance (max 22 current habits × 12 days). Detailed history remains in local habit records.
- No release signing, production AAB, Play Console publication, or on-device visual testing is claimed.
- Windows app must remain open and receive Windows Firewall authorization on private networks for LAN pairing.
- Existing 2.1 debug APK is NOT a validated 3.0 build.

## Verification checklist

- [x] Source ZIP inspection and PNG/XML validity checks (offline Python checks).
- [x] SQLite schema and foreign key smoke tests (offline Python checks).
- [x] Added Flutter tests for 3.0 models, links, graph generation and sync snapshot protections (not yet executed).
- [ ] `dart format lib test integration_test` — requires Flutter/Dart SDK.
- [ ] `flutter analyze --no-fatal-infos` — requires Flutter/Dart SDK.
- [ ] `flutter test test` — requires Flutter/Dart SDK.
- [ ] `flutter build apk --debug` — requires Flutter/Android SDK.
- [ ] `flutter build windows --release` — requires Windows/Visual Studio.
- [ ] Manual small-screen Android navigation, topic dropdowns, notifications and upgrade migration.
- [ ] Two-device LAN sync tests including interrupted transfers, conflicts and first pairing.
- [ ] Share constellation from a physical device.

## Next action

Upload the new **Karya_3.0_Flutter_Source.zip** to the existing GitHub `Nived-the-dev/Karya` repository root without unzipping it. The GitHub Actions workflows can then attempt Android and Windows builds. Investigate and fix errors from logs before labelling any APK or Windows build verified.
