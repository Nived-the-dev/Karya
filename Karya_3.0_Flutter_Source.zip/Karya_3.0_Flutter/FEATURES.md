# Kārya feature inventory — version 3.0

| Area | Implemented in source | Verification |
| --- | --- | --- |
| Tasks/subjects/subtasks | Local SQLite and Flutter UI | Existing tests; v3 run pending |
| Habits/progress/heatmap | Calendar-aware local records and fl_chart | Existing tests; Android pending |
| Ideas and linked goals | Schema v3, CRUD, explicit item linking | Offline SQL checks pass; Flutter tests pending |
| Chaos Dump | Offline line parsing, task/idea selection and review | Source tests added; Flutter tests pending |
| Constellation | Habit stars from recorded check-ins, graph of explicit links, privacy-controlled PNG sharing | Manual phone tests pending |
| Goal Trees | Goals, completion, optional dates, link/unlink | Database tests added; Flutter pending |
| Rescue My Day | Up to three urgency/prioritized next steps | Algorithm test added; Flutter pending |
| Weekly Story | Narrative counts from actual data only | Algorithm test added; Flutter pending |
| True-black dark and five themes | Flutter color system, preferences | Manual UI verification pending |
| Smooth tabs and responsive layout | Draggable PageView and Windows NavigationRail | Phone/Windows visual checks pending |
| Private local Wi-Fi sync | AES-GCM protocol, opt-in host/client, conflict stop, timestamp | Real-device, interruption, security testing pending |
| Onboarding and creator story | Guided tour, About page, links | Widget/device verification pending |
| Ads/accounts/cloud AI | Not present | Source verified by inspection |

All data is local-first. Private network sync and user-invoked sharing are the only content-transfer features. No user-facing JSON export. The source contains migration logic from schema v2 to v3. Do not conflate source implementation with completed tests or published software.
