import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/state.dart';
import 'core/notifications.dart';
import 'core/lan_sync.dart';
import 'features/screens.dart';
import 'features/ideas.dart';
import 'features/tour.dart';
import 'features/brain_dump.dart';
import 'features/neo.dart';
import 'features/goals.dart';
import 'features/constellation.dart';
import 'features/rescue.dart';
import 'features/lan_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {await Reminders.instance.initialize();}catch(_){ }
  runApp(const ProviderScope(child:KaryaApp()));
}

final router=GoRouter(initialLocation:'/',routes:[
  GoRoute(path:'/',builder:(_,__)=>const AppScaffold()),
  GoRoute(path:'/brain-dump',builder:(_,__)=>const BrainDumpScreen()),
  GoRoute(path:'/chat',builder:(_,__)=>const ChatScreen()),
  GoRoute(path:'/settings',builder:(_,__)=>const SettingsScreen()),
  GoRoute(path:'/tour',builder:(_,__)=>const TourScreen()),
  GoRoute(path:'/goals',builder:(_,__)=>const GoalsScreen()),
  GoRoute(path:'/constellation',builder:(_,__)=>const ConstellationScreen()),
  GoRoute(path:'/rescue',builder:(_,__)=>const RescueScreen()),
  GoRoute(path:'/weekly-story',builder:(_,__)=>const WeeklyStoryScreen()),
  GoRoute(path:'/wifi',builder:(_,__)=>const LanSyncScreen()),
]);

class KaryaApp extends ConsumerWidget {
  const KaryaApp({super.key});
  @override Widget build(BuildContext context,WidgetRef ref){
    final mode=ref.watch(themeProvider).value??'system';
    final personality=ref.watch(paletteProvider).value??'Classic';
    return MaterialApp.router(title:'Kārya — कार्य',debugShowCheckedModeBanner:false,
      theme:neoTheme(false,personality),darkTheme:neoTheme(true,personality),
      themeMode:switch(mode){'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system},
      routerConfig:router);
  }
}
const themeNames=['Classic','Soft Pop','Monochrome','Forest','Lavender'];
const colorSets=<String,List<Color>>{
 'Classic':[Color(0xFFFFD51D),Color(0xFFFF4C89),Color(0xFFA6E529)],
 'Soft Pop':[Color(0xFFF7EDD9),Color(0xFFDE92B6),Color(0xFFAFD5A7)],
 'Monochrome':[Color(0xFFF1F1EE),Color(0xFF979797),Color(0xFFD1D1D1)],
 'Forest':[Color(0xFFE9EBD7),Color(0xFF719E78),Color(0xFFC4A779)],
 'Lavender':[Color(0xFFF0E9FC),Color(0xFF9573F5),Color(0xFFFFABC5)],
};
ThemeData neoTheme(bool dark,[String personality='Classic']) {
  final colors=colorSets[personality]??colorSets['Classic']!;
  const ink=Color(0xFF111111);const off=Color(0xFFFFFCF7);
  final background=dark?Colors.black:colors.first;
  final surface=dark?const Color(0xFF151515):off;
  final text=dark?Colors.white:ink;
  final accent=colors[1];
  return ThemeData(useMaterial3:true,brightness:dark?Brightness.dark:Brightness.light,
    scaffoldBackgroundColor:background,
    colorScheme:ColorScheme.fromSeed(seedColor:accent,
      brightness:dark?Brightness.dark:Brightness.light,
      surface:surface,primary:dark?colors[1]:ink,onSurface:text),
    textTheme:TextTheme(
      headlineLarge:TextStyle(fontSize:30,fontWeight:FontWeight.w900,color:text,letterSpacing:-.7),
      headlineMedium:TextStyle(fontSize:25,fontWeight:FontWeight.w900,color:text),
      titleLarge:TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:text),
      bodyMedium:TextStyle(color:text)),
    appBarTheme:AppBarTheme(backgroundColor:background,foregroundColor:text,
      centerTitle:false,scrolledUnderElevation:0),
    inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:surface,
      border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),
        borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),
      enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(14),
        borderSide:BorderSide(color:dark?Colors.white:ink,width:2)),
      contentPadding:const EdgeInsets.all(14)),
    snackBarTheme:SnackBarThemeData(backgroundColor:dark?const Color(0xFF252525):ink,
      contentTextStyle:const TextStyle(color:Colors.white)),
    extensions:[NeoAccents([colors[0],colors[1],colors[2],
      personality=='Classic'?const Color(0xFF9573F5):colors[1],
      personality=='Classic'?const Color(0xFF70DDE3):colors[2]])],
  );
}

/// A real PageView follows the user's finger; desktop switches to a side rail.
class AppScaffold extends ConsumerStatefulWidget {
  const AppScaffold({super.key});
  static void open(BuildContext context,int tab,{int? subjectId}){
    context.findAncestorStateOfType<_AppScaffoldState>()?.openTab(tab,subjectId:subjectId);
  }
  @override ConsumerState<AppScaffold> createState()=>_AppScaffoldState();
}
class _AppScaffoldState extends ConsumerState<AppScaffold> {
  final controller=PageController();
  int selected=0;
  int? subjectId;
  Timer? _syncTimer;
  StreamSubscription<int>? _syncEvents;
  bool _syncBusy=false;
  @override void initState(){
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_)async{
      final prefs=await SharedPreferences.getInstance();
      if(!mounted)return;
      if(!(prefs.getBool('onboarded')??false)){
        await prefs.setBool('onboarded',true);
        if(mounted)context.push('/tour');
      }
    });
    _syncEvents=LocalSync.instance.changed.stream.listen((_){
      if(mounted)ref.read(appProvider.notifier).refresh();
    });
    _syncTimer=Timer.periodic(const Duration(minutes:2),(_)async{
      if(!mounted||_syncBusy)return;
      _syncBusy=true;
      try{
        final result=await LocalSync.instance.autoSync(ref.read(dbProvider));
        if(result!=null&&mounted)await ref.read(appProvider.notifier).refresh();
      }catch(_){/* offline is normal; manual sync gives full details */}
      finally{_syncBusy=false;}
    });
  }
  @override void dispose(){
    controller.dispose();_syncTimer?.cancel();_syncEvents?.cancel();super.dispose();
  }
  void openTab(int index,{int? subjectId}){
    if(subjectId!=null)setState(()=>this.subjectId=subjectId);
    if(controller.hasClients){
      controller.animateToPage(index,duration:const Duration(milliseconds:300),curve:Curves.easeOutCubic);
    }else{setState(()=>selected=index);}
    SharedPreferences.getInstance().then((p){
      if(p.getBool('haptics')??true)HapticFeedback.selectionClick();
    });
  }
  @override Widget build(BuildContext context){
    final labels=['Home','Tasks','Habits','Progress','Ideas'];
    final icons=[Icons.home_rounded,Icons.check_box_rounded,Icons.auto_awesome_rounded,
      Icons.bar_chart_rounded,Icons.lightbulb_outline_rounded];
    return Scaffold(appBar:AppBar(title:const Text('KĀRYA ✦',
      style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),
      actions:[
        IconButton(tooltip:'Chaos Dump',icon:const Icon(Icons.edit_note_outlined),
          onPressed:()=>context.push('/brain-dump')),
        IconButton(tooltip:'Settings',icon:const Icon(Icons.settings_outlined),
          onPressed:()=>context.push('/settings')),
      ]),
      body:LayoutBuilder(builder:(context,bounds){
        final desktop=bounds.maxWidth>=850;
        final pages=<Widget>[
          const HomeScreen(),TasksScreen(initialSubjectId:subjectId),
          const HabitsScreen(),const ProgressScreen(),const IdeasScreen(),
        ];
        final view=PageView(controller:controller,
          onPageChanged:(i)=>setState(()=>selected=i),
          physics:const BouncingScrollPhysics(),children:pages);
        if(desktop)return Row(children:[
          NavigationRail(selectedIndex:selected,
            onDestinationSelected:openTab,
            extended:bounds.maxWidth>=1100,
            destinations:[for(var i=0;i<labels.length;i++)
              NavigationRailDestination(icon:Icon(icons[i]),label:Text(labels[i]))]),
          const VerticalDivider(width:1),Expanded(child:view),
        ]);
        return view;
      }),
      bottomNavigationBar:MediaQuery.sizeOf(context).width>=850?null:
        SafeArea(top:false,child:Padding(padding:const EdgeInsets.fromLTRB(9,4,12,8),
          child:LayoutBuilder(builder:(ctx,constraints){
            final width=constraints.maxWidth;
            return Container(height:72,decoration:BoxDecoration(
              color:Theme.of(ctx).colorScheme.surface,
              border:Border.all(color:Theme.of(ctx).colorScheme.onSurface,width:2.5),
              borderRadius:BorderRadius.circular(18),
              boxShadow:const [BoxShadow(color:Colors.black,offset:Offset(3,4))]),
              child:Stack(children:[
                Positioned(left:7,top:4,child:AnimatedBuilder(animation:controller,builder:(ctx,_) {
                  final page=controller.hasClients?(controller.page??selected.toDouble()):selected.toDouble();
                  return Transform.translate(offset:Offset((width-14)/5*page,0),
                    child:Container(width:(width-14)/5-3,height:5,
                      decoration:BoxDecoration(color:const Color(0xFFFF4C89),
                        borderRadius:BorderRadius.circular(6))));
                })),
                Row(children:[for(var i=0;i<labels.length;i++)
                  Expanded(child:InkWell(onTap:()=>openTab(i),
                    borderRadius:BorderRadius.circular(14),
                    child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                      Icon(icons[i],size:23,color:selected==i?const Color(0xFFFF4C89):
                        Theme.of(ctx).colorScheme.onSurface),
                      const SizedBox(height:3),
                      if(selected==i)FittedBox(child:Text(labels[i],style:const TextStyle(
                        fontWeight:FontWeight.w900,fontSize:11))),
                    ]))),
                ]),
              ]));
          }))),
    );
  }
}
