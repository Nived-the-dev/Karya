import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/state.dart';
import 'neo.dart';
import 'ideas.dart';

/// Deterministic offline capture: suggestions are never silently saved.
List<String> splitThoughts(String raw) {
  final lines=raw.split(RegExp(r'[\n;]+')).expand((line)=>line.split(RegExp(r'\.\s+(?=[A-Z])')));
  return lines.map((line)=>line.trim().replaceAll(RegExp(r'^[-•*]\s*'),'')).where((line)=>line.isNotEmpty).toList();
}
String suggestedKind(String thought) {
  final lower=thought.toLowerCase();
  if(RegExp(r'\b(idea|maybe|what if|wonder|thought|note to self|brainstorm)\b').hasMatch(lower)) return 'Idea';
  return 'Task';
}
class BrainDumpScreen extends ConsumerStatefulWidget {
  const BrainDumpScreen({super.key});
  @override ConsumerState<BrainDumpScreen> createState()=>_BrainDumpScreenState();
}
class _BrainDumpScreenState extends ConsumerState<BrainDumpScreen> {
  final thoughts=TextEditingController();
  final drafts=<TextEditingController>[];
  final kinds=<String>[];
  bool saving=false;
  @override void dispose(){thoughts.dispose();for(final d in drafts)d.dispose();super.dispose();}
  void preview(){
    for(final d in drafts)d.dispose();
    drafts.clear();kinds.clear();
    for(final s in splitThoughts(thoughts.text)) {
      drafts.add(TextEditingController(text:s));
      kinds.add(suggestedKind(s));
    }
    setState((){});
  }
  Future<void> save() async {
    if(saving)return;
    final entries=<({String text,String kind})>[];
    for(var i=0;i<drafts.length;i++){
      final trimmed=drafts[i].text.trim();
      if(trimmed.isNotEmpty)entries.add((text:trimmed,kind:kinds[i]));
    }
    if(entries.isEmpty)return;
    setState(()=>saving=true);
    try{
      await ref.read(appProvider.notifier).change((db)=>db.transaction(() async {
        for(final e in entries){
          if(e.kind=='Idea') {
            await db.saveIdea(body:e.text);
          }else{
            final name=e.text.length>180?e.text.substring(0,180):e.text;
            await db.saveTask(title:name,description:e.text.length>180?e.text:'');
          }
        }
      }));
      ref.invalidate(ideasProvider);
      if(mounted){toast(context,'Saved ${entries.length} items.');Navigator.pop(context);}
    }catch(e){if(mounted)toast(context,'Could not save: $e');}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('CHAOS DUMP ✦')),
    body:ScreenBody(children:[
      const Headline('EMPTY YOUR HEAD.',
        'Write everything. Kārya will suggest tasks or ideas; you decide what stays.'),
      TextField(controller:thoughts,minLines:5,maxLines:10,
        decoration:const InputDecoration(hintText:'Finish chemistry assignment\nMaybe build a science fair project\nRead chapter 5')),
      const SizedBox(height:12),
      NeoButton(label:'SORT MY THOUGHTS',icon:Icons.auto_awesome_outlined,onPressed:preview),
      if(drafts.isNotEmpty)...[
        const SizedBox(height:12),
        Text('CHECK BEFORE SAVING',style:Theme.of(context).textTheme.titleLarge),
        const Text('These are offline suggestions, not AI. Change the type or edit each entry.'),
        for(var i=0;i<drafts.length;i++)NeoCard(child:Column(children:[
          TextField(controller:drafts[i],minLines:1,maxLines:4,
            decoration:InputDecoration(labelText:'Thought ${i+1}')),
          Row(children:[
            ChoiceChip(label:const Text('Task'),selected:kinds[i]=='Task',
              onSelected:(_)=>setState(()=>kinds[i]='Task')),
            const SizedBox(width:8),
            ChoiceChip(label:const Text('Idea'),selected:kinds[i]=='Idea',
              onSelected:(_)=>setState(()=>kinds[i]='Idea')),
            const Spacer(),
            IconButton(tooltip:'Remove',icon:const Icon(Icons.close),onPressed:(){
              final old=drafts.removeAt(i);kinds.removeAt(i);setState((){});
              Future<void>.delayed(const Duration(milliseconds:350),old.dispose);
            }),
          ]),
        ])),
        NeoButton(label:saving?'SAVING...':'SAVE ${drafts.length} THOUGHTS',
          icon:Icons.save_alt,onPressed:saving?null:save),
      ],
      const SizedBox(height:12),
      const Text('Nothing leaves your device. You can add dates, subjects and connections afterwards.'),
    ]),
  );
}
