import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/lan_sync.dart';
import '../core/state.dart';
import 'neo.dart';

class LanSyncScreen extends ConsumerStatefulWidget {
  const LanSyncScreen({super.key});
  @override ConsumerState<LanSyncScreen> createState()=>_LanSyncScreenState();
}
class _LanSyncScreenState extends ConsumerState<LanSyncScreen> {
  final ip=TextEditingController();
  final code=TextEditingController();
  String result='Not connected';
  String lastSuccess='Never';
  String? hostCode;
  List<String> addresses=[];
  bool syncing=false, auto=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    final prefs=await SharedPreferences.getInstance();
    if(!mounted)return;
    ip.text=prefs.getString('lan_ip')??'';
    code.text=prefs.getString('lan_code')??'';
    auto=prefs.getBool('lan_auto')??false;
    lastSuccess=prefs.getString('lan_last_success')??'Never';
    if(Platform.isWindows){
      try{addresses=await LocalSync.instance.ipv4Addresses();}catch(_){}
      if(LocalSync.instance.serving)hostCode=prefs.getString('lan_host_code');
    }
    if(mounted)setState((){});
  }
  @override void dispose(){ip.dispose();code.dispose();super.dispose();}
  Future<void> handleSync() async {
    if(syncing)return;
    setState((){syncing=true;result='Checking both devices...';});
    try{
      final message=await LocalSync.instance.sync(ref.read(dbProvider),ip.text,code.text);
      await ref.read(appProvider.notifier).refresh();
      if(mounted)setState((){result=message;lastSuccess=DateTime.now().toLocal().toString().substring(0,16);});
    }catch(e){if(mounted)setState(()=>result='$e');}
    finally{if(mounted)setState(()=>syncing=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('PRIVATE WI-FI SYNC')),
    body:ScreenBody(children:[
      const Headline('YOUR DEVICES. YOUR DATA.',
        'Sync directly on the same Wi-Fi. No cloud account, no ads.'),
      if(Platform.isWindows)...[
        NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Text('THIS LAPTOP',style:Theme.of(context).textTheme.titleLarge),
          const SizedBox(height:8),
          Text(addresses.isEmpty?'Local IPv4 not detected':addresses.join(' • '),
            style:const TextStyle(fontWeight:FontWeight.bold)),
          const SizedBox(height:9),
          if(hostCode!=null)...[
            SelectableText(hostCode!,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900,letterSpacing:1)),
            TextButton.icon(icon:const Icon(Icons.copy),label:const Text('Copy pairing code'),
              onPressed:()=>Clipboard.setData(ClipboardData(text:hostCode!))),
            const Text('Enter this IP and code on your phone. Keep the app open. Windows Firewall may ask to allow private-network access.'),
          ],
          NeoButton(label:LocalSync.instance.serving?'STOP SHARING':'START WI-FI SYNC',
            icon:Icons.wifi,onPressed:()async{
              try{
                if(LocalSync.instance.serving){await LocalSync.instance.stopHost();
                  if(mounted)setState(()=>hostCode=null);
                }else{
                  final value=await LocalSync.instance.startHost(ref.read(dbProvider));
                  addresses=await LocalSync.instance.ipv4Addresses();
                  if(mounted)setState(()=>hostCode=value);
                }
              }catch(e){if(mounted)toast(context,'Could not start: $e');}
            }),
        ])),
      ]else...[
        NeoCard(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Text('CONNECT TO YOUR LAPTOP',style:Theme.of(context).textTheme.titleLarge),
          const SizedBox(height:12),
          TextField(controller:ip,keyboardType:TextInputType.url,
            decoration:const InputDecoration(labelText:'Laptop IPv4 address',hintText:'192.168.1.42')),
          const SizedBox(height:12),
          TextField(controller:code,autocorrect:false,enableSuggestions:false,
            textCapitalization:TextCapitalization.characters,
            decoration:const InputDecoration(labelText:'Pairing code shown on laptop')),
          const SizedBox(height:12),
          NeoButton(label:syncing?'SYNCING...':'SYNC NOW',icon:Icons.sync,
            onPressed:syncing?null:handleSync),
          SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Auto-sync while Kārya is open'),
            subtitle:const Text('Try every 2 minutes when both devices are available.'),
            value:auto,onChanged:(v)async{
              await (await SharedPreferences.getInstance()).setBool('lan_auto',v);
              if(mounted)setState(()=>auto=v);
            }),
          const SizedBox(height:8),Text(result),Text('Last sync: $lastSuccess'),
        ])),
      ],
      const NeoCard(child:Text('SAFETY FIRST\n\nOnly one device can have unsynced changes at a time. If both change, Kārya stops instead of overwriting either device. Pairing uses an encrypted connection on your private Wi-Fi. This first version does not automatically merge simultaneous edits. Keep a backup before transferring large amounts of data.')),
    ]),
  );
}
