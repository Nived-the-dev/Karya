import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'ideas.dart';

class StarNode {
  const StarNode(this.key, this.label, this.type, this.position, this.color, this.value);
  final String key, label, type;
  final Offset position;
  final Color color;
  final String value;
}
class StarEdge {
  const StarEdge(this.a, this.b);
  final int a,b;
}
class StarMap {
  const StarMap(this.nodes, this.edges);
  final List<StarNode> nodes;
  final List<StarEdge> edges;
}

/// A deterministic graph of REAL entries; empty databases have empty graphs.
StarMap makeStarMap(AppData data, {bool activity = true, List<Idea> ideas = const []}) {
  final nodes = <StarNode>[];
  final edges = <StarEdge>[];
  final lookups = <String,int>{};
  void add(String key,String label,String type,Offset pos,Color col,String description) {
    lookups[key]=nodes.length;
    nodes.add(StarNode(key,label,type,pos,col,description));
  }
  const origin=Offset(430,310);
  if(activity) {
    final habits=data.habits.take(22).toList();
    for(var i=0;i<habits.length;i++) {
      final h=habits[i];
      final theta=-math.pi/2 + 2*math.pi*i/math.max(1,habits.length);
      final center=origin+Offset(math.cos(theta)*205,math.sin(theta)*170);
      final color=colorFor(h.color);
      add('habit:${h.id}',h.name,'habit',center,color,'${h.logs.length} recorded check-ins');
      final logs=h.logs.toList()..sort();
      for(var j=0;j<math.min(logs.length,12);j++) {
        final day=logs[logs.length-1-j];
        final angle=(j*2.399)+theta;
        final point=center+Offset(math.cos(angle)*(55+j*3),math.sin(angle)*(48+j*2));
        add('day:${h.id}:$day',day,'check-in',point,color,'Completed ${h.name} on $day');
        edges.add(StarEdge(lookups['habit:${h.id}']!,nodes.length-1));
      }
    }
  } else {
    final goals=data.goals;
    final habits=data.habits.take(14).toList();
    final tasks=data.tasks.where((t)=>!t.completed).take(16).toList();
    final subjects=data.subjects.take(10).toList();
    final thoughts=ideas.take(12).toList();
    for(var i=0;i<goals.length;i++){
      final angle=-math.pi/2+(math.pi*2*i/math.max(1,goals.length));
      add('goal:${goals[i].id}',goals[i].title,'goal',
        origin+Offset(math.cos(angle)*115,math.sin(angle)*105),colorFor(1),'Goal${goals[i].done?' completed':''}');
    }
    for(var i=0;i<habits.length;i++){
      final angle=-math.pi/2+math.pi*2*i/math.max(1,habits.length);
      add('habit:${habits[i].id}',habits[i].name,'habit',
        origin+Offset(math.cos(angle)*235,math.sin(angle)*175),colorFor(habits[i].color), 'Habit');
    }
    for(var i=0;i<subjects.length;i++){
      final angle=math.pi/3 + math.pi*2*i/math.max(1,subjects.length);
      add('subject:${subjects[i].id}',subjects[i].name,'subject',
        origin+Offset(math.cos(angle)*330,math.sin(angle)*230),colorFor(subjects[i].color),'Subject board');
    }
    for(var i=0;i<tasks.length;i++){
      final angle=-math.pi/4+math.pi*2*i/math.max(1,tasks.length);
      add('task:${tasks[i].id}',tasks[i].title,'task',
        origin+Offset(math.cos(angle)*285,math.sin(angle)*220),colorFor(3),'Pending task');
    }
    for(var i=0;i<thoughts.length;i++){
      final angle=math.pi/5+math.pi*2*i/math.max(1,thoughts.length);
      add('idea:${thoughts[i].id}',thoughts[i].body.split('\n').first,'idea',
        origin+Offset(math.cos(angle)*355,math.sin(angle)*245),colorFor(4),'Saved idea');
    }
    for(final link in data.links){
      final a=lookups['${link.fromType}:${link.fromId}'];
      final b=lookups['${link.toType}:${link.toId}'];
      if(a!=null&&b!=null)edges.add(StarEdge(a,b));
    }
    for(final task in tasks){
      final a=lookups['task:${task.id}'];
      final b=lookups['subject:${task.subjectId}'];
      if(a!=null&&b!=null)edges.add(StarEdge(a,b));
    }
  }
  return StarMap(nodes,edges);
}

class ConstellationScreen extends ConsumerStatefulWidget {
  const ConstellationScreen({super.key});
  @override ConsumerState<ConstellationScreen> createState()=>_ConstellationScreenState();
}
class _ConstellationScreenState extends ConsumerState<ConstellationScreen> {
  bool activity=true,hideNames=false,sharing=false;
  StarNode? selected;
  final key=GlobalKey();
  Future<void> shareMap() async {
    setState(()=>sharing=true);
    try {
      final boundary=key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if(boundary==null) throw StateError('Graph is not ready');
      final image=await boundary.toImage(pixelRatio:1.5);
      final data=await image.toByteData(format:ui.ImageByteFormat.png);
      if(data==null)throw StateError('Image could not be encoded');
      final file=File('${(await getTemporaryDirectory()).path}/karya_constellation.png');
      await file.writeAsBytes(data.buffer.asUint8List(),flush:true);
      await SharePlus.instance.share(ShareParams(files:[XFile(file.path)],
        text:'My Kārya Constellation ✦ • Offline, no ads.'));
    } catch(e){if(mounted)toast(context,'Could not share graph: $e');}
    finally{if(mounted)setState(()=>sharing=false);}
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar:AppBar(title:const Text('CONSTELLATION ✦'),actions:[
      IconButton(tooltip:'Share constellation image',onPressed:sharing?null:shareMap,
        icon:const Icon(Icons.ios_share_outlined)),
    ]),
    body:ref.watch(appProvider).when(loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('$e')),data:(data) {
        final map=makeStarMap(data,activity:activity,ideas:ref.watch(ideasProvider).value??const []);
        return Column(children:[
          Padding(padding:const EdgeInsets.fromLTRB(14,8,14,4),child:Wrap(spacing:8,runSpacing:6,children:[
            ChoiceChip(label:const Text('Habit activity'),selected:activity,onSelected:(_)=>setState((){activity=true;selected=null;})),
            ChoiceChip(label:const Text('Connections'),selected:!activity,onSelected:(_)=>setState((){activity=false;selected=null;})),
            FilterChip(label:const Text('Hide names for sharing'),selected:hideNames,onSelected:(v)=>setState(()=>hideNames=v)),
          ])),
          Expanded(child:ClipRect(child:InteractiveViewer(minScale:.35,maxScale:3,
            boundaryMargin:const EdgeInsets.all(240),constrained:false,
            child:RepaintBoundary(key:key,child:Container(
              width:860,height:620,color:Colors.black,
              child:Stack(children:[
                CustomPaint(size:const Size(860,620),painter:_Lines(map)),
                for(final node in map.nodes)
                  Positioned(left:node.position.dx-(node.type=='check-in'?6:28),
                    top:node.position.dy-(node.type=='check-in'?6:24),
                    child:GestureDetector(onTap:()=>setState(()=>selected=node),child:
                    Container(constraints:node.type=='check-in'?null:const BoxConstraints(maxWidth:150),
                      padding:node.type=='check-in'?EdgeInsets.zero:const EdgeInsets.symmetric(horizontal:10,vertical:7),
                      width:node.type=='check-in'?12:null,height:node.type=='check-in'?12:null,
                      decoration:BoxDecoration(color:node.color,
                        borderRadius:BorderRadius.circular(node.type=='check-in'?8:13),
                        border:Border.all(color:Colors.white70,width:node.type=='check-in'?1:1.4),
                        boxShadow:[BoxShadow(color:node.color.withValues(alpha:.24),blurRadius:15)]),
                      child:node.type=='check-in'?null:Text(hideNames?node.type.toUpperCase():node.label,
                        maxLines:2,overflow:TextOverflow.ellipsis,textAlign:TextAlign.center,
                        style:const TextStyle(color:Colors.black,fontSize:11,fontWeight:FontWeight.w900))))),
              ]),
            ))))),
          if(map.nodes.isEmpty)const Padding(padding:EdgeInsets.all(10),
            child:Text('Your sky is empty for now. Add habits or link goals to see it grow.')),
          Container(width:double.infinity,padding:const EdgeInsets.all(14),
            color:Theme.of(context).colorScheme.surface,child:Column(
              crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(selected?.label ?? (activity?'Your habit activity':'Your connected work'),
                maxLines:2,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.titleMedium),
              Text(selected?.value ?? 'Pinch to zoom • Drag to explore • Tap any node'),
              Text('${map.nodes.length} real nodes • ${map.edges.length} links',
                style:Theme.of(context).textTheme.bodySmall),
            ])),
        ]);
      }),
  );
}
class _Lines extends CustomPainter {
  const _Lines(this.map);
  final StarMap map;
  @override void paint(Canvas canvas,Size size){
    final paint=Paint()..color=Colors.white.withValues(alpha:.27)..strokeWidth=1.6;
    for(final line in map.edges){
      if(line.a<map.nodes.length&&line.b<map.nodes.length)
        canvas.drawLine(map.nodes[line.a].position,map.nodes[line.b].position,paint);
    }
  }
  @override bool shouldRepaint(covariant _Lines oldDelegate)=>oldDelegate.map!=map;
}
