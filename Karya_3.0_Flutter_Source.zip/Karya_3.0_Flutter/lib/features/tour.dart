import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class TourScreen extends StatefulWidget {
  const TourScreen({super.key});
  @override State<TourScreen> createState()=>_TourScreenState();
}
class _TourScreenState extends State<TourScreen> {
  int step=0;
  static const titles=[
    'WELCOME TO KĀRYA ✦','SUBJECT BOARDS','TASKS IN SECONDS',
    'ONE DAY AT A TIME','THOUGHTS INTO ACTION','GOAL TREES',
    'YOUR CONSTELLATION','MAKE IT YOURS',
  ];
  static const descriptions=[
    'Less Organising. More Doing. Offline-first. No ads. No accounts.',
    'Create colorful boards for your subjects, personal life and projects. They live right on Home.',
    'Tap Add Task, type a name, and you are done. Dates, priorities and reminders are optional.',
    'Check off habits without guilt. Your heatmap shows real activity, never pretend progress.',
    'Use Ideas for any thought. Chaos Dump sorts your messy writing into editable Tasks and Ideas.',
    'Break ambitions into steps by connecting tasks, habits and ideas with your goals.',
    'Watch your completed habits become stars and explore how your work is connected.',
    'Choose five themes with true-black dark mode. Optional Wi-Fi sync shares directly with your Windows laptop.',
  ];
  static const symbols=[
    Icons.waving_hand,Icons.folder_copy_outlined,Icons.add_task,
    Icons.check_circle_outline,Icons.edit_note_outlined,Icons.account_tree_outlined,
    Icons.hub_outlined,Icons.palette_outlined,
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('GETTING STARTED'),
      actions:[TextButton(onPressed:()=>context.pop(),child:const Text('SKIP'))]),
    body:SafeArea(child:Center(child:ConstrainedBox(
      constraints:const BoxConstraints(maxWidth:600),
      child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
        Expanded(child:Center(child:SingleChildScrollView(child:Column(children:[
          AnimatedSwitcher(duration:const Duration(milliseconds:260),
            child:Icon(symbols[step],key:ValueKey(step),size:94,
              color:Theme.of(context).colorScheme.primary)),
          const SizedBox(height:24),
          Text(titles[step],textAlign:TextAlign.center,
            style:Theme.of(context).textTheme.headlineLarge),
          const SizedBox(height:12),
          Text(descriptions[step],textAlign:TextAlign.center,
            style:Theme.of(context).textTheme.bodyLarge),
        ])))),
        Wrap(alignment:WrapAlignment.center,spacing:4,children:[
          for(var i=0;i<titles.length;i++)Container(width:i==step?22:8,height:8,
            decoration:BoxDecoration(color:i==step?Theme.of(context).colorScheme.primary:Colors.grey,
              borderRadius:BorderRadius.circular(8))),
        ]),
        const SizedBox(height:18),
        SizedBox(width:double.infinity,child:FilledButton(onPressed:(){
          if(step==titles.length-1)context.pop();
          else setState(()=>step++);
        },child:Text(step==titles.length-1?'START USING KĀRYA':'NEXT →'))),
      ])),
    ))),
  );
}
