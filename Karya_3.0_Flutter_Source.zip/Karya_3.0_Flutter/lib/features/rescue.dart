import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../core/models.dart';
import '../core/state.dart';
import 'neo.dart';
import 'tasks.dart';

/// Tiny, fully offline prioritizer; it never edits or deletes tasks automatically.
List<Task> rescueCandidates(List<Task> tasks, DateTime now) {
  final current = dayKey(now);
  final pending = tasks.where((t)=>!t.completed).toList();
  int score(Task t) {
    final overdue=t.dueDay!=null && t.dueDay!.compareTo(current)<0;
    final today=t.dueDay==current;
    return (overdue?100:today?75:0) +
      (t.priority=='high'?30:t.priority=='medium'?10:0);
  }
  pending.sort((a,b){final c=score(b).compareTo(score(a));
    if(c!=0)return c;
    return (a.dueAt??'9999').compareTo(b.dueAt??'9999');});
  return pending.take(3).toList();
}
class RescueScreen extends ConsumerWidget {
  const RescueScreen({super.key});
  @override Widget build(BuildContext context, WidgetRef ref) => Scaffold(
    appBar:AppBar(title:const Text('RESCUE MY DAY')),
    body:ref.watch(appProvider).when(loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('$e')),data:(data){
        final picks=rescueCandidates(data.tasks,DateTime.now());
        return ScreenBody(children:[
          const Headline('START SMALL.','Three suggestions based on urgency and priority — you stay in control.'),
          if(picks.isEmpty)const EmptyState('All clear ✦','Nothing pending. Enjoy the space.'),
          for(var i=0;i<picks.length;i++)NeoCard(color:colorFor(i),child:Column(
            crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('STEP ${i+1}',style:const TextStyle(fontWeight:FontWeight.w900,color:Colors.black)),
              const SizedBox(height:4),
              Text(picks[i].title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:20,color:Colors.black)),
              if(picks[i].dueDay!=null)Text('Due: ${picks[i].dueDay}',style:const TextStyle(color:Colors.black)),
              const SizedBox(height:8),
              Wrap(spacing:7,children:[
                OutlinedButton.icon(icon:const Icon(Icons.check),label:const Text('Done'),
                  onPressed:()=>ref.read(appProvider.notifier).change((db)=>db.setTaskDone(picks[i].id,true))),
                OutlinedButton.icon(icon:const Icon(Icons.event),label:const Text('Reschedule'),
                  onPressed:()async {
                    final d=await showDatePicker(context:context,initialDate:DateTime.now(),
                      firstDate:DateTime.now(),lastDate:DateTime(2100));
                    if(d==null)return;
                    final t=picks[i];
                    await ref.read(appProvider.notifier).change((db)=>db.saveTask(
                      id:t.id,title:t.title,description:t.description,subjectId:t.subjectId,
                      priority:t.priority,dueAt:DateFormat("yyyy-MM-dd'T'HH:mm:ss").format(
                        DateTime(d.year,d.month,d.day,23,59)),reminderAt:null));
                  }),
                TextButton(onPressed:()=>showTaskEditor(context,ref,task:picks[i]),child:const Text('Details')),
              ]),
            ])),
          NeoCard(child:const Text('This is a suggestion, not a judgment. No streaks, guilt, or automatically postponed tasks.')),
        ]);
      }),
  );
}

String weeklyStory(AppData data, DateTime reference) {
  final week = List.generate(7, (i)=>DateTime(reference.year,reference.month,reference.day-i));
  final keys = week.map(dayKey).toSet();
  final tasks = data.tasks.where((t)=>t.completedAt!=null && keys.contains(t.completedAt!.substring(0,10))).length;
  final logs = week.fold<int>(0,(sum,day)=>sum+statsFor(data.habits,day).completed);
  final habitsActive = data.habits.where((h)=>week.any((d)=>h.scheduledOn(d)&&h.doneOn(d))).length;
  final ideaTasks=data.links.where((l)=>l.fromType=='idea'&&l.toType=='task'&&
    data.tasks.any((t)=>t.id==l.toId&&t.completedAt!=null&&
      keys.contains(t.completedAt!.substring(0,10)))).length;
  if(tasks==0 && logs==0)return 'A fresh page. Add a task, check in with a habit, or catch an idea. No pressure.';
  final parts=<String>[];
  if(tasks>0)parts.add('You finished $tasks task${tasks==1?'':'s'} this week.');
  if(logs>0)parts.add('You made $logs habit check-in${logs==1?'':'s'} across $habitsActive habit${habitsActive==1?'':'s'}.');
  if(ideaTasks>0)parts.add('$ideaTasks idea${ideaTasks==1?'':'s'} turned into completed tasks.');
  parts.add('Small actions add up. Your Constellation remembers the moments you showed up.');
  return parts.join(' ');
}
class WeeklyStoryScreen extends ConsumerWidget {
  const WeeklyStoryScreen({super.key});
  @override Widget build(BuildContext context, WidgetRef ref)=>Scaffold(
    appBar:AppBar(title:const Text('YOUR WEEK IN WORDS')),
    body:ref.watch(appProvider).when(loading:()=>const Center(child:CircularProgressIndicator()),
      error:(e,_)=>Center(child:Text('$e')),data:(data)=>ScreenBody(children:[
        const Headline('THE LITTLE THINGS ✦','A story from your actual records. Never invented numbers.'),
        NeoCard(color:colorFor(2),padding:const EdgeInsets.all(24),child:
          Text(weeklyStory(data,DateTime.now()),
            style:const TextStyle(color:Colors.black,fontSize:19,fontWeight:FontWeight.w800,height:1.45))),
        const Text('Your weekly recap uses the last seven local calendar days. Nothing is sent online.'),
      ])));
}
